#include <gprolog.h>
#include <stdio.h>
#include <stdlib.h>

 
typedef struct __anonstruct_EState_27 EState;

typedef struct __anonstruct_DState_28 DState;

typedef struct __anonstruct_bz_stream_26 bz_stream;
typedef unsigned char UChar;
typedef int Int32;
typedef unsigned int UInt32;
typedef unsigned short UInt16;


typedef void BZFILE;
typedef char Char;

PlBool ptrR(PlLong* p,  PlLong* star_p, PlLong len)
{

  {
    switch(len)
    {
      case 1:
        *p = *(unsigned char*)star_p;
        break;
      case 2:
        *p = *(short*)star_p;
        break;
      case 4:
        *p = *(int*)star_p;
        break;
      case 8:
        *p = *(long long*)star_p;
        break;
      default :
        printf("undefined exp length in babel_ptrR\n");
    }
  }

  return PL_TRUE;
}

PlBool babel_ptrR_byte(PlLong* p,  PlLong* star_p, PlLong len)
{

  if (star_p == NULL)
    return PL_FALSE;
  else
  {
    switch(len)
    {
      case 1:
        *p = *(unsigned char*)star_p;
        break;
      case 2:
        *p = *(short*)star_p;
        break;
      case 4:
        *p = *(int*)star_p;
        break;
      case 8:
        *p = *(long long*)star_p;
        break;
      default :
        printf("undefined exp length in babel_ptrR\n");
    }
  }

  return PL_TRUE;
}

PlBool ptrW(PlLong* p,  PlLong e, PlLong len)
{
  switch(len)
  {
    case 1:
      *(unsigned char*)p = (unsigned char)e;
      break;
    case 2:
      *(short*) p = (short)e;
      break;
    case 4:
      *(int*)p = (int)e;
      break;
    case 8:
      *(long long*)p = (long long)e;
      break;
    default :
      printf("undefined exp length in babel_ptrL\n");
  }

  return PL_TRUE;
}


PlBool babel__huffman_c_8(Int32 * arg_0, Int32 * arg_1, Int32  arg_2) 
{
  BZ2_hbMakeCodeLengths_cil_lr_2_cil_lr_3_cil_lr_1(arg_0, arg_1, arg_2);
  return PL_TRUE;
}
PlBool babel__huffman_c_9(UChar ** arg_0, Int32 * arg_1, Int32 * arg_2, unsigned char * arg_3, Int32 * arg_4, Int32  arg_5) 
{
  BZ2_hbMakeCodeLengths_cil_lr_2_cil_lr_3(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5);
  return PL_TRUE;
}
PlBool babel__huffman_c_10(UChar ** arg_0, Int32 * arg_1, Int32 * arg_2, unsigned char * arg_3, Int32 * arg_4, Int32  arg_5) 
{
  BZ2_hbMakeCodeLengths_cil_lr_2_cil_lr_3(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5);
  return PL_TRUE;
}
PlBool babel__huffman_c_11(UChar ** arg_0, Int32 * arg_1, Int32 * arg_2, unsigned char * arg_3, Int32 * arg_4, Int32  arg_5) 
{
  BZ2_hbMakeCodeLengths_cil_lr_2_cil_lr_3(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5);
  return PL_TRUE;
}

PlBool babel__compress_c_0(EState ** arg_0) 
{
  bsW_cil_lr_1(arg_0);
  return PL_TRUE;
}
PlBool babel__compress_c_1(EState * arg_0, int arg_1, UInt32  arg_2) 
{
  bsW(arg_0, arg_1, arg_2);
  return PL_TRUE;
}
PlBool babel__compress_c_2(EState * arg_0, int arg_1, UInt32  arg_2) 
{
  bsW(arg_0, arg_1, arg_2);
  return PL_TRUE;
}
PlBool babel__compress_c_3(EState * arg_0, int arg_1, UInt32  arg_2) 
{
  bsW(arg_0, arg_1, arg_2);
  return PL_TRUE;
}
PlBool babel__compress_c_4(EState * arg_0, int arg_1, UInt32  arg_2) 
{
  bsW(arg_0, arg_1, arg_2);
  return PL_TRUE;
}
PlBool babel__compress_c_5(EState * arg_0, int arg_1, UInt32  arg_2) 
{
  bsW(arg_0, arg_1, arg_2);
  return PL_TRUE;
}
PlBool babel__compress_c_6(EState * arg_0, Int32  arg_1) 
{
  makeMaps_e_cil_lr_1(arg_0, arg_1);
  return PL_TRUE;
}


PlBool babel__bzlib_c_0( PlLong * babel_ret) 
{
  *babel_ret = BZ2_bzlibVersion();
  return PL_TRUE;
}
PlBool babel__bzlib_c_1(FILE * __restrict   arg_0, char const   * __restrict   arg_1, int  arg_2, char const   * arg_3) 
{
  fprintf(arg_0, arg_1, arg_2, arg_3);
  return PL_TRUE;
}
PlBool babel__bzlib_c_2(FILE * __restrict   arg_0, char const   * __restrict   arg_1) 
{
  fprintf(arg_0, arg_1);
  return PL_TRUE;
}
PlBool babel__bzlib_c_3(int arg_0) 
{
  exit(arg_0);
  return PL_TRUE;
}
PlBool babel__bzlib_c_4(size_t  arg_0,  PlLong * babel_ret) 
{
  *babel_ret = malloc(arg_0);
  return PL_TRUE;
}
PlBool babel__bzlib_c_5(void * arg_0) 
{
  free(arg_0);
  return PL_TRUE;
}
PlBool babel__bzlib_c_6(EState ** arg_0, Int32  arg_1) 
{
  prepare_new_block_cil_lr_1(arg_0, arg_1);
  return PL_TRUE;
}
PlBool babel__bzlib_c_7(unsigned char * arg_0, EState * arg_1) 
{
  copy_output_until_stop_cil_lr_1(arg_0, arg_1);
  return PL_TRUE;
}
PlBool babel__bzlib_c_8(char const   * arg_0, int arg_1, char const   * arg_2, int arg_3,  PlLong * babel_ret) 
{
  *babel_ret = bzopen_or_bzdopen(arg_0, arg_1, arg_2, arg_3);
  return PL_TRUE;
}
PlBool babel__bzlib_c_9(char const   * arg_0, int  arg_1, char const   * arg_2, int arg_3,  PlLong * babel_ret) 
{
  *babel_ret = bzopen_or_bzdopen(arg_0, arg_1, arg_2, arg_3);
  return PL_TRUE;
}

PlBool babel__bzlib_c_11(int * arg_0, DState * arg_1,  PlLong * babel_ret) 
{
  *babel_ret = BZ2_bzDecompress_cil_lr_1(arg_0, arg_1);
  return PL_TRUE;
}
PlBool babel__bzlib_c_12(int arg_0) 
{
  BZ2_bz__AssertH__fail(arg_0);
  return PL_TRUE;
}

PlBool babel__blocksort_c_0(Int32 * arg_0, Int32  arg_1) 
{
  mainSimpleSort_cil_lr_1(arg_0, arg_1);
  return PL_TRUE;
}
PlBool babel__blocksort_c_1(UInt32 * arg_0, UChar * arg_1, UInt16 * arg_2, Int32  arg_3, Int32  arg_4, Int32  arg_5, Int32  arg_6, Int32 * arg_7, Int32  arg_8,  PlLong * babel_ret) 
{
  *babel_ret = mainSimpleSort_cil_lr_2(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, arg_7, arg_8);
  return PL_TRUE;
}
PlBool babel__blocksort_c_2(PlLong  arg_0,PlLong  arg_1, UChar * arg_2, UInt16 * arg_3, PlLong arg_4, Int32 * arg_5,  PlLong * babel_ret) 
{
  *babel_ret = mainGtU(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5);
  return PL_TRUE;
}
PlBool babel__blocksort_c_3(UInt32 ** arg_0, UInt32 ** arg_1, Int32 * arg_2, Int32 * arg_3, UInt32  arg_4) 
{
  fallbackSimpleSort_cil_lr_2_cil_lr_1(arg_0, arg_1, arg_2, arg_3, arg_4);
  return PL_TRUE;
}
PlBool babel__blocksort_c_4(UInt32 * arg_0, UInt32 * arg_1, Int32  arg_2, Int32  arg_3, Int32  arg_4) 
{
  fallbackSimpleSort_cil_lr_2(arg_0, arg_1, arg_2, arg_3, arg_4);
  return PL_TRUE;
}

PlBool bzlib_c_0(EState *s)
{
  add_pair_to_block(s);
  return PL_TRUE;
  
}
