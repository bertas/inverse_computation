babelJcc(OP, L, R) :-
    (  OP =:= 12 -> L =:= R
       ;  OP =:= 13 -> L \= R
       ;  OP =:= 14 -> L > R
       ;  OP =:= 15 -> L =< R
       ;  OP =:= 16 -> L < R
       ;  OP =:= 17 -> L >= R
    ).

:-foreign(babel_ptrR_byte(-byte, +integer, +integer)).
:-foreign(ptrR(-integer, +integer, +integer)).
:-foreign(ptrW(+integer, +integer, +integer)).

babelPtrR_byte(E, P, L) :- babel_ptrR_byte(T, P, L), E is T.

babelAssign(Var, Val) :- Var is Val.

bZ2_bsInitWrite(S, VOID) :- 


    babelAssign(__CIL_TMP2_SSA_1, S +1* 644),
    babelAssign(__CIL_TMP3_SSA_1, __CIL_TMP2_SSA_1),
    BabelExp_0 is 0,
    ptrW(__CIL_TMP3_SSA_1, BabelExp_0, 4),
    babelAssign(__CIL_TMP4_SSA_1, S +1* 640),
    babelAssign(__CIL_TMP5_SSA_1, __CIL_TMP4_SSA_1),
    BabelExp_1 is 0,
    ptrW(__CIL_TMP5_SSA_1, BabelExp_1, 4),true. 

:- foreign(babel__compress_c_0(+integer)).

bsW(__CIL_FP_S, __CIL_PP_S, S, N, V, VOID) :- 


    BabelExp_2 is S,
    ptrW(__CIL_FP_S, BabelExp_2, 8),
    babel__compress_c_0(__CIL_PP_S),
    BabelExp_3 is __CIL_FP_S,
    ptrR(S_SSA_1, BabelExp_3, 8),
    babelAssign(__CIL_TMP6_SSA_1, S_SSA_1 +1* 640),
    babelAssign(__CIL_TMP7_SSA_1, __CIL_TMP6_SSA_1),
    babelAssign(__CIL_TMP8_SSA_1, S_SSA_1 +1* 644),
    babelAssign(__CIL_TMP9_SSA_1, __CIL_TMP8_SSA_1),
    BabelExp_4 is __CIL_TMP9_SSA_1,
    ptrR(__CIL_TMP10_SSA_1, BabelExp_4, 4),
    BabelExp_5 is 32 - __CIL_TMP10_SSA_1,
    babelAssign(__CIL_TMP11_SSA_1, BabelExp_5),
    BabelExp_6 is __CIL_TMP11_SSA_1 - N,
    babelAssign(__CIL_TMP12_SSA_1, BabelExp_6),
    BabelExp_7 is __CIL_TMP7_SSA_1,
    ptrR(__CIL_TMP13_SSA_1, BabelExp_7, 4),
    BabelExp_8 is V << __CIL_TMP12_SSA_1,
    babelAssign(__CIL_TMP14_SSA_1, BabelExp_8),
    babelAssign(__CIL_TMP15_SSA_1, S_SSA_1 +1* 640),
    babelAssign(__CIL_TMP16_SSA_1, __CIL_TMP15_SSA_1),
    BabelExp_9 is __CIL_TMP13_SSA_1 \/ __CIL_TMP14_SSA_1,
    ptrW(__CIL_TMP16_SSA_1, BabelExp_9, 4),
    babelAssign(__CIL_TMP17_SSA_1, S_SSA_1 +1* 644),
    babelAssign(__CIL_TMP18_SSA_1, __CIL_TMP17_SSA_1),
    BabelExp_10 is __CIL_TMP18_SSA_1,
    ptrR(__CIL_TMP19_SSA_1, BabelExp_10, 4),
    babelAssign(__CIL_TMP20_SSA_1, S_SSA_1 +1* 644),
    babelAssign(__CIL_TMP21_SSA_1, __CIL_TMP20_SSA_1),
    BabelExp_11 is __CIL_TMP19_SSA_1 + N,
    ptrW(__CIL_TMP21_SSA_1, BabelExp_11, 4),true. 

:- foreign(babel__compress_c_1(+integer, +integer, +positive)).
:- foreign(babel__compress_c_2(+integer, +integer, +positive)).
:- foreign(babel__compress_c_3(+integer, +integer, +positive)).
:- foreign(babel__compress_c_4(+integer, +integer, +positive)).

bsPutUInt32(S, U, VOID) :- 


    BabelExp_12 is U >> 24,
    babelAssign(__CIL_TMP3_SSA_1, BabelExp_12),
    BabelExp_13 is __CIL_TMP3_SSA_1,
    babelAssign(__CIL_TMP4_SSA_1, BabelExp_13),
    BabelExp_14 is __CIL_TMP4_SSA_1 /\ 255,
    babelAssign(__CIL_TMP5_SSA_1, BabelExp_14),
    babel__compress_c_1(S, 8, __CIL_TMP5_SSA_1),
    BabelExp_15 is U >> 16,
    babelAssign(__CIL_TMP6_SSA_1, BabelExp_15),
    BabelExp_16 is __CIL_TMP6_SSA_1,
    babelAssign(__CIL_TMP7_SSA_1, BabelExp_16),
    BabelExp_17 is __CIL_TMP7_SSA_1 /\ 255,
    babelAssign(__CIL_TMP8_SSA_1, BabelExp_17),
    babel__compress_c_2(S, 8, __CIL_TMP8_SSA_1),
    BabelExp_18 is U >> 8,
    babelAssign(__CIL_TMP9_SSA_1, BabelExp_18),
    BabelExp_19 is __CIL_TMP9_SSA_1,
    babelAssign(__CIL_TMP10_SSA_1, BabelExp_19),
    BabelExp_20 is __CIL_TMP10_SSA_1 /\ 255,
    babelAssign(__CIL_TMP11_SSA_1, BabelExp_20),
    babel__compress_c_3(S, 8, __CIL_TMP11_SSA_1),
    BabelExp_21 is U /\ 255,
    babelAssign(__CIL_TMP12_SSA_1, BabelExp_21),
    babel__compress_c_4(S, 8, __CIL_TMP12_SSA_1),true. 

:- foreign(babel__compress_c_5(+integer, +integer, +positive)).

bsPutUChar(S, C, VOID) :- 
    babel__compress_c_5(S, 8, C),true. 

:- foreign(babel__compress_c_6(+integer, +integer)).

makeMaps_e(S) :- 

    __CIL_TMP4_SSA_1 is S +124,
    ptrW(__CIL_TMP4_SSA_1, 0, 4),

    makeMaps_e_cil_lr_1(S, 0). 

makeMaps_e_cil_lr_1(S, I) :-
    I >= 256 -> true;
    T3 is S + 128 + I,
    ptrR(T4, T3, 1),
    (T4 =:= 0 -> true;
     T5 is S + 124,
     ptrR(T6, T5, 4),
     T8 is S + 384,
     T9 is T8 + I,
     TMP is T6,
     ptrW(T9, TMP, 1),
     TMP2 is T6 + 1,
     ptrW(T5, TMP2, 4)
    ),
    I_SSA_2 is I + 1,
    makeMaps_e_cil_lr_1(S, I_SSA_2).

makeMaps_d(S) :- 
    (__CIL_TMP4_SSA_1 is S +3192),
    ptrW(__CIL_TMP4_SSA_1, 0, 4),
    makeMaps_d_cil_lr_1(S, 0).

makeMaps_d_cil_lr_1(S, I):-
    I >= 256 -> true;
    T3 is S + 3196 + I,
    ptrR(T4, T3, 1),
    (T4 =:= 0 -> true;
     T5 is S + 3192,
     ptrR(T6, T5, 4),
     T9 is S + 3468 + T6,
     ptrW(T9, I, 1),
     TMP2 is T6 + 1,
     ptrW(T5, TMP2, 4)
    ),
    I_SSA_2 is I + 1,
    makeMaps_d_cil_lr_1(S, I_SSA_2).
    

generateMTFValues_cil_lr_3_cil_lr_2(__CIL_AP_RTMP, __CIL_AP_RYY_J, RLL_I, VOID) :- 


    BabelExp_23 is __CIL_AP_RTMP,
    babelPtrR_byte(__CIL_TMP6_SSA_1, BabelExp_23, 1),
    BabelExp_24 is __CIL_TMP6_SSA_1,
    babelAssign(__CIL_TMP7_SSA_1, BabelExp_24),

    (babelJcc(13, RLL_I, __CIL_TMP7_SSA_1) ->
         babelAssign(__CIL_TMP5_SSA_1, 1)
     ; babelAssign(__CIL_TMP5_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP5_SSA_1, 0) ->
         BabelExp_25 is __CIL_AP_RYY_J,
         ptrR(__CIL_TMP8_SSA_1, BabelExp_25, 8),
         BabelExp_26 is __CIL_TMP8_SSA_1 + 1,
         ptrW(__CIL_AP_RYY_J, BabelExp_26, 8),
         BabelExp_27 is __CIL_AP_RTMP,
         babelPtrR_byte(RTMP2_SSA_1, BabelExp_27, 1),
         BabelExp_28 is __CIL_AP_RYY_J,
         ptrR(__CIL_TMP9_SSA_1, BabelExp_28, 8),
         babelPtrR_byte(BabelExp_29, __CIL_TMP9_SSA_1, 1),
         ptrW(__CIL_AP_RTMP, BabelExp_29, 1),
         BabelExp_30 is __CIL_AP_RYY_J,
         ptrR(__CIL_TMP10_SSA_1, BabelExp_30, 8),
         BabelExp_31 is RTMP2_SSA_1,
         ptrW(__CIL_TMP10_SSA_1, BabelExp_31, 1),
         generateMTFValues_cil_lr_3_cil_lr_2(__CIL_AP_RTMP, __CIL_AP_RYY_J, RLL_I, VOID)
     ; true). 


generateMTFValues_cil_lr_1(__CIL_AP_S, __CIL_AP_EOB, I, VOID) :- 


    BabelExp_32 is __CIL_AP_EOB,
    ptrR(__CIL_TMP5_SSA_1, BabelExp_32, 4),

    (babelJcc(15, I, __CIL_TMP5_SSA_1) ->
         babelAssign(__CIL_TMP4_SSA_1, 1)
     ; babelAssign(__CIL_TMP4_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP4_SSA_1, 0) ->
         BabelExp_33 is __CIL_AP_S,
         ptrR(__CIL_TMP6_SSA_1, BabelExp_33, 8),
         babelAssign(__CIL_TMP7_SSA_1, __CIL_TMP6_SSA_1),
         babelAssign(__CIL_TMP8_SSA_1, __CIL_TMP7_SSA_1 +1* 672),
         babelAssign(__CIL_TMP9_SSA_1, __CIL_TMP8_SSA_1),
         babelAssign(__CIL_TMP10_SSA_1, __CIL_TMP9_SSA_1),
         babelAssign(__CIL_TMP11_SSA_1, __CIL_TMP10_SSA_1 +4* I),
         BabelExp_34 is 0,
         ptrW(__CIL_TMP11_SSA_1, BabelExp_34, 4),
         BabelExp_35 is I + 1,
         babelAssign(I_SSA_1, BabelExp_35),
         generateMTFValues_cil_lr_1(__CIL_AP_S, __CIL_AP_EOB, I_SSA_1, VOID)
     ; true). 


generateMTFValues_cil_lr_2(__CIL_AP_S, YY, I, VOID) :- 


    BabelExp_36 is __CIL_AP_S,
    ptrR(__CIL_TMP5_SSA_1, BabelExp_36, 8),
    babelAssign(__CIL_TMP6_SSA_1, __CIL_TMP5_SSA_1),
    babelAssign(__CIL_TMP7_SSA_1, __CIL_TMP6_SSA_1 +1* 124),
    babelAssign(__CIL_TMP8_SSA_1, __CIL_TMP7_SSA_1),
    BabelExp_37 is __CIL_TMP8_SSA_1,
    ptrR(__CIL_TMP9_SSA_1, BabelExp_37, 4),

    (babelJcc(16, I, __CIL_TMP9_SSA_1) ->
         babelAssign(__CIL_TMP4_SSA_1, 1)
     ; babelAssign(__CIL_TMP4_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP4_SSA_1, 0) ->
         babelAssign(__CIL_TMP10_SSA_1, (YY +1* I)),
         BabelExp_38 is I,
         ptrW(__CIL_TMP10_SSA_1, BabelExp_38, 1),
         BabelExp_39 is I + 1,
         babelAssign(I_SSA_1, BabelExp_39),
         generateMTFValues_cil_lr_2(__CIL_AP_S, YY, I_SSA_1, VOID),true
     ; true). 


generateMTFValues_cil_lr_4(__CIL_AP_S, __CIL_AP_WR, __CIL_AP_MTFV, ZPEND, VOID) :- 
    BabelExp_68 is ZPEND /\ 1,
    babelAssign(__CIL_TMP5_SSA_1, BabelExp_68),
    (babelJcc(13, __CIL_TMP5_SSA_1, 0) ->
         BabelExp_69 is __CIL_AP_MTFV,
         ptrR(__CIL_TMP7_SSA_1, BabelExp_69, 8),
         BabelExp_70 is __CIL_AP_WR,
         ptrR(__CIL_TMP8_SSA_1, BabelExp_70, 4),
         babelAssign(__CIL_TMP9_SSA_1, __CIL_TMP7_SSA_1 +2* __CIL_TMP8_SSA_1),
         BabelExp_71 is 1,
         ptrW(__CIL_TMP9_SSA_1, BabelExp_71, 2),
         BabelExp_72 is __CIL_AP_WR,
         ptrR(__CIL_TMP10_SSA_1, BabelExp_72, 4),
         BabelExp_73 is __CIL_TMP10_SSA_1 + 1,
         ptrW(__CIL_AP_WR, BabelExp_73, 4),
         BabelExp_74 is __CIL_AP_S,
         ptrR(__CIL_TMP11_SSA_1, BabelExp_74, 8),
         babelAssign(__CIL_TMP12_SSA_1, __CIL_TMP11_SSA_1),
         babelAssign(__CIL_TMP13_SSA_1, __CIL_TMP12_SSA_1 +1* 672),
         babelAssign(__CIL_TMP14_SSA_1, __CIL_TMP13_SSA_1),
         babelAssign(__CIL_TMP15_SSA_1, __CIL_TMP14_SSA_1),
         babelAssign(__CIL_TMP16_SSA_1, __CIL_TMP15_SSA_1 +4* 1),
         BabelExp_75 is __CIL_TMP16_SSA_1,
         ptrR(__CIL_TMP17_SSA_1, BabelExp_75, 4),
         BabelExp_76 is __CIL_AP_S,
         ptrR(__CIL_TMP18_SSA_1, BabelExp_76, 8),
         babelAssign(__CIL_TMP19_SSA_1, __CIL_TMP18_SSA_1),
         babelAssign(__CIL_TMP20_SSA_1, __CIL_TMP19_SSA_1 +1* 672),
         babelAssign(__CIL_TMP21_SSA_1, __CIL_TMP20_SSA_1),
         babelAssign(__CIL_TMP22_SSA_1, __CIL_TMP21_SSA_1),
         babelAssign(__CIL_TMP23_SSA_1, __CIL_TMP22_SSA_1 +4* 1),
         BabelExp_77 is __CIL_TMP17_SSA_1 + 1,
         ptrW(__CIL_TMP23_SSA_1, BabelExp_77, 4),
         babelAssign(__CIL_TMP24_SSA_1, __CIL_TMP24),
         babelAssign(__CIL_TMP25_SSA_1, __CIL_TMP25),
         babelAssign(__CIL_TMP26_SSA_1, __CIL_TMP26),
         babelAssign(__CIL_TMP27_SSA_1, __CIL_TMP27),
         babelAssign(__CIL_TMP28_SSA_1, __CIL_TMP28),
         babelAssign(__CIL_TMP29_SSA_1, __CIL_TMP29),
         babelAssign(__CIL_TMP30_SSA_1, __CIL_TMP30),
         babelAssign(__CIL_TMP31_SSA_1, __CIL_TMP31),
         babelAssign(__CIL_TMP32_SSA_1, __CIL_TMP32),
         babelAssign(__CIL_TMP33_SSA_1, __CIL_TMP33),
         babelAssign(__CIL_TMP34_SSA_1, __CIL_TMP34),
         babelAssign(__CIL_TMP35_SSA_1, __CIL_TMP35),
         babelAssign(__CIL_TMP36_SSA_1, __CIL_TMP36),
         babelAssign(__CIL_TMP37_SSA_1, __CIL_TMP37),
         babelAssign(__CIL_TMP38_SSA_1, __CIL_TMP38),
         babelAssign(__CIL_TMP39_SSA_1, __CIL_TMP39),
         babelAssign(__CIL_TMP40_SSA_1, __CIL_TMP40)
     ; BabelExp_78 is __CIL_AP_MTFV,
       ptrR(__CIL_TMP24_SSA_1, BabelExp_78, 8),
       BabelExp_79 is __CIL_AP_WR,
       ptrR(__CIL_TMP25_SSA_1, BabelExp_79, 4),
       babelAssign(__CIL_TMP26_SSA_1, __CIL_TMP24_SSA_1 +2* __CIL_TMP25_SSA_1),
       BabelExp_80 is 0,
       ptrW(__CIL_TMP26_SSA_1, BabelExp_80, 2),
       BabelExp_81 is __CIL_AP_WR,
       ptrR(__CIL_TMP27_SSA_1, BabelExp_81, 4),
       BabelExp_82 is __CIL_TMP27_SSA_1 + 1,
       ptrW(__CIL_AP_WR, BabelExp_82, 4),
       BabelExp_83 is __CIL_AP_S,
       ptrR(__CIL_TMP28_SSA_1, BabelExp_83, 8),
       babelAssign(__CIL_TMP29_SSA_1, __CIL_TMP28_SSA_1),
       babelAssign(__CIL_TMP30_SSA_1, __CIL_TMP29_SSA_1 +1* 672),
       babelAssign(__CIL_TMP31_SSA_1, __CIL_TMP30_SSA_1),
       babelAssign(__CIL_TMP32_SSA_1, __CIL_TMP31_SSA_1),
       babelAssign(__CIL_TMP33_SSA_1, __CIL_TMP32_SSA_1),
       BabelExp_84 is __CIL_TMP33_SSA_1,
       ptrR(__CIL_TMP34_SSA_1, BabelExp_84, 4),
       BabelExp_85 is __CIL_AP_S,
       ptrR(__CIL_TMP35_SSA_1, BabelExp_85, 8),
       babelAssign(__CIL_TMP36_SSA_1, __CIL_TMP35_SSA_1),
       babelAssign(__CIL_TMP37_SSA_1, __CIL_TMP36_SSA_1 +1* 672),
       babelAssign(__CIL_TMP38_SSA_1, __CIL_TMP37_SSA_1),
       babelAssign(__CIL_TMP39_SSA_1, __CIL_TMP38_SSA_1),
       babelAssign(__CIL_TMP40_SSA_1, __CIL_TMP39_SSA_1),
       BabelExp_86 is __CIL_TMP34_SSA_1 + 1,
       ptrW(__CIL_TMP40_SSA_1, BabelExp_86, 4),
       babelAssign(__CIL_TMP10_SSA_1, __CIL_TMP10),
       babelAssign(__CIL_TMP11_SSA_1, __CIL_TMP11),
       babelAssign(__CIL_TMP12_SSA_1, __CIL_TMP12),
       babelAssign(__CIL_TMP13_SSA_1, __CIL_TMP13),
       babelAssign(__CIL_TMP14_SSA_1, __CIL_TMP14),
       babelAssign(__CIL_TMP15_SSA_1, __CIL_TMP15),
       babelAssign(__CIL_TMP16_SSA_1, __CIL_TMP16),
       babelAssign(__CIL_TMP17_SSA_1, __CIL_TMP17),
       babelAssign(__CIL_TMP18_SSA_1, __CIL_TMP18),
       babelAssign(__CIL_TMP19_SSA_1, __CIL_TMP19),
       babelAssign(__CIL_TMP20_SSA_1, __CIL_TMP20),
       babelAssign(__CIL_TMP21_SSA_1, __CIL_TMP21),
       babelAssign(__CIL_TMP22_SSA_1, __CIL_TMP22),
       babelAssign(__CIL_TMP23_SSA_1, __CIL_TMP23),
       babelAssign(__CIL_TMP7_SSA_1, __CIL_TMP7),
       babelAssign(__CIL_TMP8_SSA_1, __CIL_TMP8),
       babelAssign(__CIL_TMP9_SSA_1, __CIL_TMP9)),

    (babelJcc(16, ZPEND, 2) ->
         babelAssign(__CIL_TMP6_SSA_1, 1)
     ; babelAssign(__CIL_TMP6_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP6_SSA_1, 0) ->
         true
     ; BabelExp_87 is ZPEND - 2,
       babelAssign(__CIL_TMP41_SSA_1, BabelExp_87),
       BabelExp_88 is __CIL_TMP41_SSA_1 / 2,
       babelAssign(ZPEND_SSA_1, BabelExp_88),
       generateMTFValues_cil_lr_4(__CIL_AP_S, __CIL_AP_WR, __CIL_AP_MTFV, ZPEND_SSA_1, VOID),true). 



bZ2_hbCreateDecodeTables(__CIL_FP_LENGTH, __CIL_FP_MAXLEN, __CIL_FP_ALPHASIZE, __CIL_FP_BASE, __CIL_FP_LIMIT, __CIL_PP_LENGTH, __CIL_PP_MAXLEN, __CIL_PP_ALPHASIZE, __CIL_PP_BASE, __CIL_PP_LIMIT, LIMIT, BASE, PERM, LENGTH, MINLEN, MAXLEN, ALPHASIZE, VOID) :- 
    bZ2_hbCreateDecodeTables_cil_lr_1(MAXLEN, ALPHASIZE, LENGTH, PERM, 0, BASE, MINLEN),
    bZ2_hbCreateDecodeTables_cil_lr_2(BASE, 0),
    bZ2_hbCreateDecodeTables_cil_lr_3(ALPHASIZE, BASE, LENGTH, 0),
    bZ2_hbCreateDecodeTables_cil_lr_4(BASE, 1),
    bZ2_hbCreateDecodeTables_cil_lr_5(LIMIT, 0),
    bZ2_hbCreateDecodeTables_cil_lr_6(MAXLEN, BASE, LIMIT, 0, 0),
    I_SSA_7 is MINLEN + 1,
    bZ2_hbCreateDecodeTables_cil_lr_7(MAXLEN, BASE, LIMIT, I_SSA_7).

bZ2_hbCreateDecodeTables_cil_lr_1(MAXLEN, ALPHASIZE, LENGTH, PERM, PP, BASE, I):-
    I > MAXLEN -> true;
    bZ2_hbCreateDecodeTables_cil_lr_1_cil_lr_1(ALPHASIZE, LENGTH, PERM, PP, PP_OUT, I, 0),
    I_SSA_1 is I + 1,
    bZ2_hbCreateDecodeTables_cil_lr_1(MAXLEN, ALPHASIZE, LENGTH, PERM, PP_OUT, BASE, I_SSA_1).

bZ2_hbCreateDecodeTables_cil_lr_1_cil_lr_1(ALPHASIZE, LENGTH, PERM, PP_IN, PP_OUT, I, J):-
    J >= ALPHASIZE -> PP_OUT is PP_IN;
    (T1 is LENGTH + J,
     ptrR(T2, T1, 1),
     (T2 =:= I -> T3 is PERM + PP_IN * 4, ptrW(T3, J, 4), PP_IN_SSA_1 is PP_IN + 1; PP_IN_SSA_1 is PP_IN),
     J_SSA_1 is J + 1,
     bZ2_hbCreateDecodeTables_cil_lr_1_cil_lr_1(ALPHASIZE, LENGTH, PERM, PP_IN_SSA_1, PP_OUT, I, J_SSA_1)
    ).

bZ2_hbCreateDecodeTables_cil_lr_2(BASE, I):-
    I >= 23 -> true;
    T1 is BASE + I * 4,
    ptrW(T1, 0, 4),
    I_SSA_1 is I + 1,
    bZ2_hbCreateDecodeTables_cil_lr_2(BASE, I_SSA_1).

bZ2_hbCreateDecodeTables_cil_lr_3(ALPHASIZE, BASE, LENGTH, I):-
    I >= ALPHASIZE -> true;
    T1 is LENGTH + I,
    ptrR(T2, T1, 1),
    T3 is BASE + (T2 + 1) * 4,
    ptrR(T4, T3, 4),
    T5 is T4 + 1,
    ptrW(T3, T5, 4),
    I_SSA_1 is I + 1,
    bZ2_hbCreateDecodeTables_cil_lr_3(ALPHASIZE, BASE, LENGTH, I_SSA_1).

bZ2_hbCreateDecodeTables_cil_lr_4(BASE, I):-
    I >= 23 -> true;
    T1 is BASE + I * 4,
    ptrR(T2, T1, 4),
    T3 is BASE + (I - 1) * 4,
    ptrR(T4, T3, 4),
    T5 is T2 + T4,
    ptrW(T1, T5, 4),
    I_SSA_1 is I + 1,
    bZ2_hbCreateDecodeTables_cil_lr_4(BASE, I_SSA_1).

bZ2_hbCreateDecodeTables_cil_lr_5(LIMIT, I):-
    I >= 23 -> true;
    T1 is LIMIT + I,
    ptrW(T1, 0, 1),
    I_SSA_1 is I + 1,
    bZ2_hbCreateDecodeTables_cil_lr_5(LIMIT, I_SSA_1).

bZ2_hbCreateDecodeTables_cil_lr_6(MAXLEN, BASE, LIMIT, VEC, I):-
    I > MAXLEN -> true;
    T1 is BASE + (I + 1) * 4, 
    ptrR(T2, T1, 4),
    T3 is BASE + I * 4,
    ptrR(T4, T3, 4),
    VEC_SSA_1 is VEC + (T2 - T4),
    T5 is LIMIT + I * 4,
    TMP is VEC_SSA_1 - 1,
    ptrW(T5, TMP, 4),
    VEC_SSA_2 is VEC_SSA_1 << 1,
    I_SSA_1 is I + 1,
    bZ2_hbCreateDecodeTables_cil_lr_6(MAXLEN, BASE, LIMIT, VEC_SSA_2, I_SSA_1).

bZ2_hbCreateDecodeTables_cil_lr_7(MAXLEN, BASE, LIMIT, I):-
    I > MAXLEN -> true;
    T1 is LIMIT + (I - 1) * 4,
    ptrR(Limiti_1, T1, 4),
    T2 is (Limiti_1 + 1) << 1,
    T3 is BASE + I * 4,
    ptrR(T4, T3, 4),
    T5 is T2 - T4,
    ptrW(T3, T5, 4),
    I_SSA_1 is I + 1,
    bZ2_hbCreateDecodeTables_cil_lr_7(MAXLEN, BASE, LIMIT, I_SSA_1).
                 

bZ2_hbCreateDecodeTables_cil_lr_1_cil_lr_1(__CIL_AP_PERM, __CIL_AP_PP, __CIL_AP_I, __CIL_AP_LENGTH, __CIL_AP_ALPHASIZE, J, VOID) :- 


    BabelExp_21 is 0,
    babelAssign(__CIL_TMP15, BabelExp_21),
    BabelExp_22 is 0,
    babelAssign(__CIL_TMP17, BabelExp_22),
    BabelExp_23 is __CIL_AP_ALPHASIZE,
    ptrR(__CIL_TMP9_SSA_1, BabelExp_23, 4),

    (babelJcc(16, J, __CIL_TMP9_SSA_1) ->
         babelAssign(__CIL_TMP7_SSA_1, 1)
     ; babelAssign(__CIL_TMP7_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP7_SSA_1, 0) ->
         BabelExp_24 is __CIL_AP_LENGTH,
         ptrR(__CIL_TMP10_SSA_1, BabelExp_24, 8),
         babelAssign(__CIL_TMP11_SSA_1, __CIL_TMP10_SSA_1 +1* J),
         BabelExp_25 is __CIL_TMP11_SSA_1,
         babelPtrR_byte(__CIL_TMP12_SSA_1, BabelExp_25, 1),
         BabelExp_26 is __CIL_TMP12_SSA_1,
         babelAssign(__CIL_TMP13_SSA_1, BabelExp_26),
         BabelExp_27 is __CIL_AP_I,
         ptrR(__CIL_TMP14_SSA_1, BabelExp_27, 4),

         (babelJcc(12, __CIL_TMP13_SSA_1, __CIL_TMP14_SSA_1) ->
              babelAssign(__CIL_TMP8_SSA_1, 1)
          ; babelAssign(__CIL_TMP8_SSA_1, 0)),

         (babelJcc(13, __CIL_TMP8_SSA_1, 0) ->
              BabelExp_28 is __CIL_AP_PERM,
              ptrR(__CIL_TMP15_SSA_1, BabelExp_28, 8),
              BabelExp_29 is __CIL_AP_PP,
              ptrR(__CIL_TMP16_SSA_1, BabelExp_29, 4),
              babelAssign(__CIL_TMP17_SSA_1, __CIL_TMP15_SSA_1 +4* __CIL_TMP16_SSA_1),
              BabelExp_30 is J,
              ptrW(__CIL_TMP17_SSA_1, BabelExp_30, 4),
              BabelExp_31 is __CIL_AP_PP,
              ptrR(__CIL_TMP18_SSA_1, BabelExp_31, 4),
              BabelExp_32 is __CIL_TMP18_SSA_1 + 1,
              ptrW(__CIL_AP_PP, BabelExp_32, 4)
          ; babelAssign(__CIL_TMP15_SSA_1, __CIL_TMP15),
            babelAssign(__CIL_TMP16_SSA_1, __CIL_TMP16),
            babelAssign(__CIL_TMP17_SSA_1, __CIL_TMP17),
            babelAssign(__CIL_TMP18_SSA_1, __CIL_TMP18)),
         BabelExp_33 is J + 1,
         babelAssign(J_SSA_1, BabelExp_33),
         bZ2_hbCreateDecodeTables_cil_lr_1_cil_lr_1(__CIL_AP_PERM, __CIL_AP_PP, __CIL_AP_I, __CIL_AP_LENGTH, __CIL_AP_ALPHASIZE, J_SSA_1, VOID),true
     ; true),
    BabelExp_34 is J + 1,
    babelAssign(J_SSA_1, BabelExp_34),
    bZ2_hbCreateDecodeTables_cil_lr_1_cil_lr_1(__CIL_AP_PERM, __CIL_AP_PP, __CIL_AP_I, __CIL_AP_LENGTH, __CIL_AP_ALPHASIZE, J_SSA_1, VOID),true. 

:- foreign(babel__huffman_c_8(+integer, +integer, +integer)).
:- foreign(babel__huffman_c_9(+integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__huffman_c_10(+integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__huffman_c_11(+integer, +integer, +integer, +integer, +integer, +integer)).

bZ2_hbMakeCodeLengths_cil_lr_2_cil_lr_3(__CIL_FP_J, __CIL_PP_J, __CIL_AP_LEN, __CIL_AP_ALPHASIZE, __CIL_AP_MAXLEN, __CIL_AP_TOOLONG, PARENT, I, VOID) :- 


    BabelExp_35 is __CIL_AP_ALPHASIZE,
    ptrR(__CIL_TMP13_SSA_1, BabelExp_35, 4),

    (babelJcc(15, I, __CIL_TMP13_SSA_1) ->
         babelAssign(__CIL_TMP11_SSA_1, 1)
     ; babelAssign(__CIL_TMP11_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP11_SSA_1, 0) ->
         babelAssign(J_SSA_1, 0),
         babelAssign(K_SSA_1, I),
         BabelExp_36 is J_SSA_1,
         ptrW(__CIL_FP_J, BabelExp_36, 4),
         babel__huffman_c_8(__CIL_PP_J, PARENT, K_SSA_1),
         BabelExp_37 is __CIL_FP_J,
         ptrR(J_SSA_2, BabelExp_37, 4),
         BabelExp_38 is __CIL_AP_LEN,
         ptrR(__CIL_TMP14_SSA_1, BabelExp_38, 8),
         BabelExp_39 is I - 1,
         babelAssign(__CIL_TMP15_SSA_1, BabelExp_39),
         babelAssign(__CIL_TMP16_SSA_1, __CIL_TMP14_SSA_1 +1* __CIL_TMP15_SSA_1),
         BabelExp_40 is J_SSA_2,
         ptrW(__CIL_TMP16_SSA_1, BabelExp_40, 1),
         BabelExp_41 is __CIL_AP_MAXLEN,
         ptrR(__CIL_TMP17_SSA_1, BabelExp_41, 4),

         (babelJcc(14, J_SSA_2, __CIL_TMP17_SSA_1) ->
              babelAssign(__CIL_TMP12_SSA_1, 1)
          ; babelAssign(__CIL_TMP12_SSA_1, 0)),

         (babelJcc(13, __CIL_TMP12_SSA_1, 0) ->
              BabelExp_42 is 1,
              ptrW(__CIL_AP_TOOLONG, BabelExp_42, 1)
          ; true),
         BabelExp_44 is I + 1,
         babelAssign(I_SSA_1, BabelExp_44),
         bZ2_hbMakeCodeLengths_cil_lr_2_cil_lr_3(__CIL_FP_J, __CIL_PP_J, __CIL_AP_LEN, __CIL_AP_ALPHASIZE, __CIL_AP_MAXLEN, __CIL_AP_TOOLONG, PARENT, I_SSA_1, VOID)
     ; true).

bZ2_hbMakeCodeLengths_cil_lr_2_cil_lr_4(__CIL_AP_ALPHASIZE, WEIGHT, I, VOID) :- 


    BabelExp_46 is __CIL_AP_ALPHASIZE,
    ptrR(__CIL_TMP6_SSA_1, BabelExp_46, 4),

    (babelJcc(15, I, __CIL_TMP6_SSA_1) ->
         babelAssign(__CIL_TMP5_SSA_1, 1)
     ; babelAssign(__CIL_TMP5_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP5_SSA_1, 0) ->
         babelAssign(__CIL_TMP7_SSA_1, (WEIGHT +4* I)),
         BabelExp_47 is __CIL_TMP7_SSA_1,
         ptrR(__CIL_TMP8_SSA_1, BabelExp_47, 4),
         BabelExp_48 is __CIL_TMP8_SSA_1 >> 8,
         babelAssign(J_SSA_1, BabelExp_48),
         BabelExp_49 is J_SSA_1 / 2,
         babelAssign(__CIL_TMP9_SSA_1, BabelExp_49),
         BabelExp_50 is 1 + __CIL_TMP9_SSA_1,
         babelAssign(J_SSA_2, BabelExp_50),
         babelAssign(__CIL_TMP10_SSA_1, (WEIGHT +4* I)),
         BabelExp_51 is J_SSA_2 << 8,
         ptrW(__CIL_TMP10_SSA_1, BabelExp_51, 4),
         BabelExp_52 is I + 1,
         babelAssign(I_SSA_1, BabelExp_52),
         bZ2_hbMakeCodeLengths_cil_lr_2_cil_lr_4(__CIL_AP_ALPHASIZE, WEIGHT, I_SSA_1, VOID),true
     ; true). 

bZ2_hbAssignCodes(CODE, LENGTH, MINLEN, MAXLEN, ALPHASIZE):-
    bZ2_hbAssignCodes_cil_lr_1(CODE, LENGTH, MAXLEN, ALPHASIZE, 0, MINLEN).

bZ2_hbAssignCodes_cil_lr_1(CODE, LENGTH, MAXLEN, ALPHASIZE, VEC, N):-
    N > MAXLEN -> true;
    bZ2_hbAssignCodes_cil_lr_1_cil_lr_1(CODE, LENGTH, ALPHASIZE, VEC, VEC_SSA_1, N, 0),
    N_SSA_1 is N + 1,
    VEC_SSA_2 is VEC_SSA_1 << 1,
    bZ2_hbAssignCodes_cil_lr_1(CODE, LENGTH, MAXLEN, ALPHASIZE, VEC_SSA_2, N_SSA_1).

bZ2_hbAssignCodes_cil_lr_1_cil_lr_1(CODE, LENGTH, ALPHASIZE, VEC_IN, VEC_OUT, N, I):-
    I >= ALPHASIZE -> VEC_OUT is VEC_IN;
    T1 is LENGTH + I,
    ptrR(T2, T1, 1),
    (T2 =:= N -> T3 is CODE + I * 4, ptrW(T3, VEC_IN, 4), VEC_SSA_1 is VEC_IN + 1; VEC_SSA_1 is VEC_IN),
    I_SSA_1 is I + 1,
    bZ2_hbAssignCodes_cil_lr_1_cil_lr_1(CODE, LENGTH, ALPHASIZE, VEC_SSA_1, VEC_OUT, N, I_SSA_1).

bZ2_hbMakeCodeLengths_cil_lr_1(__CIL_AP_ALPHASIZE, FREQ, I, WEIGHT, VOID) :- 
    ptrR(ALPHASIZE, __CIL_AP_ALPHASIZE, 4),
    (I > ALPHASIZE -> true;
     (
     babelAssign(BabelExp_119, FREQ +4* I),
     ptrR(__CIL_TMP10_SSA_1, BabelExp_119, 4),

     (__CIL_TMP10_SSA_1 =:= 0 ->
          TMP_SSA_1 is 1
      ; BabelExp_120 is FREQ +4* I,
        ptrR(TMP_SSA_1, BabelExp_120, 4)),
     __CIL_TMP13_SSA_1 is (WEIGHT +4* (I + 1)),
     BabelExp_122 is TMP_SSA_1 << 8,
     ptrW(__CIL_TMP13_SSA_1, BabelExp_122, 4),
     I_SSA_1 is I + 1,
     bZ2_hbMakeCodeLengths_cil_lr_1(__CIL_AP_ALPHASIZE, FREQ, I_SSA_1, WEIGHT, VOID))).



:- foreign(babel__bzlib_c_0( -integer)).
:- foreign(babel__bzlib_c_1(+integer, +integer, +integer, +integer)).
:- foreign(babel__bzlib_c_2(+integer, +integer)).
:- foreign(babel__bzlib_c_3(+integer)).

bZ2_bz__AssertH__fail(__CIL_GP_STDERR, ERRCODE, VOID) :- 


    BabelExp_0 is 0,
    babelAssign(__CIL_TMP6, BabelExp_0),
    babel__bzlib_c_0(TMP_SSA_1),
    BabelExp_1 is __CIL_GP_STDERR,
    ptrR(__CIL_TMP5_SSA_1, BabelExp_1, 8),
    babel__bzlib_c_1(__CIL_TMP5_SSA_1, '\n\nBZIP2/LIBBZIP2: INTERNAL ERROR NUMBER %D.\nTHIS IS A BUG IN BZIP2/LIBBZIP2, %S.\nPLEASE REPORT IT TO ME AT: JSEWARD@BZIP.ORG.  IF THIS HAPPENED\nWHEN YOU WERE USING SOME PROGRAM WHICH USES LIBBZIP2 AS A\nCOMPONENT, YOU SHOULD ALSO REPORT THIS BUG TO THE AUTHOR(S)\nOF THAT PROGRAM.  PLEASE MAKE AN EFFORT TO REPORT THIS BUG;\nTIMELY AND ACCURATE BUG REPORTS EVENTUALLY LEAD TO HIGHER\nQUALITY SOFTWARE.  THANKS.  JULIAN SEWARD, 10 DECEMBER 2007.\n\n', ERRCODE, TMP_SSA_1),

    (babelJcc(12, ERRCODE, 1007) ->
         babelAssign(__CIL_TMP4_SSA_1, 1)
     ; babelAssign(__CIL_TMP4_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP4_SSA_1, 0) ->
         BabelExp_2 is __CIL_GP_STDERR,
         ptrR(__CIL_TMP6_SSA_1, BabelExp_2, 8),
         babel__bzlib_c_2(__CIL_TMP6_SSA_1, '\n*** A SPECIAL NOTE ABOUT INTERNAL ERROR NUMBER 1007 ***\n\nEXPERIENCE SUGGESTS THAT A COMMON CAUSE OF I.E. 1007\nIS UNRELIABLE MEMORY OR OTHER HARDWARE.  THE 1007 ASSERTION\nJUST HAPPENS TO CROSS-CHECK THE RESULTS OF HUGE NUMBERS OF\nMEMORY READS/WRITES, AND SO ACTS (UNINTENDEDLY) AS A STRESS\nTEST OF YOUR MEMORY SYSTEM.\n\nI SUGGEST THE FOLLOWING: TRY COMPRESSING THE FILE AGAIN,\nPOSSIBLY MONITORING PROGRESS IN DETAIL WITH THE -VV FLAG.\n\n* IF THE ERROR CANNOT BE REPRODUCED, AND/OR HAPPENS AT DIFFERENT\n  POINTS IN COMPRESSION, YOU MAY HAVE A FLAKY MEMORY SYSTEM.\n  TRY A MEMORY-TEST PROGRAM.  I HAVE USED MEMTEST86\n  (WWW.MEMTEST86.COM).  AT THE TIME OF WRITING IT IS FREE (GPLD).\n  MEMTEST86 TESTS MEMORY MUCH MORE THOROUGLY THAN YOUR BIOSS\n  POWER-ON TEST, AND MAY FIND FAILURES THAT THE BIOS DOESN\'T.\n\n* IF THE ERROR CAN BE REPEATABLY REPRODUCED, THIS IS A BUG IN\n  BZIP2, AND I WOULD VERY MUCH LIKE TO HEAR ABOUT IT.  PLEASE\n  LET ME KNOW, AND, IDEALLY, SAVE A COPY OF THE FILE CAUSING THE\n  PROBLEM -- WITHOUT WHICH I WILL BE UNABLE TO INVESTIGATE IT.\n\n')
     ; babelAssign(__CIL_TMP6_SSA_1, __CIL_TMP6)),
    babel__bzlib_c_3(3). 

:- foreign(babel__bzlib_c_4(+positive,  -integer)).

default_bzalloc(OPAQUE, ITEMS, SIZE, V_SSA_1) :- 

    BabelExp_3 is ITEMS * SIZE,
    babelAssign(__CIL_TMP6_SSA_1, BabelExp_3),
    babel__bzlib_c_4(__CIL_TMP6_SSA_1 , TMP_SSA_1),
    babelAssign(V_SSA_1, TMP_SSA_1),true. 

:- foreign(babel__bzlib_c_5(+integer)).

default_bzfree(OPAQUE, ADDR, VOID) :- 


    (babelJcc(13, ADDR, (0)) ->
         babelAssign(__CIL_TMP3_SSA_1, 1)
     ; babelAssign(__CIL_TMP3_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP3_SSA_1, 0) ->
         babel__bzlib_c_5(ADDR)
     ; true),
    true. 

:- foreign(babel__bzlib_c_6(+integer, +integer)).

prepare_new_block(__CIL_FP_S, __CIL_PP_S, S, VOID) :- 

    babelAssign(__CIL_TMP5_SSA_1, S +1* 108),
    babelAssign(__CIL_TMP6_SSA_1, __CIL_TMP5_SSA_1),
    BabelExp_4 is 0,
    ptrW(__CIL_TMP6_SSA_1, BabelExp_4, 4),
    babelAssign(__CIL_TMP7_SSA_1, S +1* 116),
    babelAssign(__CIL_TMP8_SSA_1, __CIL_TMP7_SSA_1),
    BabelExp_5 is 0,
    ptrW(__CIL_TMP8_SSA_1, BabelExp_5, 4),
    babelAssign(__CIL_TMP9_SSA_1, S +1* 120),
    babelAssign(__CIL_TMP10_SSA_1, __CIL_TMP9_SSA_1),
    BabelExp_6 is 0,
    ptrW(__CIL_TMP10_SSA_1, BabelExp_6, 4),
    babelAssign(__CIL_TMP11_SSA_1, S +1* 648),
    babelAssign(__CIL_TMP12_SSA_1, __CIL_TMP11_SSA_1),
    BabelExp_7 is 4294967295,
    ptrW(__CIL_TMP12_SSA_1, BabelExp_7, 4),
    babelAssign(I_SSA_1, 0),
    BabelExp_8 is S,
    ptrW(__CIL_FP_S, BabelExp_8, 8),
    babel__bzlib_c_6(__CIL_PP_S, I_SSA_1),
    BabelExp_9 is __CIL_FP_S,
    ptrR(S_SSA_1, BabelExp_9, 8),
    babelAssign(__CIL_TMP13_SSA_1, S_SSA_1 +1* 660),
    babelAssign(__CIL_TMP14_SSA_1, __CIL_TMP13_SSA_1),
    BabelExp_10 is __CIL_TMP14_SSA_1,
    ptrR(__CIL_TMP15_SSA_1, BabelExp_10, 4),
    babelAssign(__CIL_TMP16_SSA_1, S_SSA_1 +1* 660),
    babelAssign(__CIL_TMP17_SSA_1, __CIL_TMP16_SSA_1),
    BabelExp_11 is __CIL_TMP15_SSA_1 + 1,
    ptrW(__CIL_TMP17_SSA_1, BabelExp_11, 4),true. 


init_RL(S, VOID) :- 
    __CIL_TMP3_SSA_1 is S +92,
    ptrW(__CIL_TMP3_SSA_1, 256, 4),
    __CIL_TMP5_SSA_1 is S +96,
    ptrW(__CIL_TMP5_SSA_1, 0, 4). 


isempty_RL(S, R) :- 

    babelAssign(__CIL_TMP4_SSA_1, S +1* 92),
    babelAssign(__CIL_TMP5_SSA_1, __CIL_TMP4_SSA_1),
    BabelExp_14 is __CIL_TMP5_SSA_1,
    ptrR(__CIL_TMP6_SSA_1, BabelExp_14, 4),

    (babelJcc(16, __CIL_TMP6_SSA_1, 256) ->
         babelAssign(__CIL_TMP2_SSA_1, 1)
     ; babelAssign(__CIL_TMP2_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP2_SSA_1, 0) ->
         babelAssign(__CIL_TMP7_SSA_1, S +1* 96),
         babelAssign(__CIL_TMP8_SSA_1, __CIL_TMP7_SSA_1),
         BabelExp_15 is __CIL_TMP8_SSA_1,
         ptrR(__CIL_TMP9_SSA_1, BabelExp_15, 4),

         (babelJcc(14, __CIL_TMP9_SSA_1, 0) ->
              babelAssign(__CIL_TMP3_SSA_1, 1)
          ; babelAssign(__CIL_TMP3_SSA_1, 0)),

         (babelJcc(13, __CIL_TMP3_SSA_1, 0) ->
              babelAssign(R, 0),true
          ; babelAssign(R, 1),true)
     ; babelAssign(R, 1),true). 

:- foreign(babel__bzlib_c_7(+integer, +integer)).

copy_output_until_stop(__CIL_FP_PROGRESS_OUT, __CIL_PP_PROGRESS_OUT, S, PROGRESS_OUT_SSA_2) :- 

    babelAssign(PROGRESS_OUT_SSA_1, 0),
    BabelExp_16 is PROGRESS_OUT_SSA_1,
    ptrW(__CIL_FP_PROGRESS_OUT, BabelExp_16, 1),
    babel__bzlib_c_7(__CIL_PP_PROGRESS_OUT, S),
    BabelExp_17 is __CIL_FP_PROGRESS_OUT,
    babelPtrR_byte(PROGRESS_OUT_SSA_2, BabelExp_17, 1),true. 

:- foreign(babel__bzlib_c_8(+integer, +integer, +integer, +integer,  -integer)).

bZ2_bzopen(PATH, MODE, TMP_SSA_1) :- 


    babel__bzlib_c_8(PATH, -1, MODE, 0 , TMP_SSA_1),true. 

:- foreign(babel__bzlib_c_9(+integer, +integer, +integer, +integer,  -integer)).

bZ2_bzdopen(FD, MODE, TMP_SSA_1) :- 


    babel__bzlib_c_9(0, FD, MODE, 1 , TMP_SSA_1),true. 


bZ2_bzflush(B, TMP_SSA_1) :- 
    TMP_SSA_1 is 0.

bZ2_indexIntoF(INDEX, CFTAB, RET):-
    bZ2_indexIntoF_cil_lr_1(256, 0, INDEX, CFTAB, RET).

bZ2_indexIntoF_cil_lr_1(NA, NB_IN, INDEX, CFTAB, NB_OUT):-
    MID is (NA + NB_IN) >> 1,
    T1 is CFTAB + MID * 4,
    ptrR(T2, T1, 4),
    (INDEX >= T2 -> NB_IN_SSA_1 is MID, NA_SSA_1 is NA;
     NB_IN_SSA_1 is NB_IN, NA_SSA_1 is MID),
    (NA_SSA_1 - NB_IN_SSA_1 =:= 1 -> NB_OUT is NB_IN_SSA_1;
     bZ2_indexIntoF_cil_lr_1(NA_SSA_1, NB_IN_SSA_1, INDEX, CFTAB, NB_OUT)).



:- foreign(babel__bzlib_c_11(+integer, +integer,  -integer)).
:- foreign(babel__bzlib_c_12(+integer)).

bZ2_bzbzlib(__CIL_FP___CIL_RET6, __CIL_PP___CIL_RET6, STRM, __CIL_RET6_SSA_1) :- 

    babelAssign(__CIL_RET6, 0),

    (babelJcc(12, STRM, (0)) ->
         babelAssign(__CIL_TMP10_SSA_1, 1)
     ; babelAssign(__CIL_TMP10_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP10_SSA_1, 0) ->
         true
     ; babelAssign(__CIL_TMP13_SSA_1, STRM +1* 48),
       babelAssign(__CIL_TMP14_SSA_1, __CIL_TMP13_SSA_1),
       BabelExp_2 is __CIL_TMP14_SSA_1,
       ptrR(__CIL_TMP15_SSA_1, BabelExp_2, 8),
       babelAssign(S_SSA_1, __CIL_TMP15_SSA_1),

       (babelJcc(12, S_SSA_1, (0)) ->
            babelAssign(__CIL_TMP11_SSA_1, 1)
        ; babelAssign(__CIL_TMP11_SSA_1, 0)),

       (babelJcc(13, __CIL_TMP11_SSA_1, 0) ->
            true
        ; babelAssign(MEM_16, S_SSA_1),
          BabelExp_3 is MEM_16,
          ptrR(__CIL_TMP16_SSA_1, BabelExp_3, 8),
          BabelExp_4 is __CIL_TMP16_SSA_1,
          babelAssign(__CIL_TMP17_SSA_1, BabelExp_4),

          (babelJcc(13, __CIL_TMP17_SSA_1, STRM) ->
               babelAssign(__CIL_TMP12_SSA_1, 1)
           ; babelAssign(__CIL_TMP12_SSA_1, 0)),

          (babelJcc(13, __CIL_TMP12_SSA_1, 0) ->
               true
           ; BabelExp_5 is __CIL_RET6,
             ptrW(__CIL_FP___CIL_RET6, BabelExp_5, 4),
             babel__bzlib_c_11(__CIL_PP___CIL_RET6, S_SSA_1 , RETFLAG7_SSA_1),
             BabelExp_6 is __CIL_FP___CIL_RET6,
             ptrR(__CIL_RET6_SSA_1, BabelExp_6, 4),
             (babelJcc(13, RETFLAG7_SSA_1, 0) ->
                  true
              ; babel__bzlib_c_12(6001),true)))). 



:- foreign(babel__blocksort_c_0(+integer, +integer)).
:- foreign(babel__blocksort_c_1(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer,  -integer)).

mainSimpleSort(__CIL_FP_HP, __CIL_PP_HP, PTR, BLOCK, QUADRANT, NBLOCK, LO, HI, D, BUDGET, VOID) :- 

    BabelExp_0 is HI - LO,
    babelAssign(__CIL_TMP15_SSA_1, BabelExp_0),
    BabelExp_1 is __CIL_TMP15_SSA_1 + 1,
    babelAssign(BIGN_SSA_1, BabelExp_1),

    (babelJcc(16, BIGN_SSA_1, 2) ->
         babelAssign(__CIL_TMP14_SSA_1, 1)
     ; babelAssign(__CIL_TMP14_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP14_SSA_1, 0) ->
         true
     ; babelAssign(HP_SSA_1, 0),
       BabelExp_2 is HP_SSA_1,
       ptrW(__CIL_FP_HP, BabelExp_2, 4),
       babel__blocksort_c_0(__CIL_PP_HP, BIGN_SSA_1),
       BabelExp_3 is __CIL_FP_HP,
       ptrR(HP_SSA_2, BabelExp_3, 4),
       BabelExp_4 is HP_SSA_2 - 1,
       babelAssign(HP_SSA_3, BabelExp_4),
       babel__blocksort_c_1(PTR, BLOCK, QUADRANT, NBLOCK, LO, HI, D, BUDGET, HP_SSA_3 , RETFLAG18_SSA_1),
       (babelJcc(13, RETFLAG18_SSA_1, 0) ->
            true
        ; true)). 

:- foreign(babel__blocksort_c_2(+integer, +integer, +integer, +integer, +integer, +integer,  -integer)).

mainSimpleSort_cil_lr_2_cil_lr_1_cil_lr_1(H, V, J, PTR, BLOCK, QUADRANT, NBLOCK, LO, D, BUDGET, J_OUT):-
    T1 is PTR + (J - H) * 4,
    ptrR(T2, T1, 4),
    A1 is T2 + D,
    A2 is V+D,
    babel__blocksort_c_2(A1, A2, BLOCK, QUADRANT, NBLOCK, BUDGET, RET),
    (
        RET =:= 0 -> J_OUT is J;
        (T3 is PTR + J * 4,
        T4 is PTR + (J - H) * 4,
        ptrR(T5, T4, 4),
        ptrW(T3, T5, 4),
        J_SSA_1 is J - H,
        (
            TMP is LO + H - 1,
            J_SSA_1 =< TMP -> J_OUT is J_SSA_1;
            mainSimpleSort_cil_lr_2_cil_lr_1_cil_lr_1(H, V, J_SSA_1, PTR, BLOCK, QUADRANT, NBLOCK, LO, D, BUDGET, J_OUT)
        ))
    ).


fallbackSort_cil_lr_9_cil_lr_2_cil_lr_1(__CIL_AP_K, __CIL_AP_BHTAB, VOID) :- 

    BabelExp_36 is __CIL_AP_K,
    ptrR(__CIL_TMP5_SSA_1, BabelExp_36, 4),
    BabelExp_37 is __CIL_AP_BHTAB,
    ptrR(__CIL_TMP6_SSA_1, BabelExp_37, 8),
    BabelExp_38 is __CIL_TMP5_SSA_1 >> 5,
    babelAssign(__CIL_TMP7_SSA_1, BabelExp_38),
    babelAssign(__CIL_TMP8_SSA_1, __CIL_TMP6_SSA_1 +4* __CIL_TMP7_SSA_1),
    BabelExp_39 is __CIL_AP_K,
    ptrR(__CIL_TMP9_SSA_1, BabelExp_39, 4),
    BabelExp_40 is __CIL_TMP9_SSA_1 /\ 31,
    babelAssign(__CIL_TMP10_SSA_1, BabelExp_40),
    BabelExp_41 is 1 << __CIL_TMP10_SSA_1,
    babelAssign(__CIL_TMP11_SSA_1, BabelExp_41),
    BabelExp_42 is __CIL_TMP8_SSA_1,
    ptrR(__CIL_TMP12_SSA_1, BabelExp_42, 4),
    BabelExp_43 is __CIL_TMP11_SSA_1,
    babelAssign(__CIL_TMP13_SSA_1, BabelExp_43),
    BabelExp_44 is __CIL_TMP12_SSA_1 /\ __CIL_TMP13_SSA_1,
    babelAssign(__CIL_TMP3_SSA_1, BabelExp_44),
    (babelJcc(13, __CIL_TMP3_SSA_1, 0) ->
         BabelExp_45 is __CIL_AP_K,
         ptrR(__CIL_TMP14_SSA_1, BabelExp_45, 4),
         BabelExp_46 is __CIL_TMP14_SSA_1 /\ 31,
         babelAssign(__CIL_TMP15_SSA_1, BabelExp_46),

         (babelJcc(12, __CIL_TMP15_SSA_1, 0) ->
              babelAssign(__CIL_TMP4_SSA_1, 1)
          ; babelAssign(__CIL_TMP4_SSA_1, 0)),

         (babelJcc(13, __CIL_TMP4_SSA_1, 0) ->
              true
          ; BabelExp_47 is __CIL_AP_K,
            ptrR(__CIL_TMP16_SSA_1, BabelExp_47, 4),
            BabelExp_48 is __CIL_TMP16_SSA_1 + 1,
            ptrW(__CIL_AP_K, BabelExp_48, 4),
            fallbackSort_cil_lr_9_cil_lr_2_cil_lr_1(__CIL_AP_K, __CIL_AP_BHTAB, VOID),true)
     ; true). 


fallbackSort_cil_lr_9_cil_lr_2_cil_lr_2(__CIL_AP_K, __CIL_AP_BHTAB, VOID) :- 

    BabelExp_49 is __CIL_AP_K,
    ptrR(__CIL_TMP4_SSA_1, BabelExp_49, 4),
    BabelExp_50 is __CIL_AP_BHTAB,
    ptrR(__CIL_TMP5_SSA_1, BabelExp_50, 8),
    BabelExp_51 is __CIL_TMP4_SSA_1 >> 5,
    babelAssign(__CIL_TMP6_SSA_1, BabelExp_51),
    babelAssign(__CIL_TMP7_SSA_1, __CIL_TMP5_SSA_1 +4* __CIL_TMP6_SSA_1),
    BabelExp_52 is __CIL_TMP7_SSA_1,
    ptrR(__CIL_TMP8_SSA_1, BabelExp_52, 4),

    (babelJcc(12, __CIL_TMP8_SSA_1, 4294967295) ->
         babelAssign(__CIL_TMP9_SSA_1, 1)
     ; babelAssign(__CIL_TMP9_SSA_1, 0)),


    (babelJcc(12, __CIL_TMP9_SSA_1, 0) ->
         babelAssign(__CIL_TMP3_SSA_1, 1)
     ; babelAssign(__CIL_TMP3_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP3_SSA_1, 0) ->
         true
     ; BabelExp_53 is __CIL_AP_K,
       ptrR(__CIL_TMP10_SSA_1, BabelExp_53, 4),
       BabelExp_54 is __CIL_TMP10_SSA_1 + 32,
       ptrW(__CIL_AP_K, BabelExp_54, 4),
       fallbackSort_cil_lr_9_cil_lr_2_cil_lr_2(__CIL_AP_K, __CIL_AP_BHTAB, VOID),true). 


fallbackSort_cil_lr_9_cil_lr_2_cil_lr_4(__CIL_AP_K, __CIL_AP_BHTAB, VOID) :- 

    BabelExp_55 is __CIL_AP_K,
    ptrR(__CIL_TMP5_SSA_1, BabelExp_55, 4),
    BabelExp_56 is __CIL_AP_BHTAB,
    ptrR(__CIL_TMP6_SSA_1, BabelExp_56, 8),
    BabelExp_57 is __CIL_TMP5_SSA_1 >> 5,
    babelAssign(__CIL_TMP7_SSA_1, BabelExp_57),
    babelAssign(__CIL_TMP8_SSA_1, __CIL_TMP6_SSA_1 +4* __CIL_TMP7_SSA_1),
    BabelExp_58 is __CIL_AP_K,
    ptrR(__CIL_TMP9_SSA_1, BabelExp_58, 4),
    BabelExp_59 is __CIL_TMP9_SSA_1 /\ 31,
    babelAssign(__CIL_TMP10_SSA_1, BabelExp_59),
    BabelExp_60 is 1 << __CIL_TMP10_SSA_1,
    babelAssign(__CIL_TMP11_SSA_1, BabelExp_60),
    BabelExp_61 is __CIL_TMP8_SSA_1,
    ptrR(__CIL_TMP12_SSA_1, BabelExp_61, 4),
    BabelExp_62 is __CIL_TMP11_SSA_1,
    babelAssign(__CIL_TMP13_SSA_1, BabelExp_62),
    BabelExp_63 is __CIL_TMP12_SSA_1 /\ __CIL_TMP13_SSA_1,
    babelAssign(__CIL_TMP14_SSA_1, BabelExp_63),

    (babelJcc(12, __CIL_TMP14_SSA_1, 0) ->
         babelAssign(__CIL_TMP3_SSA_1, 1)
     ; babelAssign(__CIL_TMP3_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP3_SSA_1, 0) ->
         BabelExp_64 is __CIL_AP_K,
         ptrR(__CIL_TMP15_SSA_1, BabelExp_64, 4),
         BabelExp_65 is __CIL_TMP15_SSA_1 /\ 31,
         babelAssign(__CIL_TMP16_SSA_1, BabelExp_65),

         (babelJcc(12, __CIL_TMP16_SSA_1, 0) ->
              babelAssign(__CIL_TMP4_SSA_1, 1)
          ; babelAssign(__CIL_TMP4_SSA_1, 0)),

         (babelJcc(13, __CIL_TMP4_SSA_1, 0) ->
              true
          ; BabelExp_66 is __CIL_AP_K,
            ptrR(__CIL_TMP17_SSA_1, BabelExp_66, 4),
            BabelExp_67 is __CIL_TMP17_SSA_1 + 1,
            ptrW(__CIL_AP_K, BabelExp_67, 4),
            fallbackSort_cil_lr_9_cil_lr_2_cil_lr_4(__CIL_AP_K, __CIL_AP_BHTAB, VOID),true)
     ; true). 


fallbackSort_cil_lr_9_cil_lr_2_cil_lr_5(__CIL_AP_K, __CIL_AP_BHTAB, VOID) :- 

    BabelExp_68 is __CIL_AP_K,
    ptrR(__CIL_TMP4_SSA_1, BabelExp_68, 4),
    BabelExp_69 is __CIL_AP_BHTAB,
    ptrR(__CIL_TMP5_SSA_1, BabelExp_69, 8),
    BabelExp_70 is __CIL_TMP4_SSA_1 >> 5,
    babelAssign(__CIL_TMP6_SSA_1, BabelExp_70),
    babelAssign(__CIL_TMP7_SSA_1, __CIL_TMP5_SSA_1 +4* __CIL_TMP6_SSA_1),
    BabelExp_71 is __CIL_TMP7_SSA_1,
    ptrR(__CIL_TMP8_SSA_1, BabelExp_71, 4),

    (babelJcc(12, __CIL_TMP8_SSA_1, 0) ->
         babelAssign(__CIL_TMP9_SSA_1, 1)
     ; babelAssign(__CIL_TMP9_SSA_1, 0)),


    (babelJcc(12, __CIL_TMP9_SSA_1, 0) ->
         babelAssign(__CIL_TMP3_SSA_1, 1)
     ; babelAssign(__CIL_TMP3_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP3_SSA_1, 0) ->
         true
     ; BabelExp_72 is __CIL_AP_K,
       ptrR(__CIL_TMP10_SSA_1, BabelExp_72, 4),
       BabelExp_73 is __CIL_TMP10_SSA_1 + 32,
       ptrW(__CIL_AP_K, BabelExp_73, 4),
       fallbackSort_cil_lr_9_cil_lr_2_cil_lr_5(__CIL_AP_K, __CIL_AP_BHTAB, VOID),true). 


fallbackSort_cil_lr_9_cil_lr_2_cil_lr_7(__CIL_AP_R, __CIL_AP_FMAP, __CIL_AP_ECLASS, __CIL_AP_BHTAB, CC, I, VOID) :- 

    BabelExp_74 is 0,
    babelAssign(__CIL_TMP18, BabelExp_74),
    BabelExp_75 is 0,
    babelAssign(__CIL_TMP20, BabelExp_75),
    babelAssign(__CIL_TMP21, 0),
    babelAssign(__CIL_TMP22, 0),
    babelAssign(__CIL_TMP24, 0),
    BabelExp_76 is 0,
    babelAssign(__CIL_TMP25, BabelExp_76),
    BabelExp_77 is 0,
    babelAssign(__CIL_TMP27, BabelExp_77),
    BabelExp_78 is __CIL_AP_R,
    ptrR(__CIL_TMP10_SSA_1, BabelExp_78, 4),

    (babelJcc(15, I, __CIL_TMP10_SSA_1) ->
         babelAssign(__CIL_TMP11_SSA_1, 1)
     ; babelAssign(__CIL_TMP11_SSA_1, 0)),


    (babelJcc(12, __CIL_TMP11_SSA_1, 0) ->
         babelAssign(__CIL_TMP8_SSA_1, 1)
     ; babelAssign(__CIL_TMP8_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP8_SSA_1, 0) ->
         true
     ; BabelExp_79 is __CIL_AP_FMAP,
       ptrR(__CIL_TMP12_SSA_1, BabelExp_79, 8),
       babelAssign(__CIL_TMP13_SSA_1, __CIL_TMP12_SSA_1 +4* I),
       BabelExp_80 is __CIL_AP_ECLASS,
       ptrR(__CIL_TMP14_SSA_1, BabelExp_80, 8),
       BabelExp_81 is __CIL_TMP13_SSA_1,
       ptrR(__CIL_TMP15_SSA_1, BabelExp_81, 4),
       babelAssign(__CIL_TMP16_SSA_1, __CIL_TMP14_SSA_1 +4* __CIL_TMP15_SSA_1),
       BabelExp_82 is __CIL_TMP16_SSA_1,
       ptrR(__CIL_TMP17_SSA_1, BabelExp_82, 4),
       BabelExp_83 is __CIL_TMP17_SSA_1,
       babelAssign(CC1_SSA_1, BabelExp_83),

       (babelJcc(13, CC, CC1_SSA_1) ->
            babelAssign(__CIL_TMP9_SSA_1, 1)
        ; babelAssign(__CIL_TMP9_SSA_1, 0)),

       (babelJcc(13, __CIL_TMP9_SSA_1, 0) ->
            BabelExp_84 is __CIL_AP_BHTAB,
            ptrR(__CIL_TMP18_SSA_1, BabelExp_84, 8),
            BabelExp_85 is I >> 5,
            babelAssign(__CIL_TMP19_SSA_1, BabelExp_85),
            babelAssign(__CIL_TMP20_SSA_1, __CIL_TMP18_SSA_1 +4* __CIL_TMP19_SSA_1),
            BabelExp_86 is I /\ 31,
            babelAssign(__CIL_TMP21_SSA_1, BabelExp_86),
            BabelExp_87 is 1 << __CIL_TMP21_SSA_1,
            babelAssign(__CIL_TMP22_SSA_1, BabelExp_87),
            BabelExp_88 is __CIL_TMP20_SSA_1,
            ptrR(__CIL_TMP23_SSA_1, BabelExp_88, 4),
            BabelExp_89 is __CIL_TMP22_SSA_1,
            babelAssign(__CIL_TMP24_SSA_1, BabelExp_89),
            BabelExp_90 is __CIL_AP_BHTAB,
            ptrR(__CIL_TMP25_SSA_1, BabelExp_90, 8),
            BabelExp_91 is I >> 5,
            babelAssign(__CIL_TMP26_SSA_1, BabelExp_91),
            babelAssign(__CIL_TMP27_SSA_1, __CIL_TMP25_SSA_1 +4* __CIL_TMP26_SSA_1),
            BabelExp_92 is __CIL_TMP23_SSA_1 \/ __CIL_TMP24_SSA_1,
            ptrW(__CIL_TMP27_SSA_1, BabelExp_92, 4),
            babelAssign(CC_SSA_1, CC1_SSA_1)
        ; babelAssign(__CIL_TMP18_SSA_1, __CIL_TMP18),
          babelAssign(__CIL_TMP19_SSA_1, __CIL_TMP19),
          babelAssign(__CIL_TMP20_SSA_1, __CIL_TMP20),
          babelAssign(__CIL_TMP21_SSA_1, __CIL_TMP21),
          babelAssign(__CIL_TMP22_SSA_1, __CIL_TMP22),
          babelAssign(__CIL_TMP23_SSA_1, __CIL_TMP23),
          babelAssign(__CIL_TMP24_SSA_1, __CIL_TMP24),
          babelAssign(__CIL_TMP25_SSA_1, __CIL_TMP25),
          babelAssign(__CIL_TMP26_SSA_1, __CIL_TMP26),
          babelAssign(__CIL_TMP27_SSA_1, __CIL_TMP27),
          babelAssign(CC_SSA_1, CC)),
       BabelExp_93 is I + 1,
       babelAssign(I_SSA_1, BabelExp_93),
       fallbackSort_cil_lr_9_cil_lr_2_cil_lr_7(__CIL_AP_R, __CIL_AP_FMAP, __CIL_AP_ECLASS, __CIL_AP_BHTAB, CC_SSA_1, I_SSA_1, VOID),true),
    BabelExp_94 is I + 1,
    babelAssign(I_SSA_1, BabelExp_94),
    fallbackSort_cil_lr_9_cil_lr_2_cil_lr_7(__CIL_AP_R, __CIL_AP_FMAP, __CIL_AP_ECLASS, __CIL_AP_BHTAB, CC, I_SSA_1, VOID),true. 


fallbackSort_cil_lr_10_cil_lr_1(__CIL_AP_J, FTABCOPY, VOID) :- 

    BabelExp_95 is __CIL_AP_J,
    ptrR(__CIL_TMP4_SSA_1, BabelExp_95, 4),
    babelAssign(__CIL_TMP5_SSA_1, FTABCOPY +4* __CIL_TMP4_SSA_1),
    BabelExp_96 is __CIL_TMP5_SSA_1,
    ptrR(__CIL_TMP6_SSA_1, BabelExp_96, 4),

    (babelJcc(12, __CIL_TMP6_SSA_1, 0) ->
         babelAssign(__CIL_TMP7_SSA_1, 1)
     ; babelAssign(__CIL_TMP7_SSA_1, 0)),


    (babelJcc(12, __CIL_TMP7_SSA_1, 0) ->
         babelAssign(__CIL_TMP3_SSA_1, 1)
     ; babelAssign(__CIL_TMP3_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP3_SSA_1, 0) ->
         true
     ; BabelExp_97 is __CIL_AP_J,
       ptrR(__CIL_TMP8_SSA_1, BabelExp_97, 4),
       BabelExp_98 is __CIL_TMP8_SSA_1 + 1,
       ptrW(__CIL_AP_J, BabelExp_98, 4),
       fallbackSort_cil_lr_10_cil_lr_1(__CIL_AP_J, FTABCOPY, VOID),true). 

:- foreign(babel__blocksort_c_3(+integer, +integer, +integer, +integer, +positive)).
:- foreign(babel__blocksort_c_4(+integer, +integer, +integer, +integer, +integer)).

fallbackSimpleSort_cil_lr_2(__CIL_FP_FMAP, __CIL_FP_ECLASS, __CIL_FP_HI, __CIL_FP_J, __CIL_PP_FMAP, __CIL_PP_ECLASS, __CIL_PP_HI, __CIL_PP_J, FMAP, ECLASS, LO, HI, I, VOID) :- 


    (babelJcc(17, I, LO) ->
         babelAssign(__CIL_TMP18_SSA_1, 1)
     ; babelAssign(__CIL_TMP18_SSA_1, 0)),


    (babelJcc(12, __CIL_TMP18_SSA_1, 0) ->
         babelAssign(__CIL_TMP17_SSA_1, 1)
     ; babelAssign(__CIL_TMP17_SSA_1, 0)),

    (babelJcc(13, __CIL_TMP17_SSA_1, 0) ->
         true
     ; babelAssign(__CIL_TMP19_SSA_1, FMAP +4* I),
       BabelExp_99 is __CIL_TMP19_SSA_1,
       ptrR(__CIL_TMP20_SSA_1, BabelExp_99, 4),
       BabelExp_100 is __CIL_TMP20_SSA_1,
       babelAssign(TMP_SSA_1, BabelExp_100),
       babelAssign(__CIL_TMP21_SSA_1, ECLASS +4* TMP_SSA_1),
       BabelExp_101 is __CIL_TMP21_SSA_1,
       ptrR(EC_TMP_SSA_1, BabelExp_101, 4),
       BabelExp_102 is I + 1,
       babelAssign(J_SSA_1, BabelExp_102),
       BabelExp_103 is FMAP,
       ptrW(__CIL_FP_FMAP, BabelExp_103, 8),
       BabelExp_104 is ECLASS,
       ptrW(__CIL_FP_ECLASS, BabelExp_104, 8),
       BabelExp_105 is HI,
       ptrW(__CIL_FP_HI, BabelExp_105, 4),
       BabelExp_106 is J_SSA_1,
       ptrW(__CIL_FP_J, BabelExp_106, 4),
       babel__blocksort_c_3(__CIL_PP_FMAP, __CIL_PP_ECLASS, __CIL_PP_HI, __CIL_PP_J, EC_TMP_SSA_1),
       BabelExp_107 is __CIL_FP_FMAP,
       ptrR(FMAP_SSA_1, BabelExp_107, 8),
       BabelExp_108 is __CIL_FP_ECLASS,
       ptrR(ECLASS_SSA_1, BabelExp_108, 8),
       BabelExp_109 is __CIL_FP_HI,
       ptrR(HI_SSA_1, BabelExp_109, 4),
       BabelExp_110 is __CIL_FP_J,
       ptrR(J_SSA_2, BabelExp_110, 4),
       BabelExp_111 is J_SSA_2 - 1,
       babelAssign(__CIL_TMP22_SSA_1, BabelExp_111),
       babelAssign(__CIL_TMP23_SSA_1, FMAP_SSA_1 +4* __CIL_TMP22_SSA_1),
       BabelExp_112 is TMP_SSA_1,
       ptrW(__CIL_TMP23_SSA_1, BabelExp_112, 4),
       BabelExp_113 is I - 1,
       babelAssign(I_SSA_1, BabelExp_113),
       babel__blocksort_c_4(FMAP_SSA_1, ECLASS_SSA_1, LO, HI_SSA_1, I_SSA_1),true). 

bsFinishWrite(S):-
    (T1 is S + 644,
    ptrR(T2, T1, 4)),
    T2 =< 0 -> true;
    T3 is S + 640,
    ptrR(T4, T3, 4),
    T5 is T4 >> 24,
    T6 is S + 80,
    ptrR(T7, T6, 8),
    T8 is S + 116,
    ptrR(T9, T8, 4),
    T10 is T7 + T9,
    ptrW(T10, T5, 1),
    T11 is T9 + 1,
    ptrW(T8, T11, 4),
    T12 is S + 640,
    ptrR(T13, T12, 4),
    T14 is T13 << 8,
    ptrW(T12, T14, 4),
    T15 is S + 644,
    ptrR(T16, T15, 4),
    T17 is T16 - 8,
    ptrW(T15, T17, 4),
    bsFinishWrite(S).

:-foreign(bzlib_c_0(+integer)).

flush_RL(S):-
    T1 is S + 92,
    ptrR(T2, T1, 4),
    (T2 < 256 -> bzlib_c_0(S);true),
    init_RL(S, VOID).
