babelJcc(OP, L, R) :-
    (  OP =:= 12 -> L =:= R
    ;  OP =:= 13 -> L \= R
    ;  OP =:= 14 -> L > R
    ;  OP =:= 15 -> L =< R
    ;  OP =:= 16 -> L < R
    ;  OP =:= 17 -> L >= R
    ).

:-foreign(babel_ptrR(-integer, +integer, +integer)).
:-foreign(babel_ptrE(+integer, +integer, +integer)).

babelPtrR(E, P, L) :- babel_ptrR(T, P, L), E is T.
babelPtrL(P, E, L) :- babel_ptrE(P, E, L).

babelAssign(Var, Val) :- Var is Val.
babelAssignStr(Var, Val) :- Var = Val.
babelAssignBool(Var, Val) :- Var = Val.

babelArrayL([_\/T], 0, X, [X\/T]).
babelArrayL([H\/T], I, X, [H\/R]):- I > -1, NI is I-1, babelArrayL(T, NI, X, R), !.
babelArrayL(L, _, _, L).

babelArrayR(X, [X\/_], 0).
babelArrayR(X, [_\/T], I):- I > 0, NI is I-1, babelArrayR(X, T, NI), !.
:- foreign(babel__implicit_regtailc_0(+integer, +integer)).

regtail(__CIL_PP_VAL, __CIL_PP_SCAN, __CIL_FP_VAL, __CIL_FP_SCAN, CP, P, VAL, VOID) :- 


 babelAssign(__CIL_TMP17, CP +1* 16),
babelAssign(__CIL_TMP18, __CIL_TMP17),
BabelExp_0 is __CIL_TMP18,
babelPtrR(__CIL_TMP23, BabelExp_0, 8),
babelAssign(__CIL_TMP20, CP +1* 24),
babelAssign(__CIL_TMP24, __CIL_TMP20),

(babelJcc(12, __CIL_TMP23, __CIL_TMP24) ->
babelAssign(__CIL_TMP15, 1)
; babelAssign(__CIL_TMP15, 0)),

(babelJcc(13, __CIL_TMP15, 0) ->
True
; babelAssign(SCAN_SSA_1, P),
BabelExp_2 is SCAN_SSA_1,
babelPtrL(__CIL_FP_SCAN, BabelExp_2, 8),
babel__implicit_regtailc_0(__CIL_PP_VAL, __CIL_PP_SCAN),
babelPtrR(VAL_SSA_1, __CIL_FP_VAL, 8),
babelPtrR(SCAN_SSA_2, __CIL_FP_SCAN, 8),
babelPtrR(__CIL_TMP25, SCAN_SSA_2, 1),
babelAssign(__CIL_TMP26, __CIL_TMP25),

(babelJcc(12, __CIL_TMP26, 7) ->
babelAssign(__CIL_TMP16, 1)
; babelAssign(__CIL_TMP16, 0)),

(babelJcc(13, __CIL_TMP16, 0) ->
BabelExp_6 is SCAN_SSA_2 - VAL_SSA_1,
babelAssign(__CIL_TMP27, BabelExp_6),
babelAssign(OFFSET_SSA_1, __CIL_TMP27)
; BabelExp_7 is VAL_SSA_1 - SCAN_SSA_2,
babelAssign(__CIL_TMP28, BabelExp_7),
babelAssign(OFFSET_SSA_1, __CIL_TMP28)),
BabelExp_8 is OFFSET_SSA_1 >> 8,
babelAssign(__CIL_TMP29, BabelExp_8),
BabelExp_9 is __CIL_TMP29 /\ 127,
babelAssign(__CIL_TMP30, BabelExp_9),
babelAssign(__CIL_TMP31, SCAN_SSA_2 +1* 1),
BabelExp_10 is __CIL_TMP30,
babelPtrL(__CIL_TMP31, BabelExp_10, 1),
BabelExp_11 is OFFSET_SSA_1 /\ 255,
babelAssign(__CIL_TMP32, BabelExp_11),
babelAssign(__CIL_TMP33, SCAN_SSA_2 +1* 2),
BabelExp_12 is __CIL_TMP32,
babelPtrL(__CIL_TMP33, BabelExp_12, 1)).

 :- foreign(babel__implicit_regoptailc_1(+integer, +integer, +integer)).

regoptail(CP, P, VAL, VOID) :- 


 babelAssign(__CIL_TMP6, CP +1* 16),
babelAssign(__CIL_TMP7, __CIL_TMP6),
BabelExp_18 is __CIL_TMP7,
babelPtrR(__CIL_TMP8, BabelExp_18, 8),
babelAssign(__CIL_TMP9, CP +1* 24),
babelAssign(__CIL_TMP10, __CIL_TMP9),
babelAssign(__CIL_TMP11, __CIL_TMP10),
babelAssign(__CIL_TMP12, __CIL_TMP8),
babelAssign(__CIL_TMP13, __CIL_TMP11),

(babelJcc(13, __CIL_TMP12, __CIL_TMP13) ->
babelAssign(__CIL_TMP14, 1)
; babelAssign(__CIL_TMP14, 0)),


(babelJcc(12, __CIL_TMP14, 0) ->
babelAssign(__CIL_TMP4, 1)
; babelAssign(__CIL_TMP4, 0)),

(babelJcc(13, __CIL_TMP4, 0) ->
True
; BabelExp_19 is P,
babelPtrR(__CIL_TMP15, BabelExp_19, 1),
babelAssign(__CIL_TMP16, __CIL_TMP15),

(babelJcc(13, __CIL_TMP16, 6) ->
babelAssign(__CIL_TMP5, 1)
; babelAssign(__CIL_TMP5, 0)),

(babelJcc(13, __CIL_TMP5, 0) ->
True
; babelAssign(__CIL_TMP17, P +1* 3),
babel__implicit_regoptailc_1(CP, __CIL_TMP17, VAL))). 

 :- foreign(babel__implicit_regtryc_2(+integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_regtryc_3(+integer, +integer,  -integer)).

regtry(__CIL_PP_EP, __CIL_PP_PROG, __CIL_PP_STRING, __CIL_FP_EP, __CIL_FP_PROG, __CIL_FP_STRING, EP, PROG, STRING, R) :- 


 babelAssign(MEM_30, EP),
BabelExp_20 is STRING,
babelPtrL(MEM_30, BabelExp_20, 8),
babelAssign(MEM_31, PROG),
babelAssign(STP_SSA_1, MEM_31),
babelAssign(__CIL_TMP23, PROG +1* 80),
babelAssign(__CIL_TMP24, __CIL_TMP23),
babelAssign(ENP_SSA_1, __CIL_TMP24),
babelAssign(I_SSA_1, 10),
BabelExp_21 is EP,
babelPtrL(__CIL_FP_EP, BabelExp_21, 8),
BabelExp_22 is PROG,
babelPtrL(__CIL_FP_PROG, BabelExp_22, 8),
BabelExp_23 is STRING,
babelPtrL(__CIL_FP_STRING, BabelExp_23, 8),
babel__implicit_regtryc_2(__CIL_PP_EP, __CIL_PP_PROG, __CIL_PP_STRING, I_SSA_1, STP_SSA_1, ENP_SSA_1),
BabelExp_24 is __CIL_FP_EP,
babelPtrR(EP_SSA_1, BabelExp_24, 8),
BabelExp_25 is __CIL_FP_PROG,
babelPtrR(PROG_SSA_1, BabelExp_25, 8),
BabelExp_26 is __CIL_FP_STRING,
babelPtrR(STRING_SSA_1, BabelExp_26, 8),
babelAssign(__CIL_TMP25, PROG_SSA_1 +1* 180),
babelAssign(__CIL_TMP26, __CIL_TMP25),
babelAssign(__CIL_TMP27, __CIL_TMP26),
babelAssign(__CIL_TMP28, __CIL_TMP27 +1* 1),
babel__implicit_regtryc_3(EP_SSA_1, __CIL_TMP28 , TMP___1_SSA_1),
(babelJcc(13, TMP___1_SSA_1, 0) ->
babelAssign(MEM_32, PROG_SSA_1),
babelAssign(__CIL_TMP29, MEM_32),
babelAssign(__CIL_TMP30, __CIL_TMP29),
BabelExp_27 is STRING_SSA_1,
babelPtrL(__CIL_TMP30, BabelExp_27, 8),
babelAssign(__CIL_TMP31, PROG_SSA_1 +1* 80),
babelAssign(__CIL_TMP32, __CIL_TMP31),
babelAssign(__CIL_TMP33, __CIL_TMP32),
babelAssign(__CIL_TMP34, __CIL_TMP33),
babelAssign(MEM_33, EP_SSA_1),
babelPtrR(BabelExp_28, MEM_33, 8),
babelPtrL(__CIL_TMP34, BabelExp_28, 8),
babelAssign(R, 1),True
; babelAssign(R, 0),True). 

 :- foreign(babel__implicit_regrepeatc_4(+integer,  -positive)).
:- foreign(babel__implicit_regrepeatc_5(+integer, +integer, +char)).
:- foreign(babel__implicit_regrepeatc_6(+integer, +integer,  -positive)).
:- foreign(babel__implicit_regrepeatc_7(+integer, +integer,  -positive)).
:- foreign(babel__implicit_regrepeatc_8(+integer)).

regrepeat(__CIL_PP_COUNT, __CIL_FP_COUNT, EP, NODE, TMP_SSA_1) :- 


 BabelExp_29 is NODE,
babelPtrR(NV_SSA_1, BabelExp_29, 1),

(babelJcc(12, NV_SSA_1, 3) ->
babelAssign(__CIL_TMP20, 1)
; babelAssign(__CIL_TMP20, 0)),

(babelJcc(13, __CIL_TMP20, 0) ->
babelAssign(MEM_24, EP),
BabelExp_30 is MEM_24,
babelPtrR(__CIL_TMP24, BabelExp_30, 8),
babel__implicit_regrepeatc_4(__CIL_TMP24 , TMP_SSA_1),True
; (babelJcc(12, NV_SSA_1, 8) ->
babelAssign(__CIL_TMP21, 1)
; babelAssign(__CIL_TMP21, 0)),

(babelJcc(13, __CIL_TMP21, 0) ->
babelAssign(__CIL_TMP25, NODE +1* 3),
BabelExp_31 is __CIL_TMP25,
babelPtrR(CH_SSA_1, BabelExp_31, 1),
babelAssign(COUNT_SSA_1, 0),
babelAssign(MEM_25, EP),
BabelExp_32 is MEM_25,
babelPtrR(SCAN_SSA_1, BabelExp_32, 8),
BabelExp_33 is COUNT_SSA_1,
babelPtrL(__CIL_FP_COUNT, BabelExp_33, 8),
babel__implicit_regrepeatc_5(__CIL_PP_COUNT, SCAN_SSA_1, CH_SSA_1),
BabelExp_34 is __CIL_FP_COUNT,
babelPtrR(COUNT_SSA_2, BabelExp_34, 8),
babelAssign(TMP_SSA_1, COUNT_SSA_2),True
; (babelJcc(12, NV_SSA_1, 4) ->
babelAssign(__CIL_TMP22, 1)
; babelAssign(__CIL_TMP22, 0)),

(babelJcc(13, __CIL_TMP22, 0) ->
babelAssign(MEM_26, EP),
BabelExp_35 is MEM_26,
babelPtrR(__CIL_TMP26, BabelExp_35, 8),
babelAssign(__CIL_TMP27, NODE +1* 3),
babel__implicit_regrepeatc_6(__CIL_TMP26, __CIL_TMP27 , TMP___0_SSA_1),
babelAssign(TMP_SSA_1, TMP___0_SSA_1),True
; (babelJcc(12, NV_SSA_1, 5) ->
babelAssign(__CIL_TMP23, 1)
; babelAssign(__CIL_TMP23, 0)),

(babelJcc(13, __CIL_TMP23, 0) ->
babelAssign(MEM_27, EP),
BabelExp_36 is MEM_27,
babelPtrR(__CIL_TMP28, BabelExp_36, 8),
babelAssign(__CIL_TMP29, NODE +1* 3),
babel__implicit_regrepeatc_7(__CIL_TMP28, __CIL_TMP29 , TMP___1_SSA_1),
babelAssign(TMP_SSA_1, TMP___1_SSA_1),True
; babel__implicit_regrepeatc_8('INTERNAL ERROR: BAD CALL OF REGREPEAT'),
babelAssign(TMP_SSA_1, 0),True)))). 

regnext(P, R) :-
    P1 is P+1,
    babel_ptrR(T1, P1, 1),
    T2 is (T1/\127) << 8,
    P2 is P+2,
    babel_ptrR(T3, P2, 1),
    T4 is T3/\255,
    T5 is T2+T4,
    (T5 =:= 0 -> R is 0; (babel_ptrR(T6, P, 1), (T6 =:= 7 -> R is P-T5; R is P+T5))).

:- foreign(babel__implicit_reg_cil_lr_1c_9(+integer, +integer,  -integer)).
:- foreign(babel__implicit_reg_cil_lr_1c_10(+integer, +integer, +integer)).
:- foreign(babel__implicit_reg_cil_lr_1c_11(+integer, +integer, +integer, +integer, +integer, +integer, +integer,  -integer)).

reg_cil_lr_1(__CIL_PP_FLAGS, __CIL_FP_FLAGS, __CIL_AP_CP, __CIL_AP_PAREN, __CIL_AP_RET, __CIL_AP_PARNO, __CIL_AP___CIL_RET13, FLAGP, FLAGS, RETFLAG9_SSA_1) :- 


 BabelExp_44 is __CIL_AP_CP,
babelPtrR(__CIL_TMP17, BabelExp_44, 8),
babelAssign(__CIL_TMP18, __CIL_TMP17),
BabelExp_45 is __CIL_TMP18,
babelPtrR(__CIL_TMP19, BabelExp_45, 8),
BabelExp_46 is __CIL_TMP19,
babelPtrR(__CIL_TMP20, BabelExp_46, 1),
babelAssign(__CIL_TMP21, __CIL_TMP20),

(babelJcc(12, __CIL_TMP21, 124) ->
babelAssign(__CIL_TMP15, 1)
; babelAssign(__CIL_TMP15, 0)),

(babelJcc(13, __CIL_TMP15, 0) ->
BabelExp_47 is __CIL_AP_CP,
babelPtrR(__CIL_TMP22, BabelExp_47, 8),
babelAssign(__CIL_TMP23, __CIL_TMP22),
BabelExp_48 is __CIL_TMP23,
babelPtrR(__CIL_TMP24, BabelExp_48, 8),
BabelExp_49 is __CIL_AP_CP,
babelPtrR(__CIL_TMP25, BabelExp_49, 8),
babelAssign(__CIL_TMP26, __CIL_TMP25),
BabelExp_50 is __CIL_TMP24 + 1,
babelPtrL(__CIL_TMP26, BabelExp_50, 8),
BabelExp_51 is __CIL_AP_CP,
babelPtrR(__CIL_TMP27, BabelExp_51, 8),
babel__implicit_reg_cil_lr_1c_9(__CIL_TMP27, __CIL_PP_FLAGS , BR_SSA_1),
BabelExp_52 is __CIL_FP_FLAGS,
babelPtrR(FLAGS_SSA_1, BabelExp_52, 4),

(babelJcc(12, BR_SSA_1, (0)) ->
babelAssign(__CIL_TMP16, 1)
; babelAssign(__CIL_TMP16, 0)),

(babelJcc(13, __CIL_TMP16, 0) ->
BabelExp_53 is 0,
babelPtrL(__CIL_AP___CIL_RET13, BabelExp_53, 8),
babelAssign(RETFLAG9_SSA_1, 1),True
; BabelExp_54 is __CIL_AP_CP,
babelPtrR(__CIL_TMP28, BabelExp_54, 8),
BabelExp_55 is __CIL_AP_RET,
babelPtrR(__CIL_TMP29, BabelExp_55, 8),
babel__implicit_reg_cil_lr_1c_10(__CIL_TMP28, __CIL_TMP29, BR_SSA_1),
BabelExp_56 is \ (FLAGS_SSA_1 /\ 1),
babelAssign(__CIL_TMP30, BabelExp_56),
BabelExp_57 is FLAGP,
babelPtrR(__CIL_TMP31, BabelExp_57, 4),

(babelJcc(12, __CIL_TMP30, 0) ->
babelAssign(__CIL_TMP32, 1)
; babelAssign(__CIL_TMP32, 0)),

BabelExp_58 is __CIL_TMP31 /\ __CIL_TMP32,
babelPtrL(FLAGP, BabelExp_58, 4),
BabelExp_59 is FLAGP,
babelPtrR(__CIL_TMP33, BabelExp_59, 4),
BabelExp_60 is FLAGS_SSA_1 /\ 4,
babelAssign(__CIL_TMP34, BabelExp_60),
BabelExp_61 is __CIL_TMP33 \/ __CIL_TMP34,
babelPtrL(FLAGP, BabelExp_61, 4),
babel__implicit_reg_cil_lr_1c_11(__CIL_AP_CP, __CIL_AP_PAREN, __CIL_AP_RET, 
	__CIL_AP_PARNO, __CIL_AP___CIL_RET13, FLAGP, FLAGS_SSA_1 , RETFLAG9_SSA_1))
; babelAssign(RETFLAG9_SSA_1, 0),True). 

:- foreign(babel__implicit_reg_cil_lr_2c_12(+integer, +integer, +integer)).
:- foreign(babel__implicit_reg_cil_lr_2c_13(+integer,  -integer)).

reg_cil_lr_2(__CIL_AP_CP, __CIL_AP_PAREN, __CIL_AP_RET, BR, ENDER, VOID) :- 


 (babelJcc(13, BR, (0)) ->
babelAssign(__CIL_TMP7, 1)
; babelAssign(__CIL_TMP7, 0)),

(babelJcc(12, __CIL_TMP7, 0) -> True;
BabelExp_62 is __CIL_AP_CP,
babelPtrR(__CIL_TMP8, BabelExp_62, 8),
babel__implicit_reg_cil_lr_2c_12(__CIL_TMP8, BR, ENDER),
babel__implicit_reg_cil_lr_2c_13(BR , BR_SSA_1),
reg_cil_lr_2(__CIL_AP_CP, __CIL_AP_PAREN, __CIL_AP_RET, BR_SSA_1, ENDER, VOID)
).

 :- foreign(babel__implicit_regcomp_cil_lr_1c_14(+integer,  -positive)).
:- foreign(babel__implicit_regcomp_cil_lr_1c_15(+integer,  -positive)).
:- foreign(babel__implicit_regcomp_cil_lr_1c_16(+integer,  -integer)).
:- foreign(babel__implicit_regcomp_cil_lr_1c_17(+integer,  -integer)).

regcomp_cil_lr_1(__CIL_AP_R, __CIL_AP_LONGEST, __CIL_AP_LEN, SCAN, VOID) :- 
(babelJcc(13, SCAN, (0)) -> 
   babelAssign(__CIL_TMP8, 1);
   babelAssign(__CIL_TMP8, 0)),
(babelJcc(12, __CIL_TMP8, 0) ->
	True;
    BabelExp_63 is SCAN, babelPtrR(__CIL_TMP11, BabelExp_63, 1), babelAssign(__CIL_TMP12, __CIL_TMP11),
    (babelJcc(12, __CIL_TMP12, 8) ->
        babelAssign(__CIL_TMP9, 1); 
        babelAssign(__CIL_TMP9, 0)),
    (babelJcc(13, __CIL_TMP9, 0) -> 
        babelAssign(__CIL_TMP13, SCAN +1* 3), babel__implicit_regcomp_cil_lr_1c_14(__CIL_TMP13 , TMP___2_SSA_1), BabelExp_64 is __CIL_AP_LEN, babelPtrR(__CIL_TMP14, BabelExp_64, 8), 
        (babelJcc(17, TMP___2_SSA_1, __CIL_TMP14) -> 
            babelAssign(__CIL_TMP10, 1); 
            babelAssign(__CIL_TMP10, 0)),
            (babelJcc(13, __CIL_TMP10, 0) ->
                BabelExp_65 is SCAN + 3, babelPtrL(__CIL_AP_LONGEST, BabelExp_65, 8),babelAssign(__CIL_TMP15, SCAN +1* 3),babel__implicit_regcomp_cil_lr_1c_15(__CIL_TMP15 , TMP),BabelExp_66 is TMP,babelPtrL(__CIL_AP_LEN, BabelExp_66, 8); 
                True); 
         True),
     babel__implicit_regcomp_cil_lr_1c_16(SCAN , SCAN_SSA_1),
     regcomp_cil_lr_1(__CIL_AP_R, __CIL_AP_LONGEST, __CIL_AP_LEN, SCAN_SSA_1, VOID)).

 
