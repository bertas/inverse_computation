babelJcc(OP, L, R) :-
    (  OP =:= 12 -> L =:= R
       ;  OP =:= 13 -> L \= R
       ;  OP =:= 14 -> L > R
       ;  OP =:= 15 -> L =< R
       ;  OP =:= 16 -> L < R
       ;  OP =:= 17 -> L >= R
    ).

:-foreign(ptrR(-integer, +integer, +integer)).
:-foreign(ptrW(+integer, +integer, +integer)).
:-foreign(ptrRF(-float, +integer)).
:-foreign(ptrWF(+integer, +float)).

babelAssign(Var, Val) :- Var is Val.



:- foreign(babel__implicit_distribute_alpha_t_greedily_cil_lr_2_cil_lr_3c_0(+integer, +integer, +integer,  -float)).

distribute_alpha_t_greedily_cil_lr_2_cil_lr_3(__CIL_AP_SV2DNUM, __CIL_AP_SVNUM, __CIL_AP_DOCS, __CIL_AP_DOCNUM, __CIL_AP_KERNEL_PARM, __CIL_AP_LEARN_PARM, __CIL_AP_THRESH, __CIL_AP_D, __CIL_AP_INIT_VAL_SQ, __CIL_AP_INIT_VAL_LIN, __CIL_AP_ALLSKIP, __CIL_AP_CACHE, BEST_EX, K, VOID) :- 
    BabelExp_0 is __CIL_AP_SVNUM,
    ptrR(__CIL_TMP19, BabelExp_0, 8),

    (babelJcc(16, K, __CIL_TMP19) ->
         babelAssign(__CIL_TMP18, 1)
     ; babelAssign(__CIL_TMP18, 0)),

    (babelJcc(13, __CIL_TMP18, 0) ->
         BabelExp_1 is __CIL_AP_D,
         ptrR(__CIL_TMP20, BabelExp_1, 8),
         babelAssign(__CIL_TMP21, (BEST_EX +8* __CIL_TMP20)),
         BabelExp_2 is __CIL_AP_SV2DNUM,
         ptrR(__CIL_TMP22, BabelExp_2, 8),
         BabelExp_3 is __CIL_TMP21,
         ptrR(__CIL_TMP23, BabelExp_3, 8),
         babelAssign(__CIL_TMP24, __CIL_TMP22 +8* __CIL_TMP23),
         BabelExp_4 is __CIL_AP_DOCS,
         ptrR(__CIL_TMP25, BabelExp_4, 8),
         BabelExp_5 is __CIL_TMP24,
         ptrR(__CIL_TMP26, BabelExp_5, 8),
         babelAssign(__CIL_TMP27, __CIL_TMP25 +1* __CIL_TMP26),
         BabelExp_6 is __CIL_AP_SV2DNUM,
         ptrR(__CIL_TMP28, BabelExp_6, 8),
         babelAssign(__CIL_TMP29, __CIL_TMP28 +8* K),
         BabelExp_7 is __CIL_AP_DOCS,
         ptrR(__CIL_TMP30, BabelExp_7, 8),
         BabelExp_8 is __CIL_TMP29,
         ptrR(__CIL_TMP31, BabelExp_8, 8),
         babelAssign(__CIL_TMP32, __CIL_TMP30 +1* __CIL_TMP31),
         BabelExp_9 is __CIL_AP_KERNEL_PARM,
         ptrR(__CIL_TMP33, BabelExp_9, 8),
         BabelExp_10 is __CIL_TMP27,
         ptrR(__CIL_TMP34, BabelExp_10, 8),
         BabelExp_11 is __CIL_TMP32,
         ptrR(__CIL_TMP35, BabelExp_11, 8),
         babel__implicit_distribute_alpha_t_greedily_cil_lr_2_cil_lr_3c_0(__CIL_TMP33, __CIL_TMP34, __CIL_TMP35 , TMP___3_SSA_1),
         BabelExp_12 is __CIL_AP_D,
         ptrR(__CIL_TMP36, BabelExp_12, 8),
         BabelExp_13 is __CIL_AP_SVNUM,
         ptrR(__CIL_TMP37, BabelExp_13, 8),
         BabelExp_14 is __CIL_TMP36 * __CIL_TMP37,
         babelAssign(__CIL_TMP38, BabelExp_14),
         BabelExp_15 is __CIL_AP_CACHE,
         ptrR(__CIL_TMP39, BabelExp_15, 8),
         BabelExp_16 is __CIL_TMP38 + K,
         babelAssign(__CIL_TMP40, BabelExp_16),
         babelAssign(__CIL_TMP41, __CIL_TMP39 +4* __CIL_TMP40),
         BabelExp_17 is TMP___3_SSA_1,
         ptrW(__CIL_TMP41, BabelExp_17, 4),
         BabelExp_18 is K + 1,
         babelAssign(K_SSA_1, BabelExp_18),
         distribute_alpha_t_greedily_cil_lr_2_cil_lr_3(__CIL_AP_SV2DNUM, __CIL_AP_SVNUM, __CIL_AP_DOCS, __CIL_AP_DOCNUM, __CIL_AP_KERNEL_PARM, __CIL_AP_LEARN_PARM, __CIL_AP_THRESH, __CIL_AP_D, __CIL_AP_INIT_VAL_SQ, __CIL_AP_INIT_VAL_LIN, __CIL_AP_ALLSKIP, __CIL_AP_CACHE, BEST_EX, K_SSA_1, VOID),true
     ; true). 


kernel_cache_shrink_cil_lr_3_cil_lr_1(__CIL_AP_I, __CIL_AP_FROM, __CIL_AP_TO, __CIL_AP_KERNEL_CACHE, __CIL_AP_KEEP, JJ, VOID) :- 


    BabelExp_19 is __CIL_AP_KERNEL_CACHE,
    ptrR(__CIL_TMP12, BabelExp_19, 8),
    babelAssign(__CIL_TMP13, __CIL_TMP12),
    babelAssign(__CIL_TMP14, __CIL_TMP13 +1* 80),
    babelAssign(__CIL_TMP15, __CIL_TMP14),
    BabelExp_20 is __CIL_TMP15,
    ptrR(__CIL_TMP16, BabelExp_20, 8),

    (babelJcc(16, JJ, __CIL_TMP16) ->
         babelAssign(__CIL_TMP10, 1)
     ; babelAssign(__CIL_TMP10, 0)),

    (babelJcc(13, __CIL_TMP10, 0) ->
         BabelExp_21 is __CIL_AP_KERNEL_CACHE,
         ptrR(__CIL_TMP17, BabelExp_21, 8),
         babelAssign(__CIL_TMP18, __CIL_TMP17),
         babelAssign(__CIL_TMP19, __CIL_TMP18 +1* 24),
         babelAssign(__CIL_TMP20, __CIL_TMP19),
         BabelExp_22 is __CIL_TMP20,
         ptrR(__CIL_TMP21, BabelExp_22, 8),
         babelAssign(__CIL_TMP22, __CIL_TMP21 +8* JJ),
         BabelExp_23 is __CIL_TMP22,
         ptrR(J_SSA_1, BabelExp_23, 8),
         BabelExp_24 is __CIL_AP_KEEP,
         ptrR(__CIL_TMP23, BabelExp_24, 8),
         babelAssign(__CIL_TMP24, __CIL_TMP23 +8* J_SSA_1),
         BabelExp_25 is __CIL_TMP24,
         ptrR(__CIL_TMP25, BabelExp_25, 8),

         (babelJcc(12, __CIL_TMP25, 0) ->
              babelAssign(__CIL_TMP11, 1)
          ; babelAssign(__CIL_TMP11, 0)),

         (babelJcc(13, __CIL_TMP11, 0) ->
              BabelExp_26 is __CIL_AP_FROM,
              ptrR(__CIL_TMP26, BabelExp_26, 8),
              BabelExp_27 is __CIL_TMP26 + 1,
              ptrW(__CIL_AP_FROM, BabelExp_27, 8)
          ; BabelExp_28 is __CIL_AP_KERNEL_CACHE,
            ptrR(__CIL_TMP27, BabelExp_28, 8),
            babelAssign(__CIL_TMP28, __CIL_TMP27),
            babelAssign(__CIL_TMP29, __CIL_TMP28 +1* 8),
            babelAssign(__CIL_TMP30, __CIL_TMP29),
            BabelExp_29 is __CIL_TMP30,
            ptrR(__CIL_TMP31, BabelExp_29, 8),
            BabelExp_30 is __CIL_AP_FROM,
            ptrR(__CIL_TMP32, BabelExp_30, 8),
            babelAssign(__CIL_TMP33, __CIL_TMP31 +4* __CIL_TMP32),
            BabelExp_31 is __CIL_AP_KERNEL_CACHE,
            ptrR(__CIL_TMP34, BabelExp_31, 8),
            babelAssign(__CIL_TMP35, __CIL_TMP34),
            babelAssign(__CIL_TMP36, __CIL_TMP35 +1* 8),
            babelAssign(__CIL_TMP37, __CIL_TMP36),
            BabelExp_32 is __CIL_TMP37,
            ptrR(__CIL_TMP38, BabelExp_32, 8),
            BabelExp_33 is __CIL_AP_TO,
            ptrR(__CIL_TMP39, BabelExp_33, 8),
            babelAssign(__CIL_TMP40, __CIL_TMP38 +4* __CIL_TMP39),
            ptrR(BabelExp_34, __CIL_TMP33, 4),
            ptrW(__CIL_TMP40, BabelExp_34, 4),
            BabelExp_35 is __CIL_AP_TO,
            ptrR(__CIL_TMP41, BabelExp_35, 8),
            BabelExp_36 is __CIL_TMP41 + 1,
            ptrW(__CIL_AP_TO, BabelExp_36, 8),
            BabelExp_37 is __CIL_AP_FROM,
            ptrR(__CIL_TMP42, BabelExp_37, 8),
            BabelExp_38 is __CIL_TMP42 + 1,
            ptrW(__CIL_AP_FROM, BabelExp_38, 8)),
         BabelExp_39 is JJ + 1,
         babelAssign(JJ_SSA_1, BabelExp_39),
         kernel_cache_shrink_cil_lr_3_cil_lr_1(__CIL_AP_I, __CIL_AP_FROM, __CIL_AP_TO, __CIL_AP_KERNEL_CACHE, __CIL_AP_KEEP, JJ_SSA_1, VOID),true
     ; true),
    BabelExp_40 is JJ + 1,
    babelAssign(JJ_SSA_1, BabelExp_40),
    kernel_cache_shrink_cil_lr_3_cil_lr_1(__CIL_AP_I, __CIL_AP_FROM, __CIL_AP_TO, __CIL_AP_KERNEL_CACHE, __CIL_AP_KEEP, JJ_SSA_1, VOID),true. 


select_top_n_cil_lr_2_cil_lr_1(__CIL_AP_SELCRIT, __CIL_AP_RANGE, __CIL_AP_SELECT___0, __CIL_AP_N, __CIL_AP_I, J, VOID) :- 


    (babelJcc(17, J, 0) ->
         babelAssign(__CIL_TMP9, 1)
     ; babelAssign(__CIL_TMP9, 0)),

    (babelJcc(13, __CIL_TMP9, 0) ->
         (babelJcc(14, J, 0) ->
              babelAssign(__CIL_TMP10, 1)
          ; babelAssign(__CIL_TMP10, 0)),

         (babelJcc(13, __CIL_TMP10, 0) ->
              BabelExp_41 is __CIL_AP_SELECT___0,
              ptrR(__CIL_TMP12, BabelExp_41, 8),
              BabelExp_42 is J - 1,
              babelAssign(__CIL_TMP13, BabelExp_42),
              babelAssign(__CIL_TMP14, __CIL_TMP12 +8* __CIL_TMP13),
              BabelExp_43 is __CIL_AP_SELCRIT,
              ptrR(__CIL_TMP15, BabelExp_43, 8),
              BabelExp_44 is __CIL_TMP14,
              ptrR(__CIL_TMP16, BabelExp_44, 8),
              babelAssign(__CIL_TMP17, __CIL_TMP15 +8* __CIL_TMP16),
              BabelExp_45 is __CIL_AP_SELCRIT,
              ptrR(__CIL_TMP18, BabelExp_45, 8),
              BabelExp_46 is __CIL_AP_I,
              ptrR(__CIL_TMP19, BabelExp_46, 8),
              babelAssign(__CIL_TMP20, __CIL_TMP18 +8* __CIL_TMP19),
              BabelExp_47 is __CIL_TMP17,
              ptrR(__CIL_TMP21, BabelExp_47, 8),
              BabelExp_48 is __CIL_TMP20,
              ptrR(__CIL_TMP22, BabelExp_48, 8),

              (babelJcc(16, __CIL_TMP21, __CIL_TMP22) ->
                   babelAssign(__CIL_TMP11, 1)
               ; babelAssign(__CIL_TMP11, 0)),

              (babelJcc(13, __CIL_TMP11, 0) ->
                   BabelExp_49 is __CIL_AP_SELECT___0,
                   ptrR(__CIL_TMP23, BabelExp_49, 8),
                   BabelExp_50 is J - 1,
                   babelAssign(__CIL_TMP24, BabelExp_50),
                   babelAssign(__CIL_TMP25, __CIL_TMP23 +8* __CIL_TMP24),
                   BabelExp_51 is __CIL_AP_SELECT___0,
                   ptrR(__CIL_TMP26, BabelExp_51, 8),
                   babelAssign(__CIL_TMP27, __CIL_TMP26 +8* J),
                   ptrR(BabelExp_52, __CIL_TMP25, 8),
                   ptrW(__CIL_TMP27, BabelExp_52, 8),
                   babelAssign(J_SSA_1, J)
               ; BabelExp_53 is __CIL_AP_SELECT___0,
                 ptrR(__CIL_TMP28, BabelExp_53, 8),
                 babelAssign(__CIL_TMP29, __CIL_TMP28 +8* J),
                 ptrR(BabelExp_54, __CIL_AP_I, 8),
                 ptrW(__CIL_TMP29, BabelExp_54, 8),
                 babelAssign(J_SSA_1, -1))
          ; BabelExp_55 is __CIL_AP_SELECT___0,
            ptrR(__CIL_TMP30, BabelExp_55, 8),
            babelAssign(__CIL_TMP31, __CIL_TMP30 +8* J),
            ptrR(BabelExp_56, __CIL_AP_I, 8),
            ptrW(__CIL_TMP31, BabelExp_56, 8),
            babelAssign(J_SSA_1, -1)),
         BabelExp_57 is J_SSA_1 - 1,
         babelAssign(J_SSA_2, BabelExp_57),
         select_top_n_cil_lr_2_cil_lr_1(__CIL_AP_SELCRIT, __CIL_AP_RANGE, __CIL_AP_SELECT___0, __CIL_AP_N, __CIL_AP_I, J_SSA_2, VOID),true
     ; true),
    BabelExp_58 is J - 1,
    babelAssign(J_SSA_1, BabelExp_58),
    select_top_n_cil_lr_2_cil_lr_1(__CIL_AP_SELCRIT, __CIL_AP_RANGE, __CIL_AP_SELECT___0, __CIL_AP_N, __CIL_AP_I, J_SSA_1, VOID),true. 


update_linear_component_cil_lr_3_cil_lr_1(__CIL_AP_DOCS, __CIL_AP_LABEL, __CIL_AP_ACTIVE2DNUM, __CIL_AP_A, __CIL_AP_A_OLD, __CIL_AP_WORKING2DNUM, __CIL_AP_TOTDOC, __CIL_AP_KERNEL_PARM, __CIL_AP_KERNEL_CACHE, __CIL_AP_LIN, __CIL_AP_AICACHE, __CIL_AP_JJ, I, II, VOID) :- 


    BabelExp_59 is __CIL_AP_ACTIVE2DNUM,
    ptrR(__CIL_TMP21, BabelExp_59, 8),
    babelAssign(__CIL_TMP22, __CIL_TMP21 +8* II),
    BabelExp_60 is __CIL_TMP22,
    ptrR(J_SSA_1, BabelExp_60, 8),

    (babelJcc(17, J_SSA_1, 0) ->
         babelAssign(__CIL_TMP20, 1)
     ; babelAssign(__CIL_TMP20, 0)),

    (babelJcc(13, __CIL_TMP20, 0) ->
         BabelExp_61 is __CIL_AP_AICACHE,
         ptrR(__CIL_TMP23, BabelExp_61, 8),
         babelAssign(__CIL_TMP24, __CIL_TMP23 +4* J_SSA_1),
         BabelExp_62 is __CIL_TMP24,
         ptrR(__CIL_TMP25, BabelExp_62, 4),
         babelAssign(TEC_SSA_1, __CIL_TMP25),
         BabelExp_63 is __CIL_AP_LIN,
         ptrR(__CIL_TMP26, BabelExp_63, 8),
         babelAssign(__CIL_TMP27, __CIL_TMP26 +8* J_SSA_1),
         BabelExp_64 is __CIL_AP_A,
         ptrR(__CIL_TMP28, BabelExp_64, 8),
         babelAssign(__CIL_TMP29, __CIL_TMP28 +8* I),
         BabelExp_65 is __CIL_TMP29,
         ptrR(__CIL_TMP30, BabelExp_65, 8),
         BabelExp_66 is __CIL_AP_A_OLD,
         ptrR(__CIL_TMP31, BabelExp_66, 8),
         babelAssign(__CIL_TMP32, __CIL_TMP31 +8* I),
         BabelExp_67 is __CIL_TMP32,
         ptrR(__CIL_TMP33, BabelExp_67, 8),
         BabelExp_68 is __CIL_TMP30 * TEC_SSA_1,
         babelAssign(__CIL_TMP34, BabelExp_68),
         BabelExp_69 is __CIL_TMP33 * TEC_SSA_1,
         babelAssign(__CIL_TMP35, BabelExp_69),
         BabelExp_70 is __CIL_AP_LABEL,
         ptrR(__CIL_TMP36, BabelExp_70, 8),
         babelAssign(__CIL_TMP37, __CIL_TMP36 +8* I),
         BabelExp_71 is __CIL_TMP37,
         ptrR(__CIL_TMP38, BabelExp_71, 8),
         BabelExp_72 is __CIL_TMP34 - __CIL_TMP35,
         babelAssign(__CIL_TMP39, BabelExp_72),
         babelAssign(__CIL_TMP40, __CIL_TMP38),
         BabelExp_73 is __CIL_TMP27,
         ptrR(__CIL_TMP41, BabelExp_73, 8),
         BabelExp_74 is __CIL_TMP39 * __CIL_TMP40,
         babelAssign(__CIL_TMP42, BabelExp_74),
         BabelExp_75 is __CIL_AP_LIN,
         ptrR(__CIL_TMP43, BabelExp_75, 8),
         babelAssign(__CIL_TMP44, __CIL_TMP43 +8* J_SSA_1),
         BabelExp_76 is __CIL_TMP41 + __CIL_TMP42,
         ptrW(__CIL_TMP44, BabelExp_76, 8),
         BabelExp_77 is II + 1,
         babelAssign(II_SSA_1, BabelExp_77),
         update_linear_component_cil_lr_3_cil_lr_1(__CIL_AP_DOCS, __CIL_AP_LABEL, __CIL_AP_ACTIVE2DNUM, __CIL_AP_A, __CIL_AP_A_OLD, __CIL_AP_WORKING2DNUM, __CIL_AP_TOTDOC, __CIL_AP_KERNEL_PARM, __CIL_AP_KERNEL_CACHE, __CIL_AP_LIN, __CIL_AP_AICACHE, __CIL_AP_JJ, I, II_SSA_1, VOID),true
     ; true). 

:- foreign(babel__implicit_compute_matrices_for_optimization_cil_lr_3_cil_lr_1c_1(+integer, +integer, +integer,  -float)).

compute_matrices_for_optimization_cil_lr_3_cil_lr_1(__CIL_AP_STDOUT, __CIL_AP_VERBOSITY, __CIL_AP_DOCS, __CIL_AP_KERNEL_PARM, __CIL_AP_I, __CIL_AP_LABEL, __CIL_AP_KEY, __CIL_AP_A, __CIL_AP_VARNUM, __CIL_AP_QP, KI, J, VOID) :- 


    BabelExp_78 is __CIL_AP_VARNUM,
    ptrR(__CIL_TMP21, BabelExp_78, 8),

    (babelJcc(16, J, __CIL_TMP21) ->
         babelAssign(__CIL_TMP20, 1)
     ; babelAssign(__CIL_TMP20, 0)),

    (babelJcc(13, __CIL_TMP20, 0) ->
         BabelExp_79 is __CIL_AP_KEY,
         ptrR(__CIL_TMP22, BabelExp_79, 8),
         babelAssign(__CIL_TMP23, __CIL_TMP22 +8* J),
         BabelExp_80 is __CIL_TMP23,
         ptrR(KJ_SSA_1, BabelExp_80, 8),
         BabelExp_81 is __CIL_AP_DOCS,
         ptrR(__CIL_TMP24, BabelExp_81, 8),
         babelAssign(__CIL_TMP25, __CIL_TMP24 +1* KI),
         BabelExp_82 is __CIL_AP_DOCS,
         ptrR(__CIL_TMP26, BabelExp_82, 8),
         babelAssign(__CIL_TMP27, __CIL_TMP26 +1* KJ_SSA_1),
         BabelExp_83 is __CIL_AP_KERNEL_PARM,
         ptrR(__CIL_TMP28, BabelExp_83, 8),
         BabelExp_84 is __CIL_TMP25,
         ptrR(__CIL_TMP29, BabelExp_84, 8),
         BabelExp_85 is __CIL_TMP27,
         ptrR(__CIL_TMP30, BabelExp_85, 8),
         babel__implicit_compute_matrices_for_optimization_cil_lr_3_cil_lr_1c_1(__CIL_TMP28, __CIL_TMP29, __CIL_TMP30 , TMP___0_SSA_1),
         babelAssign(KERNEL_TEMP_SSA_1, TMP___0_SSA_1),
         BabelExp_86 is __CIL_AP_QP,
         ptrR(__CIL_TMP31, BabelExp_86, 8),
         babelAssign(__CIL_TMP32, __CIL_TMP31),
         babelAssign(__CIL_TMP33, __CIL_TMP32 +1* 40),
         babelAssign(__CIL_TMP34, __CIL_TMP33),
         BabelExp_87 is __CIL_TMP34,
         ptrR(__CIL_TMP35, BabelExp_87, 8),
         BabelExp_88 is __CIL_AP_I,
         ptrR(__CIL_TMP36, BabelExp_88, 8),
         babelAssign(__CIL_TMP37, __CIL_TMP35 +8* __CIL_TMP36),
         BabelExp_89 is __CIL_AP_A,
         ptrR(__CIL_TMP38, BabelExp_89, 8),
         babelAssign(__CIL_TMP39, __CIL_TMP38 +8* KJ_SSA_1),
         BabelExp_90 is __CIL_TMP39,
         ptrR(__CIL_TMP40, BabelExp_90, 8),
         BabelExp_91 is __CIL_AP_LABEL,
         ptrR(__CIL_TMP41, BabelExp_91, 8),
         babelAssign(__CIL_TMP42, __CIL_TMP41 +8* KJ_SSA_1),
         BabelExp_92 is __CIL_TMP42,
         ptrR(__CIL_TMP43, BabelExp_92, 8),
         BabelExp_93 is KERNEL_TEMP_SSA_1 * __CIL_TMP40,
         babelAssign(__CIL_TMP44, BabelExp_93),
         babelAssign(__CIL_TMP45, __CIL_TMP43),
         BabelExp_94 is __CIL_TMP37,
         ptrR(__CIL_TMP46, BabelExp_94, 8),
         BabelExp_95 is __CIL_TMP44 * __CIL_TMP45,
         babelAssign(__CIL_TMP47, BabelExp_95),
         BabelExp_96 is __CIL_AP_QP,
         ptrR(__CIL_TMP48, BabelExp_96, 8),
         babelAssign(__CIL_TMP49, __CIL_TMP48),
         babelAssign(__CIL_TMP50, __CIL_TMP49 +1* 40),
         babelAssign(__CIL_TMP51, __CIL_TMP50),
         BabelExp_97 is __CIL_TMP51,
         ptrR(__CIL_TMP52, BabelExp_97, 8),
         BabelExp_98 is __CIL_AP_I,
         ptrR(__CIL_TMP53, BabelExp_98, 8),
         babelAssign(__CIL_TMP54, __CIL_TMP52 +8* __CIL_TMP53),
         BabelExp_99 is __CIL_TMP46 - __CIL_TMP47,
         ptrW(__CIL_TMP54, BabelExp_99, 8),
         BabelExp_100 is __CIL_AP_QP,
         ptrR(__CIL_TMP55, BabelExp_100, 8),
         babelAssign(__CIL_TMP56, __CIL_TMP55),
         babelAssign(__CIL_TMP57, __CIL_TMP56 +1* 40),
         babelAssign(__CIL_TMP58, __CIL_TMP57),
         BabelExp_101 is __CIL_TMP58,
         ptrR(__CIL_TMP59, BabelExp_101, 8),
         babelAssign(__CIL_TMP60, __CIL_TMP59 +8* J),
         BabelExp_102 is __CIL_AP_A,
         ptrR(__CIL_TMP61, BabelExp_102, 8),
         babelAssign(__CIL_TMP62, __CIL_TMP61 +8* KI),
         BabelExp_103 is __CIL_TMP62,
         ptrR(__CIL_TMP63, BabelExp_103, 8),
         BabelExp_104 is __CIL_AP_LABEL,
         ptrR(__CIL_TMP64, BabelExp_104, 8),
         babelAssign(__CIL_TMP65, __CIL_TMP64 +8* KI),
         BabelExp_105 is __CIL_TMP65,
         ptrR(__CIL_TMP66, BabelExp_105, 8),
         BabelExp_106 is KERNEL_TEMP_SSA_1 * __CIL_TMP63,
         babelAssign(__CIL_TMP67, BabelExp_106),
         babelAssign(__CIL_TMP68, __CIL_TMP66),
         BabelExp_107 is __CIL_TMP60,
         ptrR(__CIL_TMP69, BabelExp_107, 8),
         BabelExp_108 is __CIL_TMP67 * __CIL_TMP68,
         babelAssign(__CIL_TMP70, BabelExp_108),
         BabelExp_109 is __CIL_AP_QP,
         ptrR(__CIL_TMP71, BabelExp_109, 8),
         babelAssign(__CIL_TMP72, __CIL_TMP71),
         babelAssign(__CIL_TMP73, __CIL_TMP72 +1* 40),
         babelAssign(__CIL_TMP74, __CIL_TMP73),
         BabelExp_110 is __CIL_TMP74,
         ptrR(__CIL_TMP75, BabelExp_110, 8),
         babelAssign(__CIL_TMP76, __CIL_TMP75 +8* J),
         BabelExp_111 is __CIL_TMP69 - __CIL_TMP70,
         ptrW(__CIL_TMP76, BabelExp_111, 8),
         BabelExp_112 is __CIL_AP_LABEL,
         ptrR(__CIL_TMP77, BabelExp_112, 8),
         babelAssign(__CIL_TMP78, __CIL_TMP77 +8* KI),
         BabelExp_113 is __CIL_TMP78,
         ptrR(__CIL_TMP79, BabelExp_113, 8),
         BabelExp_114 is __CIL_AP_LABEL,
         ptrR(__CIL_TMP80, BabelExp_114, 8),
         babelAssign(__CIL_TMP81, __CIL_TMP80 +8* KJ_SSA_1),
         BabelExp_115 is __CIL_TMP81,
         ptrR(__CIL_TMP82, BabelExp_115, 8),
         babelAssign(__CIL_TMP83, __CIL_TMP79),
         babelAssign(__CIL_TMP84, __CIL_TMP82),
         BabelExp_116 is __CIL_TMP83 * __CIL_TMP84,
         babelAssign(__CIL_TMP85, BabelExp_116),
         BabelExp_117 is __CIL_AP_QP,
         ptrR(__CIL_TMP86, BabelExp_117, 8),
         babelAssign(__CIL_TMP87, __CIL_TMP86),
         babelAssign(__CIL_TMP88, __CIL_TMP87 +1* 32),
         babelAssign(__CIL_TMP89, __CIL_TMP88),
         BabelExp_118 is __CIL_AP_VARNUM,
         ptrR(__CIL_TMP90, BabelExp_118, 8),
         BabelExp_119 is __CIL_AP_I,
         ptrR(__CIL_TMP91, BabelExp_119, 8),
         BabelExp_120 is __CIL_TMP90 * __CIL_TMP91,
         babelAssign(__CIL_TMP92, BabelExp_120),
         BabelExp_121 is __CIL_TMP89,
         ptrR(__CIL_TMP93, BabelExp_121, 8),
         BabelExp_122 is __CIL_TMP92 + J,
         babelAssign(__CIL_TMP94, BabelExp_122),
         babelAssign(__CIL_TMP95, __CIL_TMP93 +8* __CIL_TMP94),
         BabelExp_123 is __CIL_TMP85 * KERNEL_TEMP_SSA_1,
         ptrW(__CIL_TMP95, BabelExp_123, 8),
         BabelExp_124 is __CIL_AP_LABEL,
         ptrR(__CIL_TMP96, BabelExp_124, 8),
         babelAssign(__CIL_TMP97, __CIL_TMP96 +8* KI),
         BabelExp_125 is __CIL_TMP97,
         ptrR(__CIL_TMP98, BabelExp_125, 8),
         BabelExp_126 is __CIL_AP_LABEL,
         ptrR(__CIL_TMP99, BabelExp_126, 8),
         babelAssign(__CIL_TMP100, __CIL_TMP99 +8* KJ_SSA_1),
         BabelExp_127 is __CIL_TMP100,
         ptrR(__CIL_TMP101, BabelExp_127, 8),
         babelAssign(__CIL_TMP102, __CIL_TMP98),
         babelAssign(__CIL_TMP103, __CIL_TMP101),
         BabelExp_128 is __CIL_TMP102 * __CIL_TMP103,
         babelAssign(__CIL_TMP104, BabelExp_128),
         BabelExp_129 is __CIL_AP_QP,
         ptrR(__CIL_TMP105, BabelExp_129, 8),
         babelAssign(__CIL_TMP106, __CIL_TMP105),
         babelAssign(__CIL_TMP107, __CIL_TMP106 +1* 32),
         babelAssign(__CIL_TMP108, __CIL_TMP107),
         BabelExp_130 is __CIL_AP_VARNUM,
         ptrR(__CIL_TMP109, BabelExp_130, 8),
         BabelExp_131 is __CIL_TMP109 * J,
         babelAssign(__CIL_TMP110, BabelExp_131),
         BabelExp_132 is __CIL_AP_I,
         ptrR(__CIL_TMP111, BabelExp_132, 8),
         BabelExp_133 is __CIL_TMP108,
         ptrR(__CIL_TMP112, BabelExp_133, 8),
         BabelExp_134 is __CIL_TMP110 + __CIL_TMP111,
         babelAssign(__CIL_TMP113, BabelExp_134),
         babelAssign(__CIL_TMP114, __CIL_TMP112 +8* __CIL_TMP113),
         BabelExp_135 is __CIL_TMP104 * KERNEL_TEMP_SSA_1,
         ptrW(__CIL_TMP114, BabelExp_135, 8),
         BabelExp_136 is J + 1,
         babelAssign(J_SSA_1, BabelExp_136),
         compute_matrices_for_optimization_cil_lr_3_cil_lr_1(__CIL_AP_STDOUT, __CIL_AP_VERBOSITY, __CIL_AP_DOCS, __CIL_AP_KERNEL_PARM, __CIL_AP_I, __CIL_AP_LABEL, __CIL_AP_KEY, __CIL_AP_A, __CIL_AP_VARNUM, __CIL_AP_QP, KI, J_SSA_1, VOID),true
     ; true). 

clear_index(INDEX) :-
    ptrW(INDEX, -1, 8). 


compute_objective_function(__CIL_PP_CRITERION, __CIL_FP_CRITERION, A, LIN, C, EPS, LABEL, ACTIVE2DNUM, CRITERION_SSA_2) :- 
    CRITERION_SSA_1 is 0,
    II_SSA_1 is 0,
    ptrW(__CIL_FP_CRITERION, 0, 8),
    cof_cil_lr_1(__CIL_PP_CRITERION, A, LIN, C, EPS, LABEL, ACTIVE2DNUM, II_SSA_1),
    ptrR(CRITERION_SSA_2, __CIL_FP_CRITERION, 8).

cof_cil_lr_1(__CIL_AP_CRITERION, A, LIN, C, EPS, LABEL, ACTIVE2DNUM, II):-
    TMP13 is ACTIVE2DNUM + II * 8,
    ptrR(I1, TMP13, 8),
    (I1 < 0 -> true; 
     T16 is LABEL + I1 * 8,
     ptrR(T17, T16, 8),
     T18 is C + I1 * 8,
     ptrRF(T20, T18),
     T21 is T20 * T17,
     T22 is A + I1 * 8,
     T23 is EPS - T21,
     ptrRF(T24, T22),
     ptrRF(T25, __CIL_AP_CRITERION),
     T26 is T23 * T24,
     T29 is LABEL + I1 * 8,
     ptrR(T30, T29, 8),
     T31 is T24 * 0.5,
     T33 is LIN + I1 * 8,
     T34 is T31 * T30,
     ptrRF(T35, T33),
     T36 is T25 + T26,
     T37 is T34 * T35,
     B1 is T36 + T37,
     ptrWF(__CIL_AP_CRITERION, B1),
     II_SSA_1 is II + 1,
     cof_cil_lr_1(__CIL_AP_CRITERION, A, LIN, C, EPS, LABEL, ACTIVE2DUM, II_SSA_1)
    ).
    

add_to_index(INDEX, ELEM) :-
    add_to_index_cil_lr_1(INDEX, ELEM, 0).

add_to_index_cil_lr_1(INDEX, ELEM, I):-
    T1 is INDEX + I * 8,
    ptrR(T2, T1, 8),
    (T2 =:= -1 -> true;
     ptrW(T1, ELEM, 8),
     T3 is T1 + 8,
     ptrW(T3, -1, 8),
     I2 is I + 1,
     add_to_index_cil_lr_1(INDEX, ELEM, I2)
    ).

compute_index(__CIL_PP_INDEX, __CIL_PP_II, __CIL_FP_INDEX, __CIL_FP_II, BINFEATURE, RANGE, INDEX, II_SSA_2) :- 
    II_SSA_1 is 0,
    compute_index_cil_lr_1(INDEX, II_SSA_1, II_SSA_2, BINFEATURE, RANGE, 0),
    T1 is INDEX + II_SSA_2 * 8,
    ptrW(T1, -1, 8),
    T2 is T1 + 8,
    ptrW(T2, -1, 8),
    T3 is T2 + 8,
    ptrW(T3, -1, 8),
    T4 is T3 + 8,
    ptrW(T4, -1, 8).

compute_index_cil_lr_1(INDEX, II_IN, II_OUT, BINFEATURE, RANGE, I):-
    I >= RANGE -> II_OUT is II_IN;
    (T1 is BINFEATURE + I * 8,
    ptrR(T2, T1, 8),
    (T2 =:= 0 -> II_IN_NEW is II_IN;
     T3 is INDEX + II_IN * 8,
     ptrW(T3, I, 8),
     II_IN_NEW is II_IN + 1),
    I2 is I + 1,
    compute_index_cil_lr_1(INDEX, II_IN_NEW, II_OUT, BINFEATURE, RANGE, I2)
    ).

:- foreign(babel__implicit_optimize_svmc_4(+integer, +integer, +integer, +integer, +float, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_optimize_svmc_5(+integer)).
:- foreign(babel__implicit_optimize_svmc_6(+integer)).
:- foreign(babel__implicit_optimize_svmc_7(+integer, +integer, +integer, +integer, +integer,  -integer)).
:- foreign(babel__implicit_optimize_svmc_8(+integer)).
:- foreign(babel__implicit_optimize_svmc_9(+integer, +integer, +integer, +integer, +integer)).

optimize_svm(__CIL_GP_VERBOSITY, __CIL_GP_STDOUT, DOCS, LABEL, UNLABELED, EXCLUDE_FROM_EQ_CONST, EQ_TARGET, CHOSEN, ACTIVE2DNUM, MODEL, TOTDOC, WORKING2DNUM, VARNUM, A, LIN, C, LEARN_PARM, AICACHE, KERNEL_PARM, QP, EPSILON_CRIT_TARGET) :- 
    babel__implicit_optimize_svmc_4(DOCS, LABEL, UNLABELED, EXCLUDE_FROM_EQ_CONST, EQ_TARGET, CHOSEN, ACTIVE2DNUM, WORKING2DNUM, MODEL, A, LIN, C, VARNUM, TOTDOC, LEARN_PARM, AICACHE, KERNEL_PARM, QP),
    BabelExp_17 is __CIL_GP_VERBOSITY,
    ptrR(__CIL_TMP28, BabelExp_17, 8),

    (babelJcc(17, __CIL_TMP28, 3) ->
         babelAssign(__CIL_TMP26, 1)
     ; babelAssign(__CIL_TMP26, 0)),

    (babelJcc(13, __CIL_TMP26, 0) ->
         babel__implicit_optimize_svmc_5('RUNNING OPTIMIZER...'),
         BabelExp_18 is __CIL_GP_STDOUT,
         ptrR(__CIL_TMP29, BabelExp_18, 8),
         babel__implicit_optimize_svmc_6(__CIL_TMP29)
     ; true),
    babelAssign(__CIL_TMP30, LEARN_PARM +1* 56),
    babelAssign(__CIL_TMP31, __CIL_TMP30),
    babelAssign(__CIL_TMP32, MODEL +1* 16),
    BabelExp_19 is __CIL_TMP31,
    ptrR(__CIL_TMP33, BabelExp_19, 8),
    babel__implicit_optimize_svmc_7(QP, EPSILON_CRIT_TARGET, __CIL_TMP33, __CIL_TMP32, LEARN_PARM , A_V_SSA_1),
    BabelExp_20 is __CIL_GP_VERBOSITY,
    ptrR(__CIL_TMP34, BabelExp_20, 8),

    (babelJcc(17, __CIL_TMP34, 3) ->
         babelAssign(__CIL_TMP27, 1)
     ; babelAssign(__CIL_TMP27, 0)),

    (babelJcc(13, __CIL_TMP27, 0) ->
         babel__implicit_optimize_svmc_8('DONE\\N')
     ; true),
    optimize_svm_cil_lr_1(WORKING2DNUM, VARNUM, A, 0, A_V_SSA_1). 

optimize_svm_cil_lr_1(WORKING2DNUM, VARNUM, A, I, A_V):-
    I >= VARNUM -> true;
    I2 is I + 1,
    T1 is A_V + I * 8,
    ptrRF(A_V_I, T1),
    T2 is WORKING2DNUM + I * 8,
    ptrR(W2DI, T2, 8),
    T3 is A + W2DI * 8,
    ptrWF(T3, A_V_I),
    optimize_svm_cil_lr_1(WORKING2DNUM, VARNUM, A, I2, A_V).

:- foreign(babel__implicit_compute_matrices_for_optimizationc_10(+integer, +string, +integer, +integer, +float, +float, +float)).
:- foreign(babel__implicit_compute_matrices_for_optimizationc_11(+integer)).
:- foreign(babel__implicit_compute_matrices_for_optimizationc_12(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_compute_matrices_for_optimizationc_13(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_compute_matrices_for_optimizationc_14(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_compute_matrices_for_optimizationc_15(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_compute_matrices_for_optimizationc_16(+integer, +string)).

compute_matrices_for_optimization(__CIL_PP_STDOUT, __CIL_PP_VERBOSITY, __CIL_PP_DOCS, __CIL_PP_LABEL, __CIL_PP_KEY, __CIL_PP_A, __CIL_PP_LIN, __CIL_PP_C, __CIL_PP_VARNUM, __CIL_PP_LEARN_PARM, __CIL_PP_KERNEL_PARM, __CIL_PP_QP, __CIL_GP_VERBOSITY, __CIL_GP_STDOUT, __CIL_FP_DOCS, __CIL_FP_LABEL, __CIL_FP_KEY, __CIL_FP_A, __CIL_FP_LIN, __CIL_FP_C, __CIL_FP_VARNUM, __CIL_FP_LEARN_PARM, __CIL_FP_KERNEL_PARM, __CIL_FP_QP, DOCS, LABEL, UNLABELED, EXCLUDE_FROM_EQ_CONST, EQ_TARGET, CHOSEN, ACTIVE2DNUM, KEY, MODEL, A, LIN, C, VARNUM, TOTDOC, LEARN_PARM, AICACHE, KERNEL_PARM, QP) :- 


    BabelExp_21 is __CIL_GP_VERBOSITY,
    ptrR(__CIL_TMP83, BabelExp_21, 8),

    ( __CIL_TMP83 >= 3 ->
          BabelExp_22 is __CIL_GP_STDOUT,
          ptrR(__CIL_TMP84, BabelExp_22, 8),
          babelAssign(__CIL_TMP85, KERNEL_PARM +1* 8),
          babelAssign(__CIL_TMP86, __CIL_TMP85),
          babelAssign(__CIL_TMP87, KERNEL_PARM +1* 16),
          babelAssign(__CIL_TMP88, __CIL_TMP87),
          babelAssign(__CIL_TMP89, KERNEL_PARM +1* 24),
          babelAssign(__CIL_TMP90, __CIL_TMP89),
          babelAssign(__CIL_TMP91, KERNEL_PARM +1* 32),
          babelAssign(__CIL_TMP92, __CIL_TMP91),
          babelAssign(MEM_104, KERNEL_PARM),
          BabelExp_23 is MEM_104,
          ptrR(__CIL_TMP93, BabelExp_23, 8),
          BabelExp_24 is __CIL_TMP86,
          ptrR(__CIL_TMP94, BabelExp_24, 8),
          BabelExp_25 is __CIL_TMP88,
          ptrR(__CIL_TMP95, BabelExp_25, 8),
          BabelExp_26 is __CIL_TMP90,
          ptrR(__CIL_TMP96, BabelExp_26, 8),
          BabelExp_27 is __CIL_TMP92,
          ptrR(__CIL_TMP97, BabelExp_27, 8),
          babel__implicit_compute_matrices_for_optimizationc_10(__CIL_TMP84, 'COMPUTING QP-MATRICES (TYPE %ld KERNEL [DEGREE %LD, RBF_GAMMA %f, COEF_LIN %f, COEF_CONST %f])...', __CIL_TMP93, __CIL_TMP94, __CIL_TMP95, __CIL_TMP96, __CIL_TMP97),
         BabelExp_28 is __CIL_GP_STDOUT,
         ptrR(__CIL_TMP98, BabelExp_28, 8),
         babel__implicit_compute_matrices_for_optimizationc_11(__CIL_TMP98)
     ; true),
    ptrW(QP, VARNUM, 8),
    __CIL_TMP100 is QP + 24,
    ptrR(__CIL_TMP102, __CIL_TMP100, 8),
    EXP is -1.0 * EQ_TARGET,
    ptrWF(__CIL_TMP102, EXP),
    J_SSA_1 is 1,
    babel__implicit_compute_matrices_for_optimizationc_12(__CIL_PP_STDOUT, __CIL_PP_VERBOSITY, __CIL_PP_DOCS, __CIL_PP_LABEL, __CIL_PP_KEY, __CIL_PP_A, __CIL_PP_LIN, __CIL_PP_C, __CIL_PP_VARNUM, __CIL_PP_LEARN_PARM, __CIL_PP_KERNEL_PARM, __CIL_PP_QP, EXCLUDE_FROM_EQ_CONST, CHOSEN, MODEL, J_SSA_1),
    BabelExp_42 is __CIL_FP_DOCS,
    ptrR(DOCS_SSA_1, BabelExp_42, 8),
    BabelExp_43 is __CIL_FP_LABEL,
    ptrR(LABEL_SSA_1, BabelExp_43, 8),
    BabelExp_44 is __CIL_FP_KEY,
    ptrR(KEY_SSA_1, BabelExp_44, 8),
    BabelExp_45 is __CIL_FP_A,
    ptrR(A_SSA_1, BabelExp_45, 8),
    BabelExp_46 is __CIL_FP_LIN,
    ptrR(LIN_SSA_1, BabelExp_46, 8),
    BabelExp_47 is __CIL_FP_C,
    ptrR(C_SSA_1, BabelExp_47, 8),
    BabelExp_48 is __CIL_FP_VARNUM,
    ptrR(VARNUM_SSA_1, BabelExp_48, 8),
    BabelExp_49 is __CIL_FP_LEARN_PARM,
    ptrR(LEARN_PARM_SSA_1, BabelExp_49, 8),
    BabelExp_50 is __CIL_FP_KERNEL_PARM,
    ptrR(KERNEL_PARM_SSA_1, BabelExp_50, 8),
    BabelExp_51 is __CIL_FP_QP,
    ptrR(QP_SSA_1, BabelExp_51, 8),
    babelAssign(__CIL_TMP103, LEARN_PARM_SSA_1 +1* 40),
    babelAssign(__CIL_TMP104, __CIL_TMP103),
    BabelExp_52 is __CIL_TMP104,
    ptrR(__CIL_TMP81, BabelExp_52, 8),
    (babelJcc(13, __CIL_TMP81, 0) ->
         babelAssign(__CIL_TMP105, QP_SSA_1 +1* 8),
         babelAssign(__CIL_TMP106, __CIL_TMP105),
         BabelExp_53 is 1,
         ptrW(__CIL_TMP106, BabelExp_53, 8)
     ; babelAssign(__CIL_TMP107, QP_SSA_1 +1* 8),
       babelAssign(__CIL_TMP108, __CIL_TMP107),
       BabelExp_54 is 0,
       ptrW(__CIL_TMP108, BabelExp_54, 8)),
    babelAssign(I_SSA_1, 0),
    BabelExp_55 is DOCS_SSA_1,
    ptrW(__CIL_FP_DOCS, BabelExp_55, 8),
    BabelExp_56 is LABEL_SSA_1,
    ptrW(__CIL_FP_LABEL, BabelExp_56, 8),
    BabelExp_57 is KEY_SSA_1,
    ptrW(__CIL_FP_KEY, BabelExp_57, 8),
    BabelExp_58 is A_SSA_1,
    ptrW(__CIL_FP_A, BabelExp_58, 8),
    BabelExp_59 is C_SSA_1,
    ptrW(__CIL_FP_C, BabelExp_59, 8),
    BabelExp_60 is VARNUM_SSA_1,
    ptrW(__CIL_FP_VARNUM, BabelExp_60, 8),
    BabelExp_61 is LEARN_PARM_SSA_1,
    ptrW(__CIL_FP_LEARN_PARM, BabelExp_61, 8),
    BabelExp_62 is KERNEL_PARM_SSA_1,
    ptrW(__CIL_FP_KERNEL_PARM, BabelExp_62, 8),
    BabelExp_63 is QP_SSA_1,
    ptrW(__CIL_FP_QP, BabelExp_63, 8),
    babel__implicit_compute_matrices_for_optimizationc_13(__CIL_PP_STDOUT, __CIL_PP_VERBOSITY, __CIL_PP_DOCS, __CIL_PP_LABEL, __CIL_PP_KEY, __CIL_PP_A, __CIL_PP_C, __CIL_PP_VARNUM, __CIL_PP_LEARN_PARM, __CIL_PP_KERNEL_PARM, __CIL_PP_QP, LIN_SSA_1, I_SSA_1),
    BabelExp_64 is __CIL_FP_DOCS,
    ptrR(DOCS_SSA_2, BabelExp_64, 8),
    BabelExp_65 is __CIL_FP_LABEL,
    ptrR(LABEL_SSA_2, BabelExp_65, 8),
    BabelExp_66 is __CIL_FP_KEY,
    ptrR(KEY_SSA_2, BabelExp_66, 8),
    BabelExp_67 is __CIL_FP_A,
    ptrR(A_SSA_2, BabelExp_67, 8),
    BabelExp_68 is __CIL_FP_C,
    ptrR(C_SSA_2, BabelExp_68, 8),
    BabelExp_69 is __CIL_FP_VARNUM,
    ptrR(VARNUM_SSA_2, BabelExp_69, 8),
    BabelExp_70 is __CIL_FP_LEARN_PARM,
    ptrR(LEARN_PARM_SSA_2, BabelExp_70, 8),
    BabelExp_71 is __CIL_FP_KERNEL_PARM,
    ptrR(KERNEL_PARM_SSA_2, BabelExp_71, 8),
    BabelExp_72 is __CIL_FP_QP,
    ptrR(QP_SSA_2, BabelExp_72, 8),
    babelAssign(I_SSA_2, 0),
    BabelExp_73 is LABEL_SSA_2,
    ptrW(__CIL_FP_LABEL, BabelExp_73, 8),
    BabelExp_74 is KEY_SSA_2,
    ptrW(__CIL_FP_KEY, BabelExp_74, 8),
    BabelExp_75 is A_SSA_2,
    ptrW(__CIL_FP_A, BabelExp_75, 8),
    BabelExp_76 is C_SSA_2,
    ptrW(__CIL_FP_C, BabelExp_76, 8),
    BabelExp_77 is VARNUM_SSA_2,
    ptrW(__CIL_FP_VARNUM, BabelExp_77, 8),
    BabelExp_78 is LEARN_PARM_SSA_2,
    ptrW(__CIL_FP_LEARN_PARM, BabelExp_78, 8),
    BabelExp_79 is QP_SSA_2,
    ptrW(__CIL_FP_QP, BabelExp_79, 8),
    babel__implicit_compute_matrices_for_optimizationc_14(__CIL_PP_STDOUT, __CIL_PP_VERBOSITY, __CIL_PP_LABEL, __CIL_PP_KEY, __CIL_PP_A, __CIL_PP_C, __CIL_PP_VARNUM, __CIL_PP_LEARN_PARM, __CIL_PP_QP, DOCS_SSA_2, KERNEL_PARM_SSA_2, I_SSA_2),
    BabelExp_80 is __CIL_FP_LABEL,
    ptrR(LABEL_SSA_3, BabelExp_80, 8),
    BabelExp_81 is __CIL_FP_KEY,
    ptrR(KEY_SSA_3, BabelExp_81, 8),
    BabelExp_82 is __CIL_FP_A,
    ptrR(A_SSA_3, BabelExp_82, 8),
    BabelExp_83 is __CIL_FP_C,
    ptrR(C_SSA_3, BabelExp_83, 8),
    BabelExp_84 is __CIL_FP_VARNUM,
    ptrR(VARNUM_SSA_3, BabelExp_84, 8),
    BabelExp_85 is __CIL_FP_LEARN_PARM,
    ptrR(LEARN_PARM_SSA_3, BabelExp_85, 8),
    BabelExp_86 is __CIL_FP_QP,
    ptrR(QP_SSA_3, BabelExp_86, 8),
    babelAssign(I_SSA_3, 0),
    babel__implicit_compute_matrices_for_optimizationc_15(__CIL_PP_STDOUT, __CIL_PP_VERBOSITY, LABEL_SSA_3, KEY_SSA_3, A_SSA_3, C_SSA_3, VARNUM_SSA_3, LEARN_PARM_SSA_3, QP_SSA_3, I_SSA_3),
    BabelExp_87 is __CIL_GP_VERBOSITY,
    ptrR(__CIL_TMP109, BabelExp_87, 8),

    (babelJcc(17, __CIL_TMP109, 3) ->
         babelAssign(__CIL_TMP82, 1)
     ; babelAssign(__CIL_TMP82, 0)),

    (babelJcc(13, __CIL_TMP82, 0) ->
         BabelExp_88 is __CIL_GP_STDOUT,
         ptrR(__CIL_TMP110, BabelExp_88, 8),
         babel__implicit_compute_matrices_for_optimizationc_16(__CIL_TMP110, 'done\n')
     ; true). 

:- foreign(babel__implicit_compute_shared_slacksc_17(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_compute_shared_slacksc_18(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).

compute_shared_slacks(__CIL_PP_DOCS, __CIL_PP_LABEL, __CIL_PP_A, __CIL_PP_LIN, __CIL_PP_C, __CIL_PP_ACTIVE2DNUM, __CIL_PP_LEARN_PARM, __CIL_PP_SLACK, __CIL_PP_ALPHASLACK, __CIL_FP_DOCS, __CIL_FP_LABEL, __CIL_FP_A, __CIL_FP_LIN, __CIL_FP_C, __CIL_FP_ACTIVE2DNUM, __CIL_FP_LEARN_PARM, __CIL_FP_SLACK, __CIL_FP_ALPHASLACK, DOCS, LABEL, A, LIN, C, ACTIVE2DNUM, LEARN_PARM, SLACK, ALPHASLACK) :- 
    babel__implicit_compute_shared_slacksc_17(__CIL_PP_DOCS, __CIL_PP_LABEL, __CIL_PP_A, __CIL_PP_LIN, __CIL_PP_C, __CIL_PP_ACTIVE2DNUM, __CIL_PP_LEARN_PARM, __CIL_PP_SLACK, __CIL_PP_ALPHASLACK, 0),
    BabelExp_98 is __CIL_FP_DOCS,
    ptrR(DOCS_SSA_1, BabelExp_98, 8),
    BabelExp_99 is __CIL_FP_LABEL,
    ptrR(LABEL_SSA_1, BabelExp_99, 8),
    BabelExp_100 is __CIL_FP_A,
    ptrR(A_SSA_1, BabelExp_100, 8),
    BabelExp_101 is __CIL_FP_LIN,
    ptrR(LIN_SSA_1, BabelExp_101, 8),
    BabelExp_102 is __CIL_FP_C,
    ptrR(C_SSA_1, BabelExp_102, 8),
    BabelExp_103 is __CIL_FP_ACTIVE2DNUM,
    ptrR(ACTIVE2DNUM_SSA_1, BabelExp_103, 8),
    BabelExp_104 is __CIL_FP_LEARN_PARM,
    ptrR(LEARN_PARM_SSA_1, BabelExp_104, 8),
    BabelExp_105 is __CIL_FP_SLACK,
    ptrR(SLACK_SSA_1, BabelExp_105, 8),
    BabelExp_106 is __CIL_FP_ALPHASLACK,
    ptrR(ALPHASLACK_SSA_1, BabelExp_106, 8),
    babelAssign(JJ_SSA_2, 0),
    babel__implicit_compute_shared_slacksc_18(DOCS_SSA_1, LABEL_SSA_1, A_SSA_1, LIN_SSA_1, C_SSA_1, ACTIVE2DNUM_SSA_1, LEARN_PARM_SSA_1, SLACK_SSA_1, ALPHASLACK_SSA_1, JJ_SSA_2),true. 

:- foreign(babel__implicit_identify_inconsistentc_19(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).

identify_inconsistent(__CIL_PP_RETRAIN, __CIL_FP_RETRAIN, A, LABEL, UNLABELED, TOTDOC, LEARN_PARM, INCONSISTENTNUM, INCONSISTENT, RETRAIN_SSA_2) :- 
    RETRAIN_SSA_1 is 0,
    I_SSA_1 is 0,
    ptrW(__CIL_FP_RETRAIN, 0, 8),
    babel__implicit_identify_inconsistentc_19(__CIL_PP_RETRAIN, A, UNLABELED, TOTDOC, LEARN_PARM, INCONSISTENTNUM, INCONSISTENT, I_SSA_1),
    ptrR(RETRAIN_SSA_2, __CIL_FP_RETRAIN, 8).

:- foreign(babel__implicit_identify_misclassifiedc_20(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).

identify_misclassified(__CIL_PP_RETRAIN, __CIL_FP_RETRAIN, LIN, LABEL, UNLABELED, TOTDOC, MODEL, INCONSISTENTNUM, INCONSISTENT, RETRAIN_SSA_2) :- 


    babelAssign(RETRAIN_SSA_1, 0),
    babelAssign(I_SSA_1, 0),
    BabelExp_109 is RETRAIN_SSA_1,
    ptrW(__CIL_FP_RETRAIN, BabelExp_109, 8),
    babel__implicit_identify_misclassifiedc_20(__CIL_PP_RETRAIN, LIN, LABEL, UNLABELED, TOTDOC, MODEL, INCONSISTENTNUM, INCONSISTENT, I_SSA_1),
    BabelExp_110 is __CIL_FP_RETRAIN,
    ptrR(RETRAIN_SSA_2, BabelExp_110, 8),true. 

:- foreign(babel__implicit_identify_one_misclassifiedc_21(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +float)).
:- foreign(babel__implicit_identify_one_misclassifiedc_22(+integer, +integer)).
:- foreign(babel__implicit_identify_one_misclassifiedc_23(+integer)).

identify_one_misclassified(__CIL_PP_STDOUT, __CIL_PP_VERBOSITY, __CIL_PP_INCONSISTENTNUM, __CIL_PP_INCONSISTENT, __CIL_PP_I, __CIL_PP_RETRAIN, __CIL_PP_MAXEX, __CIL_GP_VERBOSITY, __CIL_GP_STDOUT, __CIL_FP_INCONSISTENTNUM, __CIL_FP_INCONSISTENT, __CIL_FP_I, __CIL_FP_RETRAIN, __CIL_FP_MAXEX, LIN, LABEL, UNLABELED, TOTDOC, MODEL, INCONSISTENTNUM, INCONSISTENT, RETRAIN_SSA_3) :- 


    babelAssign(MAXEX_SSA_1, -1),
    babelAssign(MAXDIST_SSA_1, 0),
    babelAssign(RETRAIN_SSA_1, 0),
    babelAssign(I_SSA_1, 0),
    BabelExp_111 is INCONSISTENTNUM,
    ptrW(__CIL_FP_INCONSISTENTNUM, BabelExp_111, 8),
    BabelExp_112 is INCONSISTENT,
    ptrW(__CIL_FP_INCONSISTENT, BabelExp_112, 8),
    BabelExp_113 is I_SSA_1,
    ptrW(__CIL_FP_I, BabelExp_113, 8),
    BabelExp_114 is RETRAIN_SSA_1,
    ptrW(__CIL_FP_RETRAIN, BabelExp_114, 8),
    BabelExp_115 is MAXEX_SSA_1,
    ptrW(__CIL_FP_MAXEX, BabelExp_115, 8),
    babel__implicit_identify_one_misclassifiedc_21(__CIL_PP_STDOUT, __CIL_PP_VERBOSITY, __CIL_PP_INCONSISTENTNUM, __CIL_PP_INCONSISTENT, __CIL_PP_I, __CIL_PP_RETRAIN, __CIL_PP_MAXEX, LIN, LABEL, UNLABELED, TOTDOC, MODEL, MAXDIST_SSA_1),
    BabelExp_116 is __CIL_FP_INCONSISTENTNUM,
    ptrR(INCONSISTENTNUM_SSA_1, BabelExp_116, 8),
    BabelExp_117 is __CIL_FP_INCONSISTENT,
    ptrR(INCONSISTENT_SSA_1, BabelExp_117, 8),
    BabelExp_118 is __CIL_FP_I,
    ptrR(I_SSA_2, BabelExp_118, 8),
    BabelExp_119 is __CIL_FP_RETRAIN,
    ptrR(RETRAIN_SSA_2, BabelExp_119, 8),
    BabelExp_120 is __CIL_FP_MAXEX,
    ptrR(MAXEX_SSA_2, BabelExp_120, 8),

    (babelJcc(17, MAXEX_SSA_2, 0) ->
         babelAssign(__CIL_TMP37, 1)
     ; babelAssign(__CIL_TMP37, 0)),

    (babelJcc(13, __CIL_TMP37, 0) ->
         BabelExp_121 is INCONSISTENTNUM_SSA_1,
         ptrR(__CIL_TMP39, BabelExp_121, 8),
         BabelExp_122 is __CIL_TMP39 + 1,
         ptrW(INCONSISTENTNUM_SSA_1, BabelExp_122, 8),
         babelAssign(__CIL_TMP40, INCONSISTENT_SSA_1 +8* MAXEX_SSA_2),
         BabelExp_123 is 1,
         ptrW(__CIL_TMP40, BabelExp_123, 8),
         babelAssign(RETRAIN_SSA_3, 2),
         BabelExp_124 is __CIL_GP_VERBOSITY,
         ptrR(__CIL_TMP41, BabelExp_124, 8),

         (babelJcc(17, __CIL_TMP41, 3) ->
              babelAssign(__CIL_TMP38, 1)
          ; babelAssign(__CIL_TMP38, 0)),

         (babelJcc(13, __CIL_TMP38, 0) ->
              babel__implicit_identify_one_misclassifiedc_22('INCONSISTENT(%ld)..', I_SSA_2),
              BabelExp_125 is __CIL_GP_STDOUT,
              ptrR(__CIL_TMP42, BabelExp_125, 8),
              babel__implicit_identify_one_misclassifiedc_23(__CIL_TMP42)
          ; true)
     ; babelAssign(RETRAIN_SSA_3, RETRAIN_SSA_2)),
    true. 

:- foreign(babel__implicit_update_linear_componentc_0(+integer, +integer)).
:- foreign(babel__implicit_update_linear_componentc_1(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_update_linear_componentc_2(+integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_update_linear_componentc_3(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).

update_linear_component(__CIL_PP_DOCS, __CIL_PP_ACTIVE2DNUM, __CIL_PP_LIN, __CIL_PP_WEIGHTS, __CIL_FP_DOCS, __CIL_FP_ACTIVE2DNUM, __CIL_FP_LIN, __CIL_FP_WEIGHTS, DOCS, LABEL, ACTIVE2DNUM, A, A_OLD, WORKING2DNUM, TOTDOC, TOTWORDS, KERNEL_PARM, KERNEL_CACHE, LIN, AICACHE, WEIGHTS) :- 
    ptrR(__CIL_TMP36, KERNEL_PARM, 8),
    (__CIL_TMP36 =:= 0 ->
         babel__implicit_update_linear_componentc_0(WEIGHTS, TOTWORDS),
         babel__implicit_update_linear_componentc_1(__CIL_PP_DOCS, __CIL_PP_ACTIVE2DNUM, __CIL_PP_LIN, __CIL_PP_WEIGHTS, LABEL, A, A_OLD, WORKING2DNUM, 0),
         babel__implicit_update_linear_componentc_2(DOCS, ACTIVE2DNUM, LIN, WEIGHTS, 0)
     ;
     babel__implicit_update_linear_componentc_3(DOCS, LABEL, ACTIVE2DNUM, A, A_OLD, WORKING2DNUM, TOTDOC, KERNEL_PARM, KERNEL_CACHE, LIN, AICACHE, 0)).

:- foreign(babel__implicit_select_next_qp_slacksetc_4(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).

select_next_qp_slackset(__CIL_PP_MAXVIOL, __CIL_PP_MAXDIFFID, __CIL_PP_MAXDIFF, __CIL_FP_MAXVIOL, __CIL_FP_MAXDIFFID, __CIL_FP_MAXDIFF, DOCS, LABEL, A, LIN, SLACK, ALPHASLACK, C, LEARN_PARM, ACTIVE2DNUM, MAXVIOL, MAXDIFFID_SSA_2) :- 
    ptrW(__CIL_FP_MAXDIFFID, 0, 8),
    ptrWF(__CIL_FP_MAXDIFF, 0.0),
    babel__implicit_select_next_qp_slacksetc_4(__CIL_PP_MAXVIOL, __CIL_PP_MAXDIFFID, __CIL_PP_MAXDIFF, DOCS, LABEL, A, LIN, SLACK, ALPHASLACK, C, LEARN_PARM, ACTIVE2DNUM, 0),
    ptrR(MAXVIOL_SSA_1, __CIL_FP_MAXVIOL, 8),
    ptrR(MAXDIFFID_SSA_2, __CIL_FP_MAXDIFFID, 8),
    ptrRF(MAXDIFF_SSA_2, __CIL_FP_MAXDIFF),
    ptrWF(MAXVIOL_SSA_1, MAXDIFF_SSA_2).

:- foreign(babel__implicit_select_top_nc_5(+integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_select_top_nc_6(+integer, +integer, +integer, +integer, +integer)).

select_top_n(SELCRIT, RANGE, SELECT, N) :- 
    select_top_n_cil_lr_1(SELCRIT, RANGE, SELECT, N, 0),
    (N > 0 -> 
         select_top_n_cil_lr_2(SELCRIT, RANGE, SELECT, N, N); 
     true).

select_top_n_cil_lr_1(SELCRIT, RANGE, SELECT, N, I1):-
    (I1 >= N; I1 >= RANGE) -> true;
    (select_top_n_cil_lr_1_cil_lr_1(SELCRIT, SELECT, I1, I1),
    I2 is I1 + 1,
    select_top_n_cil_lr_1(SELCRIT, RANGE, SELECT, N, I2)).

select_top_n_cil_lr_1_cil_lr_1(SELCRIT, SELECT, I, J1):-
    J1 < 0 -> true;
    (((J1 > 0, (T1 is SELECT + (J1 - 1) * 8, ptrR(T2, T1, 8), T3 is SELCRIT + T2 * 8, ptrRF(T4, T3), T5 is SELCRIT + I * 8, ptrRF(T6, T5), T4 < T6)) -> (T7 is SELECT + J1 * 8, ptrW(T7, T2, 8), J2 is J1); (T7 is SELECT + J1 * 8, ptrW(T7, I, 8), J2 is -1)),
    J3 is J2 - 1,
    select_top_n_cil_lr_1_cil_lr_1(SELCRIT, SELECT, I, J3)).
    
select_top_n_cil_lr_2(SELCRIT, RANGE, SELECT, N, I1) :-
    I1 >= RANGE -> true;(
    T1 is SELCRIT + I1 * 8,
    ptrRF(T2, T1),
    T3 is SELECT + (N - 1) * 8,
    ptrR(T4, T3, 8),
    T5 is SELCRIT + T4 * 8,
    ptrRF(T6, T5),
    (T2 =< T6 -> true; (
    J is N - 1,
    select_top_n_cil_lr_1_cil_lr_1(SELCRIT, SELECT, I1, J))),
    I2 is I1 + 1,
    select_top_n_cil_lr_2(SELCRIT, RANGE, SELECT, N, I2)).
    


:- foreign(babel__implicit_init_shrink_statec_7(+positive,  -integer)).
:- foreign(babel__implicit_init_shrink_statec_8(+positive,  -integer)).
:- foreign(babel__implicit_init_shrink_statec_9(+positive,  -integer)).
:- foreign(babel__implicit_init_shrink_statec_10(+positive,  -integer)).
:- foreign(babel__implicit_init_shrink_statec_11(+positive,  -integer)).
:- foreign(babel__implicit_init_shrink_statec_12(+integer, +integer, +integer)).

init_shrink_state(SHRINK_STATE, TOTDOC, MAXHISTORY, VOID) :- 
    babelAssign(__CIL_TMP16, SHRINK_STATE +1* 16),
    babelAssign(__CIL_TMP17, __CIL_TMP16),
    BabelExp_24 is 0,
    ptrW(__CIL_TMP17, BabelExp_24, 8),
    BabelExp_25 is 8 * TOTDOC,
    babelAssign(__CIL_TMP18, BabelExp_25),
    babel__implicit_init_shrink_statec_7(__CIL_TMP18 , TMP_SSA_1),
    babelAssign(MEM_27, SHRINK_STATE),
    BabelExp_26 is TMP_SSA_1,
    ptrW(MEM_27, BabelExp_26, 8),
    BabelExp_27 is 8 * TOTDOC,
    babelAssign(__CIL_TMP19, BabelExp_27),
    babel__implicit_init_shrink_statec_8(__CIL_TMP19 , TMP___0_SSA_1),
    babelAssign(__CIL_TMP20, SHRINK_STATE +1* 8),
    babelAssign(__CIL_TMP21, __CIL_TMP20),
    BabelExp_28 is TMP___0_SSA_1,
    ptrW(__CIL_TMP21, BabelExp_28, 8),
    BabelExp_29 is 8 * MAXHISTORY,
    babelAssign(__CIL_TMP22, BabelExp_29),
    babel__implicit_init_shrink_statec_9(__CIL_TMP22 , TMP___1_SSA_1),
    babelAssign(__CIL_TMP23, SHRINK_STATE +1* 24),
    babelAssign(__CIL_TMP24, __CIL_TMP23),
    BabelExp_30 is TMP___1_SSA_1,
    ptrW(__CIL_TMP24, BabelExp_30, 8),
    babelAssign(__CIL_TMP25, SHRINK_STATE +1* 32),
    babelAssign(__CIL_TMP26, __CIL_TMP25),
    BabelExp_31 is MAXHISTORY,
    ptrW(__CIL_TMP26, BabelExp_31, 8),
    BabelExp_32 is 8 * TOTDOC,
    babelAssign(__CIL_TMP27, BabelExp_32),
    babel__implicit_init_shrink_statec_10(__CIL_TMP27 , TMP___2_SSA_1),
    babelAssign(__CIL_TMP28, SHRINK_STATE +1* 48),
    babelAssign(__CIL_TMP29, __CIL_TMP28),
    BabelExp_33 is TMP___2_SSA_1,
    ptrW(__CIL_TMP29, BabelExp_33, 8),
    BabelExp_34 is 8 * TOTDOC,
    babelAssign(__CIL_TMP30, BabelExp_34),
    babel__implicit_init_shrink_statec_11(__CIL_TMP30 , TMP___3_SSA_1),
    babelAssign(__CIL_TMP31, SHRINK_STATE +1* 40),
    babelAssign(__CIL_TMP32, __CIL_TMP31),
    BabelExp_35 is TMP___3_SSA_1,
    ptrW(__CIL_TMP32, BabelExp_35, 8),
    babelAssign(I_SSA_1, 0),
    init_shrink_state_cil_lr_1(SHRINK_STATE, TOTDOC, I_SSA_1).
    
init_shrink_state_cil_lr_1(SHRINK_STATE, TOTDOC, I1):-
    I1 >= TOTDOC -> true;
    (
        ptrR(T1, SHRINK_STATE, 8),
        T2 is T1 + I1 * 8,
        ptrW(T2, 1, 8),
        T3 is SHRINK_STATE + 8,
        ptrR(T4, T3, 8),
        T5 is T4 + I1 * 8,
        ptrW(T5, 0, 8),
        T6 is SHRINK_STATE + 40,
        ptrR(T7, T6, 8),
        T8 is T7 + I1 * 8,
        ptrWF(T8, 0.0),
        T9 is SHRINK_STATE + 48,
        ptrR(T10, T9, 8),
        T11 is T10 + I1 * 8,
        ptrWF(T11, 0.0),
        I2 is I1 + 1,
        init_shrink_state_cil_lr_1(SHRINK_STATE, TOTDOC, I2)
    ).
        
:- foreign(babel__implicit_shrink_state_cleanupc_13(+integer)).
:- foreign(babel__implicit_shrink_state_cleanupc_14(+integer)).
:- foreign(babel__implicit_shrink_state_cleanupc_15(+integer)).
:- foreign(babel__implicit_shrink_state_cleanupc_16(+integer)).
:- foreign(babel__implicit_shrink_state_cleanupc_17(+integer)).
:- foreign(babel__implicit_shrink_state_cleanupc_18(+integer)).

shrink_state_cleanup(SHRINK_STATE) :- 
    ptrR(__CIL_TMP3, SHRINK_STATE, 8),
    babel__implicit_shrink_state_cleanupc_13(__CIL_TMP3),
    babelAssign(__CIL_TMP5, SHRINK_STATE +8),
    ptrR(__CIL_TMP6, __CIL_TMP5, 8),
    babel__implicit_shrink_state_cleanupc_14(__CIL_TMP6),
    __CIL_TMP8 is SHRINK_STATE +16,
    ptrR(__CIL_TMP9, __CIL_TMP8, 8),

    (babelJcc(14, __CIL_TMP9, 0) ->
         babelAssign(__CIL_TMP2, 1)
     ; babelAssign(__CIL_TMP2, 0)),

    (babelJcc(13, __CIL_TMP2, 0) ->
         babelAssign(__CIL_TMP10, SHRINK_STATE +1* 24),
         babelAssign(__CIL_TMP11, __CIL_TMP10),
         babelAssign(__CIL_TMP12, SHRINK_STATE +1* 16),
         babelAssign(__CIL_TMP13, __CIL_TMP12),
         BabelExp_39 is __CIL_TMP13,
         ptrR(__CIL_TMP14, BabelExp_39, 8),
         BabelExp_40 is __CIL_TMP11,
         ptrR(__CIL_TMP15, BabelExp_40, 8),
         BabelExp_41 is __CIL_TMP14 - 1,
         babelAssign(__CIL_TMP16, BabelExp_41),
         babelAssign(__CIL_TMP17, __CIL_TMP15 +8* __CIL_TMP16),
         BabelExp_42 is __CIL_TMP17,
         ptrR(__CIL_TMP18, BabelExp_42, 8),
         babel__implicit_shrink_state_cleanupc_15(__CIL_TMP18)
     ; true),
    (__CIL_TMP20 is SHRINK_STATE +24),
    ptrR(__CIL_TMP21, __CIL_TMP20, 8),
    babel__implicit_shrink_state_cleanupc_16(__CIL_TMP21),
    babelAssign(__CIL_TMP23, SHRINK_STATE + 40),
    ptrR(__CIL_TMP24, __CIL_TMP23, 8),
    babel__implicit_shrink_state_cleanupc_17(__CIL_TMP24),
    __CIL_TMP26 is SHRINK_STATE + 48,
    ptrR(__CIL_TMP27, __CIL_TMP26, 8),
    babel__implicit_shrink_state_cleanupc_18(__CIL_TMP27).

:- foreign(babel__implicit_get_kernel_rowc_19(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_get_kernel_rowc_20(+integer, +integer, +integer, +integer, +integer, +integer)).

get_kernel_row(KERNEL_CACHE, DOCS, DOCNUM, TOTDOC, ACTIVE2DNUM, BUFFER, KERNEL_PARM, VOID) :- 
    babelAssign(__CIL_TMP18, DOCS +1* DOCNUM),
    BabelExp_46 is __CIL_TMP18,
    ptrR(EX_SSA_1, BabelExp_46, 8),
    babelAssign(MEM_31, KERNEL_CACHE),
    BabelExp_47 is MEM_31,
    ptrR(__CIL_TMP19, BabelExp_47, 8),
    babelAssign(__CIL_TMP20, __CIL_TMP19 +8* DOCNUM),
    BabelExp_48 is __CIL_TMP20,
    ptrR(__CIL_TMP21, BabelExp_48, 8),

    (babelJcc(13, __CIL_TMP21, -1) ->
         babelAssign(__CIL_TMP17, 1)
     ; babelAssign(__CIL_TMP17, 0)),

    (babelJcc(13, __CIL_TMP17, 0) ->
         babelAssign(__CIL_TMP22, KERNEL_CACHE +1* 72),
         babelAssign(__CIL_TMP23, __CIL_TMP22),
         babelAssign(__CIL_TMP24, KERNEL_CACHE +1* 40),
         babelAssign(__CIL_TMP25, __CIL_TMP24),
         babelAssign(MEM_32, KERNEL_CACHE),
         BabelExp_49 is MEM_32,
         ptrR(__CIL_TMP26, BabelExp_49, 8),
         babelAssign(__CIL_TMP27, __CIL_TMP26 +8* DOCNUM),
         BabelExp_50 is __CIL_TMP25,
         ptrR(__CIL_TMP28, BabelExp_50, 8),
         BabelExp_51 is __CIL_TMP27,
         ptrR(__CIL_TMP29, BabelExp_51, 8),
         babelAssign(__CIL_TMP30, __CIL_TMP28 +8* __CIL_TMP29),
         ptrR(BabelExp_52, __CIL_TMP23, 8),
         ptrW(__CIL_TMP30, BabelExp_52, 8),
         babelAssign(__CIL_TMP31, KERNEL_CACHE +1* 80),
         babelAssign(__CIL_TMP32, __CIL_TMP31),
         babelAssign(MEM_33, KERNEL_CACHE),
         BabelExp_53 is MEM_33,
         ptrR(__CIL_TMP33, BabelExp_53, 8),
         babelAssign(__CIL_TMP34, __CIL_TMP33 +8* DOCNUM),
         BabelExp_54 is __CIL_TMP32,
         ptrR(__CIL_TMP35, BabelExp_54, 8),
         BabelExp_55 is __CIL_TMP34,
         ptrR(__CIL_TMP36, BabelExp_55, 8),
         BabelExp_56 is __CIL_TMP35 * __CIL_TMP36,
         babelAssign(START_SSA_1, BabelExp_56),
         babelAssign(I_SSA_1, 0),
         babel__implicit_get_kernel_rowc_19(KERNEL_CACHE, DOCS, ACTIVE2DNUM, BUFFER, KERNEL_PARM, I_SSA_1, START_SSA_1, EX_SSA_1)
     ; babelAssign(I_SSA_1, 0),
       babel__implicit_get_kernel_rowc_20(DOCS, ACTIVE2DNUM, BUFFER, KERNEL_PARM, I_SSA_1, EX_SSA_1)),
    true. 

:- foreign(babel__implicit_cache_kernel_rowc_21(+integer, +integer,  -integer)).
:- foreign(babel__implicit_cache_kernel_rowc_22(+integer, +integer,  -integer)).
:- foreign(babel__implicit_cache_kernel_rowc_23(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_cache_kernel_rowc_24(+string)).

cache_kernel_row(KERNEL_CACHE, DOCS, M, KERNEL_PARM, VOID) :- 


    babel__implicit_cache_kernel_rowc_21(KERNEL_CACHE, M , TMP___0_SSA_1),
    (babelJcc(12, TMP___0_SSA_1, 0) ->
         babel__implicit_cache_kernel_rowc_22(KERNEL_CACHE, M , CACHE_SSA_1),
         (babelJcc(13, CACHE_SSA_1, 0) ->
              babelAssign(__CIL_TMP17, KERNEL_CACHE +1* 32),
              babelAssign(__CIL_TMP18, __CIL_TMP17),
              BabelExp_57 is __CIL_TMP18,
              ptrR(__CIL_TMP19, BabelExp_57, 8),
              babelAssign(__CIL_TMP20, __CIL_TMP19 +8* M),
              BabelExp_58 is __CIL_TMP20,
              ptrR(L_SSA_1, BabelExp_58, 8),
              babelAssign(__CIL_TMP21, DOCS +1* M),
              BabelExp_59 is __CIL_TMP21,
              ptrR(EX_SSA_1, BabelExp_59, 8),
              babelAssign(J_SSA_1, 0),
              babel__implicit_cache_kernel_rowc_23(KERNEL_CACHE, DOCS, M, KERNEL_PARM, EX_SSA_1, J_SSA_1, L_SSA_1, CACHE_SSA_1)
          ; babel__implicit_cache_kernel_rowc_24('Error: Kernel cache full! => increase cache size'))
     ; true),
    true. 

:- foreign(babel__implicit_kernel_cache_shrinkc_25(+integer)).
:- foreign(babel__implicit_kernel_cache_shrinkc_26(+integer)).
:- foreign(babel__implicit_kernel_cache_shrinkc_27(+positive,  -integer)).
:- foreign(babel__implicit_kernel_cache_shrinkc_28(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_kernel_cache_shrinkc_29(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_kernel_cache_shrinkc_30(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_kernel_cache_shrinkc_31(+integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_kernel_cache_shrinkc_32(+integer)).
:- foreign(babel__implicit_kernel_cache_shrinkc_33(+integer)).
:- foreign(babel__implicit_kernel_cache_shrinkc_34(+integer)).
:- foreign(babel__implicit_kernel_cache_shrinkc_35(+integer, +integer)).

kernel_cache_shrink(__CIL_PP_STDOUT, __CIL_PP_VERBOSITY, __CIL_PP_KERNEL_CACHE, __CIL_PP_TOTDOC, __CIL_PP_NUMSHRINK, __CIL_PP_AFTER, __CIL_PP_FROM, __CIL_PP_TO, __CIL_PP_KEEP, __CIL_GP_VERBOSITY, __CIL_GP_STDOUT, __CIL_FP_KERNEL_CACHE, __CIL_FP_TOTDOC, __CIL_FP_NUMSHRINK, __CIL_FP_AFTER, __CIL_FP_FROM, __CIL_FP_TO, __CIL_FP_KEEP, KERNEL_CACHE, TOTDOC, NUMSHRINK, AFTER, VOID) :- 


    babelAssign(FROM_SSA_1, 0),
    babelAssign(TO_SSA_1, 0),
    BabelExp_60 is __CIL_GP_VERBOSITY,
    ptrR(__CIL_TMP61, BabelExp_60, 8),

    (babelJcc(17, __CIL_TMP61, 2) ->
         babelAssign(__CIL_TMP58, 1)
     ; babelAssign(__CIL_TMP58, 0)),

    (babelJcc(13, __CIL_TMP58, 0) ->
         babel__implicit_kernel_cache_shrinkc_25(' REORGANIZING CACHE...'),
         BabelExp_61 is __CIL_GP_STDOUT,
         ptrR(__CIL_TMP62, BabelExp_61, 8),
         babel__implicit_kernel_cache_shrinkc_26(__CIL_TMP62)
     ; true),
    BabelExp_62 is 8 * TOTDOC,
    babelAssign(__CIL_TMP63, BabelExp_62),
    babel__implicit_kernel_cache_shrinkc_27(__CIL_TMP63 , TMP_SSA_1),
    babelAssign(KEEP_SSA_1, TMP_SSA_1),
    babelAssign(J_SSA_1, 0),
    BabelExp_63 is KERNEL_CACHE,
    ptrW(__CIL_FP_KERNEL_CACHE, BabelExp_63, 8),
    BabelExp_64 is TOTDOC,
    ptrW(__CIL_FP_TOTDOC, BabelExp_64, 8),
    BabelExp_65 is NUMSHRINK,
    ptrW(__CIL_FP_NUMSHRINK, BabelExp_65, 8),
    BabelExp_66 is AFTER,
    ptrW(__CIL_FP_AFTER, BabelExp_66, 8),
    BabelExp_67 is FROM_SSA_1,
    ptrW(__CIL_FP_FROM, BabelExp_67, 8),
    BabelExp_68 is TO_SSA_1,
    ptrW(__CIL_FP_TO, BabelExp_68, 8),
    BabelExp_69 is KEEP_SSA_1,
    ptrW(__CIL_FP_KEEP, BabelExp_69, 8),
    babel__implicit_kernel_cache_shrinkc_28(__CIL_PP_STDOUT, __CIL_PP_VERBOSITY, __CIL_PP_KERNEL_CACHE, __CIL_PP_TOTDOC, __CIL_PP_NUMSHRINK, __CIL_PP_AFTER, __CIL_PP_FROM, __CIL_PP_TO, __CIL_PP_KEEP, J_SSA_1),
    BabelExp_70 is __CIL_FP_KERNEL_CACHE,
    ptrR(KERNEL_CACHE_SSA_1, BabelExp_70, 8),
    BabelExp_71 is __CIL_FP_TOTDOC,
    ptrR(TOTDOC_SSA_1, BabelExp_71, 8),
    BabelExp_72 is __CIL_FP_NUMSHRINK,
    ptrR(NUMSHRINK_SSA_1, BabelExp_72, 8),
    BabelExp_73 is __CIL_FP_AFTER,
    ptrR(AFTER_SSA_1, BabelExp_73, 8),
    BabelExp_74 is __CIL_FP_FROM,
    ptrR(FROM_SSA_2, BabelExp_74, 8),
    BabelExp_75 is __CIL_FP_TO,
    ptrR(TO_SSA_2, BabelExp_75, 8),
    BabelExp_76 is __CIL_FP_KEEP,
    ptrR(KEEP_SSA_2, BabelExp_76, 8),
    babelAssign(SCOUNT_SSA_1, 0),
    babelAssign(JJ_SSA_1, 0),
    BabelExp_77 is KERNEL_CACHE_SSA_1,
    ptrW(__CIL_FP_KERNEL_CACHE, BabelExp_77, 8),
    BabelExp_78 is TOTDOC_SSA_1,
    ptrW(__CIL_FP_TOTDOC, BabelExp_78, 8),
    BabelExp_79 is FROM_SSA_2,
    ptrW(__CIL_FP_FROM, BabelExp_79, 8),
    BabelExp_80 is TO_SSA_2,
    ptrW(__CIL_FP_TO, BabelExp_80, 8),
    BabelExp_81 is KEEP_SSA_2,
    ptrW(__CIL_FP_KEEP, BabelExp_81, 8),
    babel__implicit_kernel_cache_shrinkc_29(__CIL_PP_STDOUT, __CIL_PP_VERBOSITY, __CIL_PP_KERNEL_CACHE, __CIL_PP_TOTDOC, __CIL_PP_FROM, __CIL_PP_TO, __CIL_PP_KEEP, NUMSHRINK_SSA_1, AFTER_SSA_1, JJ_SSA_1, SCOUNT_SSA_1),
    BabelExp_82 is __CIL_FP_KERNEL_CACHE,
    ptrR(KERNEL_CACHE_SSA_2, BabelExp_82, 8),
    BabelExp_83 is __CIL_FP_TOTDOC,
    ptrR(TOTDOC_SSA_2, BabelExp_83, 8),
    BabelExp_84 is __CIL_FP_FROM,
    ptrR(FROM_SSA_3, BabelExp_84, 8),
    BabelExp_85 is __CIL_FP_TO,
    ptrR(TO_SSA_3, BabelExp_85, 8),
    BabelExp_86 is __CIL_FP_KEEP,
    ptrR(KEEP_SSA_3, BabelExp_86, 8),
    babelAssign(I_SSA_1, 0),
    BabelExp_87 is KERNEL_CACHE_SSA_2,
    ptrW(__CIL_FP_KERNEL_CACHE, BabelExp_87, 8),
    BabelExp_88 is TOTDOC_SSA_2,
    ptrW(__CIL_FP_TOTDOC, BabelExp_88, 8),
    BabelExp_89 is KEEP_SSA_3,
    ptrW(__CIL_FP_KEEP, BabelExp_89, 8),
    babel__implicit_kernel_cache_shrinkc_30(__CIL_PP_STDOUT, __CIL_PP_VERBOSITY, __CIL_PP_KERNEL_CACHE, __CIL_PP_TOTDOC, __CIL_PP_KEEP, I_SSA_1, FROM_SSA_3, TO_SSA_3),
    BabelExp_90 is __CIL_FP_KERNEL_CACHE,
    ptrR(KERNEL_CACHE_SSA_3, BabelExp_90, 8),
    BabelExp_91 is __CIL_FP_TOTDOC,
    ptrR(TOTDOC_SSA_3, BabelExp_91, 8),
    BabelExp_92 is __CIL_FP_KEEP,
    ptrR(KEEP_SSA_4, BabelExp_92, 8),
    babelAssign(__CIL_TMP64, KERNEL_CACHE_SSA_3 +1* 80),
    babelAssign(__CIL_TMP65, __CIL_TMP64),
    BabelExp_93 is 0,
    ptrW(__CIL_TMP65, BabelExp_93, 8),
    babelAssign(J_SSA_2, 0),
    BabelExp_94 is KERNEL_CACHE_SSA_3,
    ptrW(__CIL_FP_KERNEL_CACHE, BabelExp_94, 8),
    BabelExp_95 is TOTDOC_SSA_3,
    ptrW(__CIL_FP_TOTDOC, BabelExp_95, 8),
    BabelExp_96 is KEEP_SSA_4,
    ptrW(__CIL_FP_KEEP, BabelExp_96, 8),
    babel__implicit_kernel_cache_shrinkc_31(__CIL_PP_STDOUT, __CIL_PP_VERBOSITY, __CIL_PP_KERNEL_CACHE, __CIL_PP_TOTDOC, __CIL_PP_KEEP, J_SSA_2),
    BabelExp_97 is __CIL_FP_KERNEL_CACHE,
    ptrR(KERNEL_CACHE_SSA_4, BabelExp_97, 8),
    BabelExp_98 is __CIL_FP_TOTDOC,
    ptrR(TOTDOC_SSA_4, BabelExp_98, 8),
    BabelExp_99 is __CIL_FP_KEEP,
    ptrR(KEEP_SSA_5, BabelExp_99, 8),
    babelAssign(__CIL_TMP66, KERNEL_CACHE_SSA_4 +1* 88),
    babelAssign(__CIL_TMP67, __CIL_TMP66),
    babelAssign(__CIL_TMP68, KERNEL_CACHE_SSA_4 +1* 80),
    babelAssign(__CIL_TMP69, __CIL_TMP68),
    BabelExp_100 is __CIL_TMP67,
    ptrR(__CIL_TMP70, BabelExp_100, 8),
    BabelExp_101 is __CIL_TMP69,
    ptrR(__CIL_TMP71, BabelExp_101, 8),
    babelAssign(__CIL_TMP72, KERNEL_CACHE_SSA_4 +1* 64),
    babelAssign(__CIL_TMP73, __CIL_TMP72),
    BabelExp_102 is __CIL_TMP70 / __CIL_TMP71,
    ptrW(__CIL_TMP73, BabelExp_102, 8),
    babelAssign(__CIL_TMP74, KERNEL_CACHE_SSA_4 +1* 64),
    babelAssign(__CIL_TMP75, __CIL_TMP74),
    BabelExp_103 is __CIL_TMP75,
    ptrR(__CIL_TMP76, BabelExp_103, 8),

    (babelJcc(14, __CIL_TMP76, TOTDOC_SSA_4) ->
         babelAssign(__CIL_TMP59, 1)
     ; babelAssign(__CIL_TMP59, 0)),

    (babelJcc(13, __CIL_TMP59, 0) ->
         babelAssign(__CIL_TMP77, KERNEL_CACHE_SSA_4 +1* 64),
         babelAssign(__CIL_TMP78, __CIL_TMP77),
         BabelExp_104 is TOTDOC_SSA_4,
         ptrW(__CIL_TMP78, BabelExp_104, 8)
     ; true),
    babel__implicit_kernel_cache_shrinkc_32(KEEP_SSA_5),
    BabelExp_105 is __CIL_GP_VERBOSITY,
    ptrR(__CIL_TMP79, BabelExp_105, 8),

    (babelJcc(17, __CIL_TMP79, 2) ->
         babelAssign(__CIL_TMP60, 1)
     ; babelAssign(__CIL_TMP60, 0)),

    (babelJcc(13, __CIL_TMP60, 0) ->
         babel__implicit_kernel_cache_shrinkc_33('DONE.\\N'),
         BabelExp_106 is __CIL_GP_STDOUT,
         ptrR(__CIL_TMP80, BabelExp_106, 8),
         babel__implicit_kernel_cache_shrinkc_34(__CIL_TMP80),
         babelAssign(__CIL_TMP81, KERNEL_CACHE_SSA_4 +1* 64),
         babelAssign(__CIL_TMP82, __CIL_TMP81),
         BabelExp_107 is __CIL_TMP82,
         ptrR(__CIL_TMP83, BabelExp_107, 8),
         babel__implicit_kernel_cache_shrinkc_35(' CACHE-SIZE IN ROWS = %ld\\N', __CIL_TMP83)
     ; true),
    true. 


:- foreign(babel__implicit_kernel_cache_initc_0(+integer, -integer)).
:- foreign(babel__implicit_kernel_cache_initc_1(+positive,  -integer)).
:- foreign(babel__implicit_kernel_cache_initc_2(+positive,  -integer)).
:- foreign(babel__implicit_kernel_cache_initc_3(+positive,  -integer)).
:- foreign(babel__implicit_kernel_cache_initc_4(+positive,  -integer)).
:- foreign(babel__implicit_kernel_cache_initc_5(+positive,  -integer)).
:- foreign(babel__implicit_kernel_cache_initc_6(+positive,  -integer)).
:- foreign(babel__implicit_kernel_cache_initc_7(+positive,  -integer)).
:- foreign(babel__implicit_kernel_cache_initc_8(+integer, +integer)).
:- foreign(babel__implicit_kernel_cache_initc_9(+integer, +integer)).
:- foreign(babel__implicit_kernel_cache_initc_10(+integer, +integer, +integer)).
:- foreign(babel__implicit_kernel_cache_initc_11(+integer, +integer, +integer)).
:- foreign(babel__implicit_kernel_cache_initc_12(+integer, +integer, +integer)).

kernel_cache_init(__CIL_PP_TOTDOC, __CIL_PP_KERNEL_CACHE, __CIL_GP_VERBOSITY, __CIL_GP_KERNEL_CACHE_STATISTIC, __CIL_FP_TOTDOC, __CIL_FP_KERNEL_CACHE, TOTDOC, BUFFSIZE, KERNEL_CACHE_SSA_4) :- 


    babel__implicit_kernel_cache_initc_0(96 , TMP_SSA_1),
    babelAssign(KERNEL_CACHE_SSA_1, TMP_SSA_1),
    BabelExp_0 is 8 * TOTDOC,
    babelAssign(__CIL_TMP38, BabelExp_0),
    babel__implicit_kernel_cache_initc_1(__CIL_TMP38 , TMP___0_SSA_1),
    babelAssign(MEM_75, KERNEL_CACHE_SSA_1),
    BabelExp_1 is TMP___0_SSA_1,
    ptrW(MEM_75, BabelExp_1, 8),
    BabelExp_2 is 8 * TOTDOC,
    babelAssign(__CIL_TMP39, BabelExp_2),
    babel__implicit_kernel_cache_initc_2(__CIL_TMP39 , TMP___1_SSA_1),
    babelAssign(__CIL_TMP40, KERNEL_CACHE_SSA_1 +1* 48),
    babelAssign(__CIL_TMP41, __CIL_TMP40),
    BabelExp_3 is TMP___1_SSA_1,
    ptrW(__CIL_TMP41, BabelExp_3, 8),
    BabelExp_4 is 8 * TOTDOC,
    babelAssign(__CIL_TMP42, BabelExp_4),
    babel__implicit_kernel_cache_initc_3(__CIL_TMP42 , TMP___2_SSA_1),
    babelAssign(__CIL_TMP43, KERNEL_CACHE_SSA_1 +1* 40),
    babelAssign(__CIL_TMP44, __CIL_TMP43),
    BabelExp_5 is TMP___2_SSA_1,
    ptrW(__CIL_TMP44, BabelExp_5, 8),
    BabelExp_6 is 8 * TOTDOC,
    babelAssign(__CIL_TMP45, BabelExp_6),
    babel__implicit_kernel_cache_initc_4(__CIL_TMP45 , TMP___3_SSA_1),
    babelAssign(__CIL_TMP46, KERNEL_CACHE_SSA_1 +1* 16),
    babelAssign(__CIL_TMP47, __CIL_TMP46),
    BabelExp_7 is TMP___3_SSA_1,
    ptrW(__CIL_TMP47, BabelExp_7, 8),
    BabelExp_8 is 8 * TOTDOC,
    babelAssign(__CIL_TMP48, BabelExp_8),
    babel__implicit_kernel_cache_initc_5(__CIL_TMP48 , TMP___4_SSA_1),
    babelAssign(__CIL_TMP49, KERNEL_CACHE_SSA_1 +1* 24),
    babelAssign(__CIL_TMP50, __CIL_TMP49),
    BabelExp_9 is TMP___4_SSA_1,
    ptrW(__CIL_TMP50, BabelExp_9, 8),
    BabelExp_10 is 8 * TOTDOC,
    babelAssign(__CIL_TMP51, BabelExp_10),
    babel__implicit_kernel_cache_initc_6(__CIL_TMP51 , TMP___5_SSA_1),
    babelAssign(__CIL_TMP52, KERNEL_CACHE_SSA_1 +1* 32),
    babelAssign(__CIL_TMP53, __CIL_TMP52),
    BabelExp_11 is TMP___5_SSA_1,
    ptrW(__CIL_TMP53, BabelExp_11, 8),
    BabelExp_12 is BUFFSIZE * 1024,
    babelAssign(__CIL_TMP54, BabelExp_12),
    BabelExp_13 is __CIL_TMP54 * 1024,
    babelAssign(__CIL_TMP55, BabelExp_13),
    babel__implicit_kernel_cache_initc_7(__CIL_TMP55 , TMP___6_SSA_1),
    babelAssign(__CIL_TMP56, KERNEL_CACHE_SSA_1 +1* 8),
    babelAssign(__CIL_TMP57, __CIL_TMP56),
    BabelExp_14 is TMP___6_SSA_1,
    ptrW(__CIL_TMP57, BabelExp_14, 8),
    BabelExp_15 is BUFFSIZE // 4,
    babelAssign(__CIL_TMP58, BabelExp_15),
    BabelExp_16 is __CIL_TMP58 * 1024,
    babelAssign(__CIL_TMP59, BabelExp_16),
    BabelExp_17 is __CIL_TMP59 * 1024,
    babelAssign(__CIL_TMP60, BabelExp_17),
    babelAssign(__CIL_TMP61, KERNEL_CACHE_SSA_1 +1* 88),
    babelAssign(__CIL_TMP62, __CIL_TMP61),
    BabelExp_18 is __CIL_TMP60,
    ptrW(__CIL_TMP62, BabelExp_18, 8),
    babelAssign(__CIL_TMP63, KERNEL_CACHE_SSA_1 +1* 88),
    babelAssign(__CIL_TMP64, __CIL_TMP63),
    BabelExp_19 is __CIL_TMP64,
    ptrR(__CIL_TMP65, BabelExp_19, 8),
    babelAssign(__CIL_TMP66, KERNEL_CACHE_SSA_1 +1* 64),
    babelAssign(__CIL_TMP67, __CIL_TMP66),
    BabelExp_20 is __CIL_TMP65 // TOTDOC,
    ptrW(__CIL_TMP67, BabelExp_20, 8),
    babelAssign(__CIL_TMP68, KERNEL_CACHE_SSA_1 +1* 64),
    babelAssign(__CIL_TMP69, __CIL_TMP68),
    BabelExp_21 is __CIL_TMP69,
    ptrR(__CIL_TMP70, BabelExp_21, 8),

    (babelJcc(14, __CIL_TMP70, TOTDOC) ->
         babelAssign(__CIL_TMP36, 1)
     ; babelAssign(__CIL_TMP36, 0)),

    (babelJcc(13, __CIL_TMP36, 0) ->
         babelAssign(__CIL_TMP71, KERNEL_CACHE_SSA_1 +1* 64),
         babelAssign(__CIL_TMP72, __CIL_TMP71),
         BabelExp_22 is TOTDOC,
         ptrW(__CIL_TMP72, BabelExp_22, 8)
     ; true),
    BabelExp_23 is __CIL_GP_VERBOSITY,
    ptrR(__CIL_TMP73, BabelExp_23, 8),

    (babelJcc(17, __CIL_TMP73, 2) ->
         babelAssign(__CIL_TMP37, 1)
     ; babelAssign(__CIL_TMP37, 0)),

    (babelJcc(13, __CIL_TMP37, 0) ->
         babelAssign(__CIL_TMP74, KERNEL_CACHE_SSA_1 +1* 64),
         babelAssign(__CIL_TMP75, __CIL_TMP74),
         BabelExp_24 is __CIL_TMP75,
         ptrR(__CIL_TMP76, BabelExp_24, 8),
         babel__implicit_kernel_cache_initc_8(' CACHE-SIZE IN ROWS = %ld\\n', __CIL_TMP76),
         BabelExp_25 is __CIL_GP_KERNEL_CACHE_STATISTIC,
         ptrR(__CIL_TMP77, BabelExp_25, 8),
         babel__implicit_kernel_cache_initc_9(' KERNEL EVALS SO FAR: %ld\\n', __CIL_TMP77)
     ; true),
    babelAssign(__CIL_TMP78, KERNEL_CACHE_SSA_1 +1* 56),
    babelAssign(__CIL_TMP79, __CIL_TMP78),
    BabelExp_26 is 0,
    ptrW(__CIL_TMP79, BabelExp_26, 8),
    babelAssign(I_SSA_1, 0),
    BabelExp_27 is TOTDOC,
    ptrW(__CIL_FP_TOTDOC, BabelExp_27, 8),
    BabelExp_28 is KERNEL_CACHE_SSA_1,
    ptrW(__CIL_FP_KERNEL_CACHE, BabelExp_28, 8),
    babel__implicit_kernel_cache_initc_10(__CIL_PP_TOTDOC, __CIL_PP_KERNEL_CACHE, I_SSA_1),
    BabelExp_29 is __CIL_FP_TOTDOC,
    ptrR(TOTDOC_SSA_1, BabelExp_29, 8),
    BabelExp_30 is __CIL_FP_KERNEL_CACHE,
    ptrR(KERNEL_CACHE_SSA_2, BabelExp_30, 8),
    babelAssign(I_SSA_2, 0),
    BabelExp_31 is TOTDOC_SSA_1,
    ptrW(__CIL_FP_TOTDOC, BabelExp_31, 8),
    BabelExp_32 is KERNEL_CACHE_SSA_2,
    ptrW(__CIL_FP_KERNEL_CACHE, BabelExp_32, 8),
    babel__implicit_kernel_cache_initc_11(__CIL_PP_TOTDOC, __CIL_PP_KERNEL_CACHE, I_SSA_2),
    BabelExp_33 is __CIL_FP_TOTDOC,
    ptrR(TOTDOC_SSA_2, BabelExp_33, 8),
    BabelExp_34 is __CIL_FP_KERNEL_CACHE,
    ptrR(KERNEL_CACHE_SSA_3, BabelExp_34, 8),
    babelAssign(__CIL_TMP80, KERNEL_CACHE_SSA_3 +1* 80),
    babelAssign(__CIL_TMP81, __CIL_TMP80),
    BabelExp_35 is TOTDOC_SSA_2,
    ptrW(__CIL_TMP81, BabelExp_35, 8),
    babelAssign(I_SSA_3, 0),
    BabelExp_36 is KERNEL_CACHE_SSA_3,
    ptrW(__CIL_FP_KERNEL_CACHE, BabelExp_36, 8),
    babel__implicit_kernel_cache_initc_12(__CIL_PP_KERNEL_CACHE, TOTDOC_SSA_2, I_SSA_3),
    BabelExp_37 is __CIL_FP_KERNEL_CACHE,
    ptrR(KERNEL_CACHE_SSA_4, BabelExp_37, 8),
    babelAssign(__CIL_TMP82, KERNEL_CACHE_SSA_4 +1* 72),
    babelAssign(__CIL_TMP83, __CIL_TMP82),
    BabelExp_38 is 0,
    ptrW(__CIL_TMP83, BabelExp_38, 8),true. 

:- foreign(babel__implicit_kernel_cache_reset_lruc_13(+integer, +integer, +integer)).
:- foreign(babel__implicit_kernel_cache_reset_lruc_14(+integer, +integer, +integer)).

kernel_cache_reset_lru(__CIL_PP_KERNEL_CACHE, __CIL_PP_MAXLRU, __CIL_FP_KERNEL_CACHE, __CIL_FP_MAXLRU, KERNEL_CACHE, VOID) :- 


    babelAssign(MAXLRU_SSA_1, 0),
    babelAssign(K_SSA_1, 0),
    BabelExp_39 is KERNEL_CACHE,
    ptrW(__CIL_FP_KERNEL_CACHE, BabelExp_39, 8),
    BabelExp_40 is MAXLRU_SSA_1,
    ptrW(__CIL_FP_MAXLRU, BabelExp_40, 8),
    babel__implicit_kernel_cache_reset_lruc_13(__CIL_PP_KERNEL_CACHE, __CIL_PP_MAXLRU, K_SSA_1),
    BabelExp_41 is __CIL_FP_KERNEL_CACHE,
    ptrR(KERNEL_CACHE_SSA_1, BabelExp_41, 8),
    BabelExp_42 is __CIL_FP_MAXLRU,
    ptrR(MAXLRU_SSA_2, BabelExp_42, 8),
    babelAssign(K_SSA_2, 0),
    babel__implicit_kernel_cache_reset_lruc_14(KERNEL_CACHE_SSA_1, MAXLRU_SSA_2, K_SSA_2),true. 

:- foreign(babel__implicit_kernel_cache_cleanupc_15(+integer)).
:- foreign(babel__implicit_kernel_cache_cleanupc_16(+integer)).
:- foreign(babel__implicit_kernel_cache_cleanupc_17(+integer)).
:- foreign(babel__implicit_kernel_cache_cleanupc_18(+integer)).
:- foreign(babel__implicit_kernel_cache_cleanupc_19(+integer)).
:- foreign(babel__implicit_kernel_cache_cleanupc_20(+integer)).
:- foreign(babel__implicit_kernel_cache_cleanupc_21(+integer)).
:- foreign(babel__implicit_kernel_cache_cleanupc_22(+integer)).

kernel_cache_cleanup(KERNEL_CACHE, VOID) :- 


    babelAssign(MEM_21, KERNEL_CACHE),
    BabelExp_43 is MEM_21,
    ptrR(__CIL_TMP2, BabelExp_43, 8),
    babel__implicit_kernel_cache_cleanupc_15(__CIL_TMP2),
    babelAssign(__CIL_TMP3, KERNEL_CACHE +1* 48),
    babelAssign(__CIL_TMP4, __CIL_TMP3),
    BabelExp_44 is __CIL_TMP4,
    ptrR(__CIL_TMP5, BabelExp_44, 8),
    babel__implicit_kernel_cache_cleanupc_16(__CIL_TMP5),
    babelAssign(__CIL_TMP6, KERNEL_CACHE +1* 40),
    babelAssign(__CIL_TMP7, __CIL_TMP6),
    BabelExp_45 is __CIL_TMP7,
    ptrR(__CIL_TMP8, BabelExp_45, 8),
    babel__implicit_kernel_cache_cleanupc_17(__CIL_TMP8),
    babelAssign(__CIL_TMP9, KERNEL_CACHE +1* 16),
    babelAssign(__CIL_TMP10, __CIL_TMP9),
    BabelExp_46 is __CIL_TMP10,
    ptrR(__CIL_TMP11, BabelExp_46, 8),
    babel__implicit_kernel_cache_cleanupc_18(__CIL_TMP11),
    babelAssign(__CIL_TMP12, KERNEL_CACHE +1* 24),
    babelAssign(__CIL_TMP13, __CIL_TMP12),
    BabelExp_47 is __CIL_TMP13,
    ptrR(__CIL_TMP14, BabelExp_47, 8),
    babel__implicit_kernel_cache_cleanupc_19(__CIL_TMP14),
    babelAssign(__CIL_TMP15, KERNEL_CACHE +1* 32),
    babelAssign(__CIL_TMP16, __CIL_TMP15),
    BabelExp_48 is __CIL_TMP16,
    ptrR(__CIL_TMP17, BabelExp_48, 8),
    babel__implicit_kernel_cache_cleanupc_20(__CIL_TMP17),
    babelAssign(__CIL_TMP18, KERNEL_CACHE +1* 8),
    babelAssign(__CIL_TMP19, __CIL_TMP18),
    BabelExp_49 is __CIL_TMP19,
    ptrR(__CIL_TMP20, BabelExp_49, 8),
    babel__implicit_kernel_cache_cleanupc_21(__CIL_TMP20),
    babel__implicit_kernel_cache_cleanupc_22(KERNEL_CACHE),true. 

:- foreign(babel__implicit_kernel_cache_mallocc_23(+integer,  -integer)).
:- foreign(babel__implicit_kernel_cache_mallocc_24(+integer, +integer, +integer,  -integer)).

kernel_cache_malloc(__CIL_PP___CIL_RET4, __CIL_FP___CIL_RET4, KERNEL_CACHE, __CIL_RET4_SSA_1) :- 


    babel__implicit_kernel_cache_mallocc_23(KERNEL_CACHE , TMP_SSA_1),
    (babelJcc(13, TMP_SSA_1, 0) ->
         babelAssign(I_SSA_1, 0),
         babel__implicit_kernel_cache_mallocc_24(__CIL_PP___CIL_RET4, KERNEL_CACHE, I_SSA_1 , RETFLAG5_SSA_1),
         BabelExp_51 is __CIL_FP___CIL_RET4,
         ptrR(__CIL_RET4_SSA_1, BabelExp_51, 8),
         (babelJcc(13, RETFLAG5_SSA_1, 0) ->
              true
          ; true)
     ; true). 


kernel_cache_free(KERNEL_CACHE, I, VOID) :- 


    babelAssign(__CIL_TMP3, KERNEL_CACHE +1* 48),
    babelAssign(__CIL_TMP4, __CIL_TMP3),
    BabelExp_52 is __CIL_TMP4,
    ptrR(__CIL_TMP5, BabelExp_52, 8),
    babelAssign(__CIL_TMP6, __CIL_TMP5 +8* I),
    BabelExp_53 is 0,
    ptrW(__CIL_TMP6, BabelExp_53, 8),
    babelAssign(__CIL_TMP7, KERNEL_CACHE +1* 56),
    babelAssign(__CIL_TMP8, __CIL_TMP7),
    BabelExp_54 is __CIL_TMP8,
    ptrR(__CIL_TMP9, BabelExp_54, 8),
    babelAssign(__CIL_TMP10, KERNEL_CACHE +1* 56),
    babelAssign(__CIL_TMP11, __CIL_TMP10),
    BabelExp_55 is __CIL_TMP9 - 1,
    ptrW(__CIL_TMP11, BabelExp_55, 8),true. 

:- foreign(babel__implicit_kernel_cache_free_lruc_25(+integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_kernel_cache_free_lruc_26(+integer, +integer)).

kernel_cache_free_lru(__CIL_PP_KERNEL_CACHE, __CIL_PP_LEAST_ELEM, __CIL_FP_KERNEL_CACHE, __CIL_FP_LEAST_ELEM, KERNEL_CACHE, VOID) :- 


    babelAssign(LEAST_ELEM_SSA_1, -1),
    babelAssign(__CIL_TMP15, KERNEL_CACHE +1* 72),
    babelAssign(__CIL_TMP16, __CIL_TMP15),
    BabelExp_56 is __CIL_TMP16,
    ptrR(__CIL_TMP17, BabelExp_56, 8),
    BabelExp_57 is __CIL_TMP17 + 1,
    babelAssign(LEAST_TIME_SSA_1, BabelExp_57),
    babelAssign(K_SSA_1, 0),
    BabelExp_58 is KERNEL_CACHE,
    ptrW(__CIL_FP_KERNEL_CACHE, BabelExp_58, 8),
    BabelExp_59 is LEAST_ELEM_SSA_1,
    ptrW(__CIL_FP_LEAST_ELEM, BabelExp_59, 8),
    babel__implicit_kernel_cache_free_lruc_25(__CIL_PP_KERNEL_CACHE, __CIL_PP_LEAST_ELEM, K_SSA_1, LEAST_TIME_SSA_1),
    BabelExp_60 is __CIL_FP_KERNEL_CACHE,
    ptrR(KERNEL_CACHE_SSA_1, BabelExp_60, 8),
    BabelExp_61 is __CIL_FP_LEAST_ELEM,
    ptrR(LEAST_ELEM_SSA_2, BabelExp_61, 8),

    (babelJcc(13, LEAST_ELEM_SSA_2, -1) ->
         babelAssign(__CIL_TMP14, 1)
     ; babelAssign(__CIL_TMP14, 0)),

    (babelJcc(13, __CIL_TMP14, 0) ->
         babel__implicit_kernel_cache_free_lruc_26(KERNEL_CACHE_SSA_1, LEAST_ELEM_SSA_2),
         babelAssign(__CIL_TMP18, KERNEL_CACHE_SSA_1 +1* 16),
         babelAssign(__CIL_TMP19, __CIL_TMP18),
         BabelExp_62 is __CIL_TMP19,
         ptrR(__CIL_TMP20, BabelExp_62, 8),
         babelAssign(__CIL_TMP21, __CIL_TMP20 +8* LEAST_ELEM_SSA_2),
         babelAssign(MEM_27, KERNEL_CACHE_SSA_1),
         BabelExp_63 is MEM_27,
         ptrR(__CIL_TMP22, BabelExp_63, 8),
         BabelExp_64 is __CIL_TMP21,
         ptrR(__CIL_TMP23, BabelExp_64, 8),
         babelAssign(__CIL_TMP24, __CIL_TMP22 +8* __CIL_TMP23),
         BabelExp_65 is -1,
         ptrW(__CIL_TMP24, BabelExp_65, 8),
         babelAssign(__CIL_TMP25, KERNEL_CACHE_SSA_1 +1* 16),
         babelAssign(__CIL_TMP26, __CIL_TMP25),
         BabelExp_66 is __CIL_TMP26,
         ptrR(__CIL_TMP27, BabelExp_66, 8),
         babelAssign(__CIL_TMP28, __CIL_TMP27 +8* LEAST_ELEM_SSA_2),
         BabelExp_67 is -1,
         ptrW(__CIL_TMP28, BabelExp_67, 8),true
     ; true). 

:- foreign(babel__implicit_kernel_cache_clean_and_mallocc_27(+integer,  -integer)).
:- foreign(babel__implicit_kernel_cache_clean_and_mallocc_28(+integer,  -integer)).
:- foreign(babel__implicit_kernel_cache_clean_and_mallocc_29(+integer,  -integer)).

kernel_cache_clean_and_malloc(KERNEL_CACHE, DOCNUM, __CIL_TMP10) :- 


    babel__implicit_kernel_cache_clean_and_mallocc_27(KERNEL_CACHE , RESULT_SSA_1),

    (babelJcc(12, RESULT_SSA_1, -1) ->
         babelAssign(__CIL_TMP8, 1)
     ; babelAssign(__CIL_TMP8, 0)),

    (babelJcc(13, __CIL_TMP8, 0) ->
         babel__implicit_kernel_cache_clean_and_mallocc_28(KERNEL_CACHE , TMP_SSA_1),
         (babelJcc(13, TMP_SSA_1, 0) ->
              babel__implicit_kernel_cache_clean_and_mallocc_29(KERNEL_CACHE , RESULT_SSA_2)
          ; babelAssign(RESULT_SSA_2, RESULT_SSA_1))
     ; babelAssign(RESULT_SSA_2, RESULT_SSA_1)),
    babelAssign(MEM_40, KERNEL_CACHE),
    BabelExp_68 is MEM_40,
    ptrR(__CIL_TMP11, BabelExp_68, 8),
    babelAssign(__CIL_TMP12, __CIL_TMP11 +8* DOCNUM),
    BabelExp_69 is RESULT_SSA_2,
    ptrW(__CIL_TMP12, BabelExp_69, 8),

    (babelJcc(12, RESULT_SSA_2, -1) ->
         babelAssign(__CIL_TMP9, 1)
     ; babelAssign(__CIL_TMP9, 0)),

    (babelJcc(13, __CIL_TMP9, 0) ->
         true
     ; babelAssign(__CIL_TMP13, KERNEL_CACHE +1* 16),
       babelAssign(__CIL_TMP14, __CIL_TMP13),
       BabelExp_70 is __CIL_TMP14,
       ptrR(__CIL_TMP15, BabelExp_70, 8),
       babelAssign(__CIL_TMP16, __CIL_TMP15 +8* RESULT_SSA_2),
       BabelExp_71 is DOCNUM,
       ptrW(__CIL_TMP16, BabelExp_71, 8),
       babelAssign(__CIL_TMP17, KERNEL_CACHE +1* 72),
       babelAssign(__CIL_TMP18, __CIL_TMP17),
       babelAssign(__CIL_TMP19, KERNEL_CACHE +1* 40),
       babelAssign(__CIL_TMP20, __CIL_TMP19),
       babelAssign(MEM_41, KERNEL_CACHE),
       BabelExp_72 is MEM_41,
       ptrR(__CIL_TMP21, BabelExp_72, 8),
       babelAssign(__CIL_TMP22, __CIL_TMP21 +8* DOCNUM),
       BabelExp_73 is __CIL_TMP20,
       ptrR(__CIL_TMP23, BabelExp_73, 8),
       BabelExp_74 is __CIL_TMP22,
       ptrR(__CIL_TMP24, BabelExp_74, 8),
       babelAssign(__CIL_TMP25, __CIL_TMP23 +8* __CIL_TMP24),
       ptrR(BabelExp_75, __CIL_TMP18, 8),
       ptrW(__CIL_TMP25, BabelExp_75, 8),
       babelAssign(__CIL_TMP26, KERNEL_CACHE +1* 8),
       babelAssign(__CIL_TMP27, __CIL_TMP26),
       BabelExp_76 is __CIL_TMP27,
       ptrR(__CIL_TMP28, BabelExp_76, 8),
       babelAssign(__CIL_TMP29, __CIL_TMP28),
       babelAssign(__CIL_TMP30, KERNEL_CACHE +1* 80),
       babelAssign(__CIL_TMP31, __CIL_TMP30),
       BabelExp_77 is __CIL_TMP31,
       ptrR(__CIL_TMP32, BabelExp_77, 8),
       babelAssign(__CIL_TMP33, __CIL_TMP32),
       babelAssign(MEM_42, KERNEL_CACHE),
       BabelExp_78 is MEM_42,
       ptrR(__CIL_TMP34, BabelExp_78, 8),
       babelAssign(__CIL_TMP35, __CIL_TMP34 +8* DOCNUM),
       BabelExp_79 is __CIL_TMP35,
       ptrR(__CIL_TMP36, BabelExp_79, 8),
       BabelExp_80 is __CIL_TMP33 * 4,
       babelAssign(__CIL_TMP37, BabelExp_80),
       babelAssign(__CIL_TMP38, __CIL_TMP36),
       babelAssign(__CIL_TMP39, __CIL_TMP29),
       BabelExp_81 is __CIL_TMP37 * __CIL_TMP38,
       babelAssign(__CIL_TMP40, BabelExp_81),
       BabelExp_82 is __CIL_TMP39 + __CIL_TMP40,
       babelAssign(__CIL_TMP41, BabelExp_82),
       babelAssign(__CIL_TMP10, __CIL_TMP41),true). 


kernel_cache_touch(KERNEL_CACHE, DOCNUM, __CIL_TMP10) :- 


    (babelJcc(13, KERNEL_CACHE, 0) ->
         babelAssign(MEM_16, KERNEL_CACHE),
         BabelExp_83 is MEM_16,
         ptrR(__CIL_TMP4, BabelExp_83, 8),
         babelAssign(__CIL_TMP5, __CIL_TMP4 +8* DOCNUM),
         BabelExp_84 is __CIL_TMP5,
         ptrR(__CIL_TMP6, BabelExp_84, 8),

         (babelJcc(13, __CIL_TMP6, -1) ->
              babelAssign(__CIL_TMP3, 1)
          ; babelAssign(__CIL_TMP3, 0)),

         (babelJcc(13, __CIL_TMP3, 0) ->
              babelAssign(__CIL_TMP7, KERNEL_CACHE +1* 72),
              babelAssign(__CIL_TMP8, __CIL_TMP7),
              babelAssign(__CIL_TMP9, KERNEL_CACHE +1* 40),
              babelAssign(__CIL_TMP10, __CIL_TMP9),
              babelAssign(MEM_17, KERNEL_CACHE),
              BabelExp_85 is MEM_17,
              ptrR(__CIL_TMP11, BabelExp_85, 8),
              babelAssign(__CIL_TMP12, __CIL_TMP11 +8* DOCNUM),
              BabelExp_86 is __CIL_TMP10,
              ptrR(__CIL_TMP13, BabelExp_86, 8),
              BabelExp_87 is __CIL_TMP12,
              ptrR(__CIL_TMP14, BabelExp_87, 8),
              babelAssign(__CIL_TMP15, __CIL_TMP13 +8* __CIL_TMP14),
              ptrR(BabelExp_88, __CIL_TMP8, 8),
              ptrW(__CIL_TMP15, BabelExp_88, 8),true
          ; true)
     ; true). 


kernel_cache_check(KERNEL_CACHE, DOCNUM, __CIL_TMP3) :- 


    babelAssign(MEM_8, KERNEL_CACHE),
    BabelExp_89 is MEM_8,
    ptrR(__CIL_TMP4, BabelExp_89, 8),
    babelAssign(__CIL_TMP5, __CIL_TMP4 +8* DOCNUM),
    BabelExp_90 is __CIL_TMP5,
    ptrR(__CIL_TMP6, BabelExp_90, 8),

    (babelJcc(13, __CIL_TMP6, -1) ->
         babelAssign(__CIL_TMP7, 1)
     ; babelAssign(__CIL_TMP7, 0)),

    babelAssign(__CIL_TMP3, __CIL_TMP7),true. 


kernel_cache_space_available(KERNEL_CACHE, __CIL_TMP2) :- 


    babelAssign(__CIL_TMP3, KERNEL_CACHE +1* 56),
    babelAssign(__CIL_TMP4, __CIL_TMP3),
    babelAssign(__CIL_TMP5, KERNEL_CACHE +1* 64),
    babelAssign(__CIL_TMP6, __CIL_TMP5),
    BabelExp_91 is __CIL_TMP4,
    ptrR(__CIL_TMP7, BabelExp_91, 8),
    BabelExp_92 is __CIL_TMP6,
    ptrR(__CIL_TMP8, BabelExp_92, 8),

    (babelJcc(16, __CIL_TMP7, __CIL_TMP8) ->
         babelAssign(__CIL_TMP9, 1)
     ; babelAssign(__CIL_TMP9, 0)),

    babelAssign(__CIL_TMP2, __CIL_TMP9),true. 


:- foreign(babel__implicit_distribute_alpha_t_greedilyc_0(+positive,  -integer)).
:- foreign(babel__implicit_distribute_alpha_t_greedilyc_1(+positive,  -integer)).
:- foreign(babel__implicit_distribute_alpha_t_greedilyc_2(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_distribute_alpha_t_greedilyc_3(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +float, +integer, +integer, +float, +float, +integer)).
:- foreign(babel__implicit_distribute_alpha_t_greedilyc_4(+integer)).
:- foreign(babel__implicit_distribute_alpha_t_greedilyc_5(+integer)).

distribute_alpha_t_greedily(__CIL_PP_SV2DNUM, __CIL_PP_SVNUM, __CIL_PP_DOCS, __CIL_PP_DOCNUM, __CIL_PP_KERNEL_PARM, __CIL_PP_LEARN_PARM, __CIL_PP_THRESH, __CIL_PP_CACHE, __CIL_PP_TROW, __CIL_PP_BEST, __CIL_FP_SV2DNUM, __CIL_FP_SVNUM, __CIL_FP_DOCS, __CIL_FP_DOCNUM, __CIL_FP_KERNEL_PARM, __CIL_FP_LEARN_PARM, __CIL_FP_THRESH, __CIL_FP_CACHE, __CIL_FP_TROW, __CIL_FP_BEST, SV2DNUM, SVNUM, DOCS, A, DOCNUM, LABEL, KERNEL_PARM, LEARN_PARM, THRESH, BEST_SSA_2) :- 


    babelAssign(__CIL_TMP72, LEARN_PARM +1* 144),
    babelAssign(__CIL_TMP73,__CIL_TMP72),
    BabelExp_0 is __CIL_TMP73,
    ptrR(__CIL_TMP74, BabelExp_0, 8),
    babelAssign(__CIL_TMP75, __CIL_TMP74),
    BabelExp_1 is 4 * __CIL_TMP75,
    babelAssign(__CIL_TMP76, BabelExp_1),
    BabelExp_2 is __CIL_TMP76 * SVNUM,
    babelAssign(__CIL_TMP77, BabelExp_2),
    babel__implicit_distribute_alpha_t_greedilyc_0(__CIL_TMP77 , TMP_SSA_1),
    babelAssign(CACHE_SSA_1, TMP_SSA_1),
    BabelExp_3 is 4 * SVNUM,
    babelAssign(__CIL_TMP78, BabelExp_3),
    babel__implicit_distribute_alpha_t_greedilyc_1(__CIL_TMP78 , TMP___0_SSA_1),
    babelAssign(TROW_SSA_1, TMP___0_SSA_1),
    babelAssign(K_SSA_1, 0),
    BabelExp_4 is SV2DNUM,
    ptrW(__CIL_FP_SV2DNUM, BabelExp_4, 8),
    BabelExp_5 is SVNUM,
    ptrW(__CIL_FP_SVNUM, BabelExp_5, 8),
    BabelExp_6 is DOCS,
    ptrW(__CIL_FP_DOCS, BabelExp_6, 8),
    BabelExp_7 is DOCNUM,
    ptrW(__CIL_FP_DOCNUM, BabelExp_7, 8),
    BabelExp_8 is KERNEL_PARM,
    ptrW(__CIL_FP_KERNEL_PARM, BabelExp_8, 8),
    BabelExp_9 is LEARN_PARM,
    ptrW(__CIL_FP_LEARN_PARM, BabelExp_9, 8),
    BabelExp_10 is THRESH,
    ptrW(__CIL_FP_THRESH, BabelExp_10, 8),
    BabelExp_11 is CACHE_SSA_1,
    ptrW(__CIL_FP_CACHE, BabelExp_11, 8),
    BabelExp_12 is TROW_SSA_1,
    ptrW(__CIL_FP_TROW, BabelExp_12, 8),
    babel__implicit_distribute_alpha_t_greedilyc_2(__CIL_PP_SV2DNUM, __CIL_PP_SVNUM, __CIL_PP_DOCS, __CIL_PP_DOCNUM, __CIL_PP_KERNEL_PARM, __CIL_PP_LEARN_PARM, __CIL_PP_THRESH, __CIL_PP_CACHE, __CIL_PP_TROW, K_SSA_1),
    BabelExp_13 is __CIL_FP_SV2DNUM,
    ptrR(SV2DNUM_SSA_1, BabelExp_13, 8),
    BabelExp_14 is __CIL_FP_SVNUM,
    ptrR(SVNUM_SSA_1, BabelExp_14, 8),
    BabelExp_15 is __CIL_FP_DOCS,
    ptrR(DOCS_SSA_1, BabelExp_15, 8),
    BabelExp_16 is __CIL_FP_DOCNUM,
    ptrR(DOCNUM_SSA_1, BabelExp_16, 8),
    BabelExp_17 is __CIL_FP_KERNEL_PARM,
    ptrR(KERNEL_PARM_SSA_1, BabelExp_17, 8),
    BabelExp_18 is __CIL_FP_LEARN_PARM,
    ptrR(LEARN_PARM_SSA_1, BabelExp_18, 8),
    BabelExp_19 is __CIL_FP_THRESH,
    ptrR(THRESH_SSA_1, BabelExp_19, 8),
    BabelExp_20 is __CIL_FP_CACHE,
    ptrR(CACHE_SSA_2, BabelExp_20, 8),
    BabelExp_21 is __CIL_FP_TROW,
    ptrR(TROW_SSA_2, BabelExp_21, 8),
    babelAssign(INIT_VAL_SQ_SSA_1, 0),
    babelAssign(INIT_VAL_LIN_SSA_1, 0),
    babelAssign(BEST_SSA_1, 0),
    babelAssign(D_SSA_1, 0),
    BabelExp_22 is BEST_SSA_1,
    ptrW(__CIL_FP_BEST, BabelExp_22, 8),
    BabelExp_23 is CACHE_SSA_2,
    ptrW(__CIL_FP_CACHE, BabelExp_23, 8),
    BabelExp_24 is TROW_SSA_2,
    ptrW(__CIL_FP_TROW, BabelExp_24, 8),
    babel__implicit_distribute_alpha_t_greedilyc_3(__CIL_PP_BEST, __CIL_PP_CACHE, __CIL_PP_TROW, SV2DNUM_SSA_1, SVNUM_SSA_1, DOCS_SSA_1, DOCNUM_SSA_1, KERNEL_PARM_SSA_1, LEARN_PARM_SSA_1, THRESH_SSA_1, D_SSA_1, (BEST_VAL), INIT_VAL_SQ_SSA_1, INIT_VAL_LIN_SSA_1,(BEST_EX)),
    BabelExp_25 is __CIL_FP_BEST,
    ptrR(BEST_SSA_2, BabelExp_25, 8),
    BabelExp_26 is __CIL_FP_CACHE,
    ptrR(CACHE_SSA_3, BabelExp_26, 8),
    BabelExp_27 is __CIL_FP_TROW,
    ptrR(TROW_SSA_3, BabelExp_27, 8),
    babel__implicit_distribute_alpha_t_greedilyc_4(CACHE_SSA_3),
    babel__implicit_distribute_alpha_t_greedilyc_5(TROW_SSA_3),true. 

:- foreign(babel__implicit_estimate_margin_vcdimc_6(+integer, +integer,  -float)).
:- foreign(babel__implicit_estimate_margin_vcdimc_7(+integer, +integer,  -float)).

estimate_margin_vcdim(MODEL, W, R, KERNEL_PARM, H_SSA_1) :- 



    ( W < 0.0 ->
         babel__implicit_estimate_margin_vcdimc_6(MODEL, KERNEL_PARM , W_SSA_1)
     ; W_SSA_1 is W),

    (R < 0.0 ->
         babel__implicit_estimate_margin_vcdimc_7(MODEL, KERNEL_PARM , R_SSA_1)
     ; R_SSA_1 is R),
    __CIL_TMP11 is W_SSA_1 * W_SSA_1,
    __CIL_TMP12 is __CIL_TMP11 * R_SSA_1,
    __CIL_TMP13 is __CIL_TMP12 * R_SSA_1,
    H_SSA_1 is __CIL_TMP13 + 1.0.

:- foreign(babel__implicit_estimate_spherec_8(+integer, +string, +float,  -integer)).
:- foreign(babel__implicit_estimate_spherec_9(+integer, +integer, +integer, +float, +integer,  -integer)).
:- foreign(babel__implicit_estimate_spherec_10(+integer, +integer)).


estimate_sphere(__CIL_PP_NULLWORD, __CIL_PP_MAXXLEN, __CIL_PP_NULLDOC, __CIL_FP_MAXXLEN, __CIL_FP_NULLDOC, MODEL, KERNEL_PARM, MAXXLEN_SSA_2) :- 
    MAXXLEN_SSA_1 is 0.0,
    ptrW(__CIL_PP_NULLWORD, 0, 8),
    babel__implicit_estimate_spherec_8(__CIL_PP_NULLWORD, '', 1.0 , TMP_SSA_1),
    babel__implicit_estimate_spherec_9(-2, 0, 0, 0.0, TMP_SSA_1 , NULLDOC_SSA_1),
    ptrWF(__CIL_FP_MAXXLEN, MAXXLEN_SSA_1),
    ptrW(__CIL_PP_NULLDOC, NULLDOC_SSA_1, 8),
    estimate_sphere_cil_lr_1(__CIL_PP_MAXXLEN, NULLDOC_SSA_1, MODEL, KERNEL_PARM, 1),
    ptrRF(MAXXLEN_SSA_2, __CIL_FP_MAXXLEN),
    babel__implicit_estimate_spherec_10(NULLDOC_SSA_1, 1).


:- foreign(babel__implicit_estimate_spherec_11(+integer, +integer, +integer, -float)).
estimate_sphere_cil_lr_1(PP_MAXXLEN, NULLDOC, MODEL, KERNEL_PARM, J):-
    ptrR(MEM, MODEL, 8),
    (MEM =< J -> true;
     T18 is MODEL + 24,
     ptrR(T20, T18, 8),
     T21 is T20 + J * 8,
     ptrR(T26, T21, 8),
     babel__implicit_estimate_spherec_11(KERNEL_PARM, T26, T26, TMP1),
     babel__implicit_estimate_spherec_11(KERNEL_PARM, T26, NULLDOC, TMP2),
     babel__implicit_estimate_spherec_11(KERNEL_PARM, NULLDOC, NULLDOC, TMP3),
     XLEN is sqrt(TMP1 - 2.0 * TMP2 + TMP3),
     ptrRF(MAXXLEN, PP_MAXXLEN),
     (XLEN > MAXXLEN -> ptrWF(PP_MAXXLEN, XLEN); true),
     J2 is J + 1,
     estimate_sphere_cil_lr_1(PP_MAXXLEN, NULLDOC, MODEL, KERNEL_PARM, J2)).


:- foreign(babel__implicit_estimate_r_deltac_12(+integer, +string, +float,  -integer)).
:- foreign(babel__implicit_estimate_r_deltac_13(+integer, +integer, +integer, +float, +integer,  -integer)).
:- foreign(babel__implicit_estimate_r_deltac_14(+integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_estimate_r_deltac_15(+integer, +integer)).

estimate_r_delta(__CIL_PP_NULLWORD, __CIL_PP_MAXXLEN, __CIL_PP_NULLDOC, __CIL_FP_MAXXLEN, __CIL_FP_NULLDOC, DOCS, TOTDOC, KERNEL_PARM, MAXXLEN_SSA_2) :- 


    ptrW(__CIL_PP_NULLWORD, 0, 8),
    babel__implicit_estimate_r_deltac_12(__CIL_PP_NULLWORD, '', 1.0 , TMP_SSA_1),
    babel__implicit_estimate_r_deltac_13(-2, 0, 0, 0.0, TMP_SSA_1 , NULLDOC_SSA_1),
    ptrWF(__CIL_FP_MAXXLEN, 0.0),
    ptrW(__CIL_FP_NULLDOC, NULLDOC_SSA_1, 8),
    estimate_r_delta_cil_lr_1(__CIL_PP_MAXXLEN, NULLDOC_SSA_1, DOCS, TOTDOC, KERNEL_PARM, 0),
    ptrRF(MAXXLEN_SSA_2, __CIL_FP_MAXXLEN),
    babel__implicit_estimate_spherec_10(NULLDOC_SSA_1, 1).

estimate_r_delta_cil_lr_1(PP_MAXXLEN, NULLDOC, DOCS, TOTDOC, KERNEL_PARM, J):-
    (TOTDOC =< J -> true;
     T1 is DOCS + J * 8,
     ptrR(T2, T1, 8),
     babel__implicit_estimate_spherec_11(KERNEL_PARM, T2, T2, TMP1),
     babel__implicit_estimate_spherec_11(KERNEL_PARM, T2, NULLDOC, TMP2),
     babel__implicit_estimate_spherec_11(KERNEL_PARM, NULLDOC, NULLDOC, TMP3),
     XLEN is sqrt(TMP1 - 2.0 * TMP2 + TMP3),
     ptrRF(MAXXLEN, PP_MAXXLEN),
     (XLEN > MAXXLEN -> ptrWF(PP_MAXXLEN, XLEN); true),
     J2 is J + 1,
     estimate_r_delta_cil_lr_1(PP_MAXXLEN, NULLDOC, DOCS, TOTDOC, KERNEL_PARM, J2)).

:- foreign(babel__implicit_estimate_r_delta_averagec_16(+integer, +integer, +float,  -integer)).
:- foreign(babel__implicit_estimate_r_delta_averagec_17(+integer, +integer, +integer, +float, +integer,  -integer)).
:- foreign(babel__implicit_estimate_r_delta_averagec_18(+integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_estimate_r_delta_averagec_19(+integer, +integer)).

estimate_r_delta_average(__CIL_PP_NULLWORD, __CIL_PP_TOTDOC, __CIL_PP_AVGXLEN, __CIL_PP_NULLDOC, __CIL_FP_TOTDOC, __CIL_FP_AVGXLEN, __CIL_FP_NULLDOC, DOCS, TOTDOC, KERNEL_PARM, __CIL_TMP27) :- 


    babelAssign(MEM_22,__CIL_PP_NULLWORD),
    BabelExp_42 is 0,
    ptrW(MEM_22, BabelExp_42, 8),
    babel__implicit_estimate_r_delta_averagec_16(__CIL_PP_NULLWORD, '', 1.0 , TMP_SSA_1),
    babel__implicit_estimate_r_delta_averagec_17(-2, 0, 0, 0.0, TMP_SSA_1 , NULLDOC_SSA_1),
    babelAssign(AVGXLEN_SSA_1, 0),
    babelAssign(I_SSA_1, 0),
    BabelExp_43 is TOTDOC,
    ptrW(__CIL_FP_TOTDOC, BabelExp_43, 8),
    BabelExp_44 is AVGXLEN_SSA_1,
    ptrW(__CIL_FP_AVGXLEN, BabelExp_44, 8),
    BabelExp_45 is NULLDOC_SSA_1,
    ptrW(__CIL_FP_NULLDOC, BabelExp_45, 8),
    babel__implicit_estimate_r_delta_averagec_18(__CIL_PP_TOTDOC, __CIL_PP_AVGXLEN, __CIL_PP_NULLDOC, DOCS, KERNEL_PARM, I_SSA_1),
    BabelExp_46 is __CIL_FP_TOTDOC,
    ptrR(TOTDOC_SSA_1, BabelExp_46, 8),
    BabelExp_47 is __CIL_FP_AVGXLEN,
    ptrR(AVGXLEN_SSA_2, BabelExp_47, 8),
    BabelExp_48 is __CIL_FP_NULLDOC,
    ptrR(NULLDOC_SSA_2, BabelExp_48, 8),
    babel__implicit_estimate_r_delta_averagec_19(NULLDOC_SSA_2, 1),
    BabelExp_49 is AVGXLEN_SSA_2 / TOTDOC_SSA_1,
    babelAssign(__CIL_TMP27, BabelExp_49),true. 

:- foreign(babel__implicit_length_of_longest_document_vectorc_20(+integer, +integer, +integer, +integer, +integer)).

length_of_longest_document_vector(__CIL_PP_MAXXLEN, __CIL_FP_MAXXLEN, DOCS, TOTDOC, KERNEL_PARM, MAXXLEN_SSA_2) :- 


    babelAssign(MAXXLEN_SSA_1, 0),
    babelAssign(I_SSA_1, 0),
    BabelExp_50 is MAXXLEN_SSA_1,
    ptrW(__CIL_FP_MAXXLEN, BabelExp_50, 8),
    babel__implicit_length_of_longest_document_vectorc_20(__CIL_PP_MAXXLEN, DOCS, TOTDOC, KERNEL_PARM, I_SSA_1),
    BabelExp_51 is __CIL_FP_MAXXLEN,
    ptrR(MAXXLEN_SSA_2, BabelExp_51, 8),true. 

:- foreign(babel__implicit_write_predictionc_21(+string)).
:- foreign(babel__implicit_write_predictionc_22(+integer)).
:- foreign(babel__implicit_write_predictionc_23(+integer, +string,  -integer)).
:- foreign(babel__implicit_write_predictionc_24(+integer)).
:- foreign(babel__implicit_write_predictionc_25(+integer)).
:- foreign(babel__implicit_write_predictionc_26(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_write_predictionc_27(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer, +float)).
:- foreign(babel__implicit_write_predictionc_28(+integer)).
:- foreign(babel__implicit_write_predictionc_29(+string)).

write_prediction(__CIL_PP_VERBOSITY, __CIL_PP_MODEL, __CIL_PP_LIN, __CIL_PP_A, __CIL_PP_UNLABELED, __CIL_PP_LABEL, __CIL_PP_TOTDOC, __CIL_PP_LEARN_PARM, __CIL_PP_PREDFL, __CIL_PP_A_MAX, __CIL_GP_VERBOSITY, __CIL_GP_STDOUT, __CIL_FP_MODEL, __CIL_FP_LIN, __CIL_FP_A, __CIL_FP_UNLABELED, __CIL_FP_LABEL, __CIL_FP_TOTDOC, __CIL_FP_LEARN_PARM, __CIL_FP_PREDFL, __CIL_FP_A_MAX, PREDFILE, MODEL, LIN, A, UNLABELED, LABEL, TOTDOC, LEARN_PARM) :- 

    ptrR(__CIL_TMP51, __CIL_GP_VERBOSITY, 8),

    ( __CIL_TMP51 >=1 ->
         babel__implicit_write_predictionc_21('Writing prediction file...'),
         ptrR(__CIL_TMP52, __CIL_GP_STDOUT, 8),
         babel__implicit_write_predictionc_22(__CIL_TMP52)
     ; true),
    babel__implicit_write_predictionc_23((PREDFILE), 'w' , PREDFL_SSA_1),
    (PREDFL_SSA_1 =:= 0 ->
         babel__implicit_write_predictionc_24(PREDFILE),
         babel__implicit_write_predictionc_25(1)
     ; true),
    babelAssign(__CIL_TMP53, LEARN_PARM +1* 560),
    babelAssign(__CIL_TMP54, __CIL_TMP53),
    BabelExp_54 is __CIL_TMP54,
    ptrR(A_MAX_SSA_1, BabelExp_54, 8),
    babelAssign(I_SSA_1, 0),
    BabelExp_55 is MODEL,
    ptrW(__CIL_FP_MODEL, BabelExp_55, 8),
    BabelExp_56 is LIN,
    ptrW(__CIL_FP_LIN, BabelExp_56, 8),
    BabelExp_57 is A,
    ptrW(__CIL_FP_A, BabelExp_57, 8),
    BabelExp_58 is UNLABELED,
    ptrW(__CIL_FP_UNLABELED, BabelExp_58, 8),
    BabelExp_59 is LABEL,
    ptrW(__CIL_FP_LABEL, BabelExp_59, 8),
    BabelExp_60 is TOTDOC,
    ptrW(__CIL_FP_TOTDOC, BabelExp_60, 8),
    BabelExp_61 is LEARN_PARM,
    ptrW(__CIL_FP_LEARN_PARM, BabelExp_61, 8),
    BabelExp_62 is PREDFL_SSA_1,
    ptrW(__CIL_FP_PREDFL, BabelExp_62, 8),
    BabelExp_63 is A_MAX_SSA_1,
    ptrW(__CIL_FP_A_MAX, BabelExp_63, 8),
    write_prediction_cil_lr_1(TOTDOC, UNLABELED, A, __CIL_PP_A_MAX, 0),
%    babel__implicit_write_predictionc_26(__CIL_PP_VERBOSITY, __CIL_PP_MODEL, __CIL_PP_LIN, __CIL_PP_A, __CIL_PP_UNLABELED, __CIL_PP_LABEL, __CIL_PP_TOTDOC, __CIL_PP_LEARN_PARM, __CIL_PP_PREDFL, __CIL_PP_A_MAX, I_SSA_1),
    BabelExp_64 is __CIL_FP_MODEL,
    ptrR(MODEL_SSA_1, BabelExp_64, 8),
    BabelExp_65 is __CIL_FP_LIN,
    ptrR(LIN_SSA_1, BabelExp_65, 8),
    BabelExp_66 is __CIL_FP_A,
    ptrR(A_SSA_1, BabelExp_66, 8),
    BabelExp_67 is __CIL_FP_UNLABELED,
    ptrR(UNLABELED_SSA_1, BabelExp_67, 8),
    BabelExp_68 is __CIL_FP_LABEL,
    ptrR(LABEL_SSA_1, BabelExp_68, 8),
    BabelExp_69 is __CIL_FP_TOTDOC,
    ptrR(TOTDOC_SSA_1, BabelExp_69, 8),
    BabelExp_70 is __CIL_FP_LEARN_PARM,
    ptrR(LEARN_PARM_SSA_1, BabelExp_70, 8),
    BabelExp_71 is __CIL_FP_PREDFL,
    ptrR(PREDFL_SSA_2, BabelExp_71, 8),
    BabelExp_72 is __CIL_FP_A_MAX,
    ptrR(A_MAX_SSA_2, BabelExp_72, 8),
    babelAssign(I_SSA_2, 0),
    BabelExp_73 is PREDFL_SSA_2,
    ptrW(__CIL_FP_PREDFL, BabelExp_73, 8),
    write_prediction_cil_lr_2(TOTDOC, UNLABELED, A, PREDFL_SSA_1, LEARN_PARM, A_MAX_SSA_2, LIN, MODEL, LABEL, 0),
    BabelExp_74 is __CIL_FP_PREDFL,
    ptrR(PREDFL_SSA_3, BabelExp_74, 8),
    babel__implicit_write_predictionc_28(PREDFL_SSA_3),
    BabelExp_75 is __CIL_GP_VERBOSITY,
    ptrR(__CIL_TMP55, BabelExp_75, 8),

    (babelJcc(17, __CIL_TMP55, 1) ->
         babelAssign(__CIL_TMP50, 1)
     ; babelAssign(__CIL_TMP50, 0)),

    (babelJcc(13, __CIL_TMP50, 0) ->
         babel__implicit_write_predictionc_29('done\n')
     ; true).

write_prediction_cil_lr_1(TOTDOC, UNLABELED, A, P_A_MAX, I):-
    I >= TOTDOC -> true;
    T1 is UNLABELED + I * 8,
    ptrR(T2, T1, 8),
    (T2 =:= 0 -> true;
     T3 is A + I * 8,
     ptrRF(T4, T3),
     ptrRF(A_MAX, P_A_MAX),
     (T4 =< A_MAX -> true;
      ptrWF(P_A_MAX, T4)
     )
    ),
    I2 is I + 1,
    write_prediction_cil_lr_1(TOTDOC, UNLABELED, A, P_A_MAX, I2).

:-foreign(babel__implicit_write_prediction_cil_lr2c_0(+integer, +string, +float, +float)).

write_prediction_cil_lr_2(TOTDOC, UNLABELED, A, PREDFL, LEARN_PARM, A_MAX, LIN, MODEL, LABEL, I):-
    (
    I >= TOTDOC -> true;
    (T1 is UNLABELED + I * 8,
    ptrR(T2, T1, 8),
    (T2 =:= 0 -> true;
     (
         T3 is A + I * 8,
         ptrRF(T4, T3),
         T5 is LEARN_PARM + 560,
         ptrRF(T6, T5),
         (T4 > T6 ->
              T55 is LABEL + I * 8,
              ptrR(T7, T55, 8),
              T8 is LEARN_PARM + 80,
              ptrRF(T9, T8),
              DIST is T7 * (1.0 - T9 - (T4/(A_MAX * 2.0)));
          (T10 is LIN + I * 8,
          ptrRF(T11, T10),
          T12 is MODEL + 16,
          ptrRF(T13, T12),
          DIST is T11 - T13)
         ),
         DIST2 is -1 * DIST,
         (DIST > 0 -> 
              babel__implicit_write_prediction_cil_lr2c_0(PREDFL, '%.8g:+1 %.8g:-1\n', DIST, DIST2);
          babel__implicit_write_prediction_cil_lr2c_0(PREDFL, '%.8g:-1 %.8g:+1\n', DIST2, DIST))
     )),
    I2 is I + 1,
    write_prediction_cil_lr_2(TOTDOC, UNLABELED, A, PREDFL, LEARN_PARM, A_MAX, LIN, MODEL, LABEL, I2))).
    
     
    

:- foreign(babel__implicit_write_alphasc_30(+integer)).
:- foreign(babel__implicit_write_alphasc_31(+integer)).
:- foreign(babel__implicit_write_alphasc_32(+integer, +integer,  -integer)).
:- foreign(babel__implicit_write_alphasc_33(+integer)).
:- foreign(babel__implicit_write_alphasc_34(+integer)).
:- foreign(babel__implicit_write_alphasc_35(+integer, +integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_write_alphasc_36(+integer)).
:- foreign(babel__implicit_write_alphasc_37(+integer)).

write_alphas(__CIL_PP_VERBOSITY, __CIL_PP_ALPHAFL, __CIL_GP_VERBOSITY, __CIL_GP_STDOUT, __CIL_FP_ALPHAFL, ALPHAFILE, A, LABEL, TOTDOC, VOID) :- 


    BabelExp_76 is __CIL_GP_VERBOSITY,
    ptrR(__CIL_TMP18, BabelExp_76, 8),

    (babelJcc(17, __CIL_TMP18, 1) ->
         babelAssign(__CIL_TMP15, 1)
     ; babelAssign(__CIL_TMP15, 0)),

    (babelJcc(13, __CIL_TMP15, 0) ->
         babel__implicit_write_alphasc_30('WRITING ALPHA FILE...'),
         BabelExp_77 is __CIL_GP_STDOUT,
         ptrR(__CIL_TMP19, BabelExp_77, 8),
         babel__implicit_write_alphasc_31(__CIL_TMP19)
     ; true),
    babel__implicit_write_alphasc_32((ALPHAFILE), 'w' , ALPHAFL_SSA_1),

    (babelJcc(12, ALPHAFL_SSA_1, (0)) ->
         babelAssign(__CIL_TMP16, 1)
     ; babelAssign(__CIL_TMP16, 0)),

    (babelJcc(13, __CIL_TMP16, 0) ->
         babel__implicit_write_alphasc_33(ALPHAFILE),
         babel__implicit_write_alphasc_34(1)
     ; true),
    babelAssign(I_SSA_1, 0),
    BabelExp_78 is ALPHAFL_SSA_1,
    ptrW(__CIL_FP_ALPHAFL, BabelExp_78, 8),
    babel__implicit_write_alphasc_35(__CIL_PP_VERBOSITY, __CIL_PP_ALPHAFL, A, LABEL, TOTDOC, I_SSA_1),
    BabelExp_79 is __CIL_FP_ALPHAFL,
    ptrR(ALPHAFL_SSA_2, BabelExp_79, 8),
    babel__implicit_write_alphasc_36(ALPHAFL_SSA_2),
    BabelExp_80 is __CIL_GP_VERBOSITY,
    ptrR(__CIL_TMP20, BabelExp_80, 8),

    (babelJcc(17, __CIL_TMP20, 1) ->
         babelAssign(__CIL_TMP17, 1)
     ; babelAssign(__CIL_TMP17, 0)),

    (babelJcc(13, __CIL_TMP17, 0) ->
         babel__implicit_write_alphasc_37('DONE\\n')
     ; true),
    true. 


