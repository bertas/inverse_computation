#include <gprolog.h>
#include <stdio.h>
#include <stdlib.h>

PlBool babel_ptrR(PlLong* p,  PlLong* star_p, PlLong len)
{

	if (star_p == 0)
	    return PL_FALSE;
	else
	{
		switch(len)
		{
		    case 1:
		    	*p = *(unsigned char*)star_p;
		    	break;
		    case 2:
		    	*p = *(short*)star_p;
		    	break;
		    case 4:
		    	*p = *(int*)star_p;
		    	break;
		    case 8:
		    	*p = *(long long*)star_p;
		    	break;
		    default :
		    	printf("undefined exp length in babel_ptrR\n");
		}
	}

		return PL_TRUE;
}

PlBool babel_ptrR_byte(PlLong* p,  PlLong* star_p, PlLong len)
{

	if (star_p == 0)
	    return PL_FALSE;
	else
	{
		switch(len)
		{
		    case 1:
		    	*p = *(unsigned char*)star_p;
		    	break;
		    case 2:
		    	*p = *(short*)star_p;
		    	break;
		    case 4:
		    	*p = *(int*)star_p;
		    	break;
		    case 8:
		    	*p = *(long long*)star_p;
		    	break;
		    default :
		    	printf("undefined exp length in babel_ptrR\n");
		}
	}

	return PL_TRUE;
}

PlBool babel_ptrE(PlLong* p,  PlLong e, PlLong len)
{
	if (p == 0)
	    return PL_FALSE;

	switch(len)
		{
		    case 1:
		    	*(unsigned char*)p = (unsigned char)e;
		    	break;
		    case 2:
		    	*(short*) p = (short)e;
		    	break;
		    case 4:
		    	*(int*)p = (int)e;
		    	break;
		    case 8:
		    	*(long long*)p = (long long)e;
		    	break;
		    default :
		    	printf("undefined exp length in babel_ptrL\n");
		}

        return PL_TRUE;
}
PlBool babel__implicit_distribute_alpha_t_greedily_cil_lr_2_cil_lr_3c_0(KERNEL_PARM * arg_0, DOC * arg_1, DOC * arg_2,  PlLong * babel_ret) 
{
*babel_ret = kernel(arg_0, arg_1, arg_2);
return PL_TRUE;
}
PlBool babel__implicit_compute_matrices_for_optimization_cil_lr_3_cil_lr_1c_1(KERNEL_PARM * arg_0, DOC * arg_1, DOC * arg_2,  PlLong * babel_ret) 
{
*babel_ret = kernel(arg_0, arg_1, arg_2);
return PL_TRUE;
}
