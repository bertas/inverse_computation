./svm_learn -z r example2/test.dat example2/model
./svm_learn example2/train_transduction.dat example2/model 
./svm_learn example2/train_induction.dat example2/model 
