#include <gprolog.h>
#include <stdio.h>
#include <stdlib.h>


#line 68 "defines.h"
typedef long flow_t;
#line 69 "defines.h"
typedef long cost_t;
#line 99
struct node;
#line 99
struct node;
#line 99
struct node;
#line 99 "defines.h"
typedef struct node node_t;

#line 100 "defines.h"
typedef struct node *node_p;
#line 102
struct arc;
#line 102
struct arc;
#line 102
struct arc;
#line 102 "defines.h"
typedef struct arc arc_t;
#line 103 "defines.h"
typedef struct arc *arc_p;
#line 107 "defines.h"

typedef struct network network_t;

PlBool babel_ptrR(PlLong* p,  PlLong* star_p, PlLong len)
{

	if (star_p == NULL)
	    return PL_FALSE;
	else
	{
		switch(len)
		{
		    case 1:
		    	*p = *(unsigned char*)star_p;
		    	break;
		    case 2:
		    	*p = *(short*)star_p;
		    	break;
		    case 4:
		    	*p = *(int*)star_p;
		    	break;
		    case 8:
		    	*p = *(long long*)star_p;
		    	break;
		    default :
		    	printf("undefined exp length in babel_ptrR\n");
		}
	}

		return PL_TRUE;
}

PlBool babel_ptrR_byte(PlLong* p,  PlLong* star_p, PlLong len)
{

	if (star_p == NULL)
	    return PL_FALSE;
	else
	{
		switch(len)
		{
		    case 1:
		    	*p = *(unsigned char*)star_p;
		    	break;
		    case 2:
		    	*p = *(short*)star_p;
		    	break;
		    case 4:
		    	*p = *(int*)star_p;
		    	break;
		    case 8:
		    	*p = *(long long*)star_p;
		    	break;
		    default :
		    	printf("undefined exp length in babel_ptrR\n");
		}
	}

	return PL_TRUE;
}

PlBool babel_ptrE(PlLong* p,  PlLong e, PlLong len)
{
	if (p == NULL)
	    return PL_FALSE;

	switch(len)
		{
		    case 1:
		    	*(unsigned char*)p = (unsigned char)e;
		    	break;
		    case 2:
		    	*(short*) p = (short)e;
		    	break;
		    case 4:
		    	*(int*)p = (int)e;
		    	break;
		    case 8:
		    	*(long long*)p = (long long)e;
		    	break;
		    default :
		    	printf("undefined exp length in babel_ptrL\n");
		}

        return PL_TRUE;
}
PlBool babel__implicit_c_0(char* arg_0, char* arg_1, int arg_2, char* arg_3) 
{
__assert_fail(arg_0, arg_1, arg_2, arg_3);
return PL_TRUE;
}
PlBool babel__implicit_c_1(void * arg_0, unsigned long  arg_1,  PlLong * babel_ret) 
{
*babel_ret = realloc(arg_0, arg_1);
return PL_TRUE;
}
PlBool babel__implicit_c_2(char const   * __restrict   arg_0, char * arg_1) 
{
printf(arg_0, arg_1);
return PL_TRUE;
}
PlBool babel__implicit_c_3(struct _IO_FILE * arg_0) 
{
fflush(arg_0);
return PL_TRUE;
}
PlBool babel__implicit_c_4(node_t * arg_0, node_t * arg_1, node_t * arg_2, size_t  arg_3) 
{
resize_prob_cil_lr_1(arg_0, arg_1, arg_2, arg_3);
return PL_TRUE;
}
PlBool babel__implicit_c_5(arc_t * arg_0, node_t * arg_1, node_t * arg_2, cost_t  arg_3, cost_t  arg_4, long  arg_5) 
{
insert_new_arc_cil_lr_1(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5);
return PL_TRUE;
}
PlBool babel__implicit_c_6(network_t * arg_0, arc_t * arg_1, node_t * arg_2, node_t * arg_3, cost_t  arg_4, cost_t  arg_5, long  arg_6, long  arg_7) 
{
replace_weaker_arc_cil_lr_1(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, arg_7);
return PL_TRUE;
}
PlBool babel__implicit_c_7(long * arg_0, cost_t  arg_1, arc_t * arg_2, arc_t * arg_3, void * arg_4) 
{
suspend_impl_cil_lr_1(arg_0, arg_1, arg_2, arg_3, arg_4);
return PL_TRUE;
}
PlBool babel__implicit_c_8(network_t * arg_0) 
{
refresh_neighbour_lists(arg_0);
return PL_TRUE;
}

PlBool babel__mcfutil_c_6(arc_t * arg_0, void * arg_1) 
{
flow_org_cost_cil_lr_1(arg_0, arg_1);
return PL_TRUE;
}

PlBool babel__mcfutil_c_10(void * arg_0) 
{
free(arg_0);
return PL_TRUE;
}
PlBool babel__mcfutil_c_11(void * arg_0) 
{
free(arg_0);
return PL_TRUE;
}
PlBool babel__mcfutil_c_12(void * arg_0) 
{
free(arg_0);
return PL_TRUE;
}
PlBool babel__mcfutil_c_13(char const   * __restrict   arg_0) 
{
printf(arg_0);
return PL_TRUE;
}
PlBool babel__mcfutil_c_14(char const   * __restrict   arg_0, int  arg_1, flow_t  arg_2) 
{
printf(arg_0, arg_1, arg_2);
return PL_TRUE;
}
PlBool babel__mcfutil_c_15(char const   * __restrict   arg_0) 
{
printf(arg_0);
return PL_TRUE;
}
PlBool babel__mcfutil_c_16(char const   * __restrict   arg_0, flow_t  arg_1) 
{
printf(arg_0, arg_1);
return PL_TRUE;
}
PlBool babel__mcfutil_c_17(char const   * __restrict   arg_0) 
{
printf(arg_0);
return PL_TRUE;
}
PlBool babel__mcfutil_c_18(char const   * __restrict   arg_0, flow_t  arg_1) 
{
printf(arg_0, arg_1);
return PL_TRUE;
}
PlBool babel__mcfutil_c_19(node_t ** arg_0, long * arg_1, node_t * arg_2) 
{
refresh_potential_cil_lr_1_cil_lr_1(arg_0, arg_1, arg_2);
return PL_TRUE;
}
PlBool babel__mcfutil_c_20(node_t ** arg_0, node_t ** arg_1) 
{
refresh_potential_cil_lr_1_cil_lr_2(arg_0, arg_1);
return PL_TRUE;
}
PlBool babel__mcfutil_c_21(long * arg_0, node_t * arg_1, node_t * arg_2, node_t * arg_3) 
{
refresh_potential_cil_lr_1(arg_0, arg_1, arg_2, arg_3);
return PL_TRUE;
}
