%...
babelJcc(OP, L, R) :-
    (  OP =:= 12 -> L =:= R
    ;  OP =:= 13 -> L \= R
    ;  OP =:= 14 -> L > R
    ;  OP =:= 15 -> L =< R
    ;  OP =:= 16 -> L < R
    ;  OP =:= 17 -> L >= R
    ).

:-foreign(babel_ptrR(-integer, +integer, +integer)).
:-foreign(babel_ptrE(+integer, +integer, +integer)).

babelPtrR(E, P, L) :- babel_ptrR(T, P, L), E is T.
babelPtrL(P, E, L) :- babel_ptrE(P, E, L).

babelAssign(Var, Val) :- Var is Val.
babelAssignStr(Var, Val) :- Var = Val.
babelAssignBool(Var, Val) :- Var = Val.


bea_is_dual_infeasible(ARC, RED_COST, R) :- 
(babelJcc(16, RED_COST, 0) ->
babelAssign(__CIL_TMP3, 1)
; babelAssign(__CIL_TMP3, 0)),

(babelJcc(13, __CIL_TMP3, 0) ->
babelAssign(__CIL_TMP7, ARC +1* 24),
babelAssign(__CIL_TMP8, __CIL_TMP7),
BabelExp_0 is __CIL_TMP8,
babelPtrR(__CIL_TMP9, BabelExp_0, 4),

(babelJcc(12, __CIL_TMP9, 1) ->
babelAssign(__CIL_TMP4, 1)
; babelAssign(__CIL_TMP4, 0)),

(babelJcc(13, __CIL_TMP4, 0) ->
babelAssign(R, 1),true
; babelAssign(R, 0),true)
; (babelJcc(14, RED_COST, 0) ->
babelAssign(__CIL_TMP5, 1)
; babelAssign(__CIL_TMP5, 0)),

(babelJcc(13, __CIL_TMP5, 0) ->
babelAssign(__CIL_TMP10, ARC +1* 24),
babelAssign(__CIL_TMP11, __CIL_TMP10),
BabelExp_1 is __CIL_TMP11,
babelPtrR(__CIL_TMP12, BabelExp_1, 4),

(babelJcc(12, __CIL_TMP12, 2) ->
babelAssign(__CIL_TMP6, 1)
; babelAssign(__CIL_TMP6, 0)),

(babelJcc(13, __CIL_TMP6, 0) ->
babelAssign(R, 1),true
; babelAssign(R, 0),true)
; babelAssign(R, 0),true)). 

%% :- foreign(babel__pbeampp_c_0(+integer, +integer, +integer)).
%% :- foreign(babel__pbeampp_c_1(+integer, +integer)).
%% :- foreign(babel__pbeampp_c_2(+integer, +integer)).

%% sort_basket(__CIL_PP_L, __CIL_PP_R, __CIL_FP_L, __CIL_FP_R, MIN, MAX, PERM, VOID) :- 

%% babelAssign(L_SSA_1, MIN),
%% babelAssign(R_SSA_1, MAX),
%% BabelExp_2 is L_SSA_1 + R_SSA_1,
%% babelAssign(__CIL_TMP19, BabelExp_2),
%% BabelExp_3 is __CIL_TMP19 // 2,
%% babelAssign(__CIL_TMP20, BabelExp_3),
%% BabelExp_4 is PERM + 8*__CIL_TMP20,
%% babelAssign(__CIL_TMP21, BabelExp_4),
%% BabelExp_5 is __CIL_TMP21,
%% babelPtrR(__CIL_TMP22, BabelExp_5, 8),
%% babelAssign(__CIL_TMP23, __CIL_TMP22),
%% babelAssign(__CIL_TMP24, __CIL_TMP23 +1* 16),
%% babelAssign(__CIL_TMP25, __CIL_TMP24),
%% BabelExp_6 is __CIL_TMP25,
%% babelPtrR(CUT_SSA_1, BabelExp_6, 8),
%% BabelExp_7 is L_SSA_1,
%% babelPtrL(__CIL_FP_L, BabelExp_7, 8),
%% BabelExp_8 is R_SSA_1,
%% babelPtrL(__CIL_FP_R, BabelExp_8, 8),
%% babel__pbeampp_c_0(__CIL_PP_L, __CIL_PP_R, CUT_SSA_1),
%% BabelExp_9 is __CIL_FP_L,
%% babelPtrR(L_SSA_2, BabelExp_9, 8),
%% BabelExp_10 is __CIL_FP_R,
%% babelPtrR(R_SSA_2, BabelExp_10, 8),

%% (babelJcc(16, MIN, R_SSA_2) ->
%% babelAssign(__CIL_TMP16, 1)
%% ; babelAssign(__CIL_TMP16, 0)),

%% (babelJcc(13, __CIL_TMP16, 0) ->
%% babel__pbeampp_c_1(MIN, R_SSA_2)
%% ; true),

%% (babelJcc(16, L_SSA_2, MAX) ->
%% babelAssign(__CIL_TMP17, 1)
%% ; babelAssign(__CIL_TMP17, 0)),

%% (babelJcc(13, __CIL_TMP17, 0) ->
%% (babelJcc(15, L_SSA_2, 50) ->
%% babelAssign(__CIL_TMP18, 1)
%% ; babelAssign(__CIL_TMP18, 0)),

%% (babelJcc(13, __CIL_TMP18, 0) ->
%% babel__pbeampp_c_2(L_SSA_2, MAX)
%% ; true)
%% ; true),
%% true. 

 
%% sort_basket_cil_lr_1_cil_lr_1(__CIL_AP_CUT, __CIL_AP_L, PERM) :- 
%% babelPtrR(__CIL_TMP4, __CIL_AP_L, 8),
%% __CIL_TMP5 is PERM + 8*__CIL_TMP4,
%% babelPtrR(__CIL_TMP6, __CIL_TMP5, 8),
%% __CIL_TMP8 is __CIL_TMP6 + 16,
%% babelPtrR(__CIL_TMP10, __CIL_TMP8, 8),
%% babelPtrR(__CIL_TMP11, __CIL_AP_CUT, 8),

%% (__CIL_TMP10 =< __CIL_TMP11 -> true;
%% babelPtrR(__CIL_TMP12, __CIL_AP_L, 8),
%% BabelExp_17 is __CIL_TMP12 + 1,
%% babelPtrL(__CIL_AP_L, BabelExp_17, 8),
%% sort_basket_cil_lr_1_cil_lr_1(__CIL_AP_CUT, __CIL_AP_L, PERM)). 

 
%% sort_basket_cil_lr_1_cil_lr_2(__CIL_AP_CUT, __CIL_AP_R, PERM, VOID) :- 
%% babelPtrR(__CIL_TMP4, __CIL+AP+R, 8),
%% __CIL_TMP5 is PERM + 8*__CIL_TMP4,
%% babelPtrR(__CIL_TMP6, __CIL_TMP5, 8),
%% babelAssign(__CIL_TMP9, __CIL_TMP6 + 16),
%% BabelExp_21 is __CIL_AP_CUT,
%% babelPtrR(__CIL_TMP10, __CIL_AP_CUT, 8),
%% babelPtrR(__CIL_TMP11, __CIL_TMP9, 8),

%% (__CIL_TMP10 > __CIL_TMP11 ->
%% true;
%% babelPtrR(__CIL_TMP12, __CIL_AP_R, 8),
%% BabelExp_24 is __CIL_TMP12 - 1,
%% babelPtrL(__CIL_AP_R, BabelExp_24, 8),
%% sort_basket_cil_lr_1_cil_lr_2(__CIL_AP_CUT, __CIL_AP_R, PERM, VOID)). 

%% :- foreign(babel__pbeampp_c_3(+integer, +integer)).
%% :- foreign(babel__pbeampp_c_4(+integer, +integer)).
%% :- foreign(babel__pbeampp_c_5(+integer, +integer, +integer)).

%% sort_basket_cil_lr_1(__CIL_PP_CUT, __CIL_FP_CUT, __CIL_AP_L, __CIL_AP_R, CUT, PERM, VOID) :- 
%% BabelExp_25 is CUT,
%% babelPtrL(__CIL_FP_CUT, BabelExp_25, 8),
%% babel__pbeampp_c_3(__CIL_PP_CUT, __CIL_AP_L),
%% BabelExp_26 is __CIL_FP_CUT,
%% babelPtrR(CUT_SSA_1, BabelExp_26, 8),
%% BabelExp_27 is CUT_SSA_1,
%% babelPtrL(__CIL_FP_CUT, BabelExp_27, 8),
%% babel__pbeampp_c_4(__CIL_PP_CUT, __CIL_AP_R),
%% BabelExp_28 is __CIL_FP_CUT,
%% babelPtrR(CUT_SSA_2, BabelExp_28, 8),
%% BabelExp_29 is __CIL_AP_L,
%% babelPtrR(__CIL_TMP13, BabelExp_29, 8),
%% BabelExp_30 is __CIL_AP_R,
%% babelPtrR(__CIL_TMP14, BabelExp_30, 8),

%% (babelJcc(16, __CIL_TMP13, __CIL_TMP14) ->
%% babelAssign(__CIL_TMP10, 1)
%% ; babelAssign(__CIL_TMP10, 0)),

%% (babelJcc(13, __CIL_TMP10, 0) ->
%% BabelExp_31 is __CIL_AP_L,
%% babelPtrR(__CIL_TMP15, BabelExp_31, 8),
%% BabelExp_32 is PERM + 8*__CIL_TMP15,
%% babelAssign(__CIL_TMP16, BabelExp_32),
%% BabelExp_33 is __CIL_TMP16,
%% babelPtrR(XCHANGE_SSA_1, BabelExp_33, 8),
%% BabelExp_34 is __CIL_AP_R,
%% babelPtrR(__CIL_TMP17, BabelExp_34, 8),
%% BabelExp_35 is PERM + 8*__CIL_TMP17,
%% babelAssign(__CIL_TMP18, BabelExp_35),
%% BabelExp_36 is __CIL_AP_L,
%% babelPtrR(__CIL_TMP19, BabelExp_36, 8),
%% BabelExp_37 is PERM + 8*__CIL_TMP19,
%% babelAssign(__CIL_TMP20, BabelExp_37),
%% babelPtrR(BabelExp_38, __CIL_TMP18, 8),
%% babelPtrL(__CIL_TMP20, BabelExp_38, 8),
%% BabelExp_39 is __CIL_AP_R,
%% babelPtrR(__CIL_TMP21, BabelExp_39, 8),
%% BabelExp_40 is PERM + 8*__CIL_TMP21,
%% babelAssign(__CIL_TMP22, BabelExp_40),
%% BabelExp_41 is XCHANGE_SSA_1,
%% babelPtrL(__CIL_TMP22, BabelExp_41, 8)
%% ; true),
%% BabelExp_42 is __CIL_AP_L,
%% babelPtrR(__CIL_TMP23, BabelExp_42, 8),
%% BabelExp_43 is __CIL_AP_R,
%% babelPtrR(__CIL_TMP24, BabelExp_43, 8),

%% (babelJcc(15, __CIL_TMP23, __CIL_TMP24) ->
%% babelAssign(__CIL_TMP11, 1)
%% ; babelAssign(__CIL_TMP11, 0)),

%% (babelJcc(13, __CIL_TMP11, 0) ->
%% BabelExp_44 is __CIL_AP_L,
%% babelPtrR(__CIL_TMP25, BabelExp_44, 8),
%% BabelExp_45 is __CIL_TMP25 + 1,
%% babelPtrL(__CIL_AP_L, BabelExp_45, 8),
%% BabelExp_46 is __CIL_AP_R,
%% babelPtrR(__CIL_TMP26, BabelExp_46, 8),
%% BabelExp_47 is __CIL_TMP26 - 1,
%% babelPtrL(__CIL_AP_R, BabelExp_47, 8)
%% ; true),
%% BabelExp_48 is __CIL_AP_L,
%% babelPtrR(__CIL_TMP27, BabelExp_48, 8),
%% BabelExp_49 is __CIL_AP_R,
%% babelPtrR(__CIL_TMP28, BabelExp_49, 8),

%% (babelJcc(15, __CIL_TMP27, __CIL_TMP28) ->
%% babelAssign(__CIL_TMP12, 1)
%% ; babelAssign(__CIL_TMP12, 0)),

%% (babelJcc(13, __CIL_TMP12, 0) ->
%% babel__pbeampp_c_5(__CIL_AP_L, __CIL_AP_R, CUT_SSA_2)
%% ; true). 


:- foreign(babel__implicit_c_0(+string, +string, +integer, +string)).
:- foreign(babel__implicit_c_1(+integer, +positive,  -integer)).
:- foreign(babel__implicit_c_2(+integer, +integer)).
:- foreign(babel__implicit_c_3(+integer)).
:- foreign(babel__implicit_c_4(+integer, +integer, +integer, +positive)).

resize_prob(__CIL_GP_STDOUT, NET, R) :- 


babelAssign(__CIL_TMP17, NET +1* 456),
babelAssign(__CIL_TMP18,  __CIL_TMP17),
BabelExp_0 is __CIL_TMP18,
babelPtrR(__CIL_TMP19, BabelExp_0, 8),
(babelJcc(17, __CIL_TMP19, 3) ->
babelAssign(__CIL_TMP16, 1)
; babelAssign(__CIL_TMP16, 0)),
babelAssign(__CIL_TMP20, NET +1* 416),
babelAssign(__CIL_TMP21,  __CIL_TMP20),
babelAssign(__CIL_TMP22, NET +1* 456),
babelAssign(__CIL_TMP23,  __CIL_TMP22),
BabelExp_1 is __CIL_TMP21,
babelPtrR(__CIL_TMP24, BabelExp_1, 8),
BabelExp_2 is __CIL_TMP23,
babelPtrR(__CIL_TMP25, BabelExp_2, 8),
babelAssign(__CIL_TMP26, NET +1* 416),
babelAssign(__CIL_TMP27,  __CIL_TMP26),
BabelExp_3 is __CIL_TMP24 + __CIL_TMP25,
babelPtrL(__CIL_TMP27, BabelExp_3, 8),
babelAssign(__CIL_TMP28, NET +1* 448),
babelAssign(__CIL_TMP29,  __CIL_TMP28),
babelAssign(__CIL_TMP30, NET +1* 456),
babelAssign(__CIL_TMP31,  __CIL_TMP30),
BabelExp_4 is __CIL_TMP29,
babelPtrR(__CIL_TMP32, BabelExp_4, 8),
BabelExp_5 is __CIL_TMP31,
babelPtrR(__CIL_TMP33, BabelExp_5, 8),
babelAssign(__CIL_TMP34, NET +1* 448),
babelAssign(__CIL_TMP35,  __CIL_TMP34),
BabelExp_6 is __CIL_TMP32 + __CIL_TMP33,
babelPtrL(__CIL_TMP35, BabelExp_6, 8),
babelAssign(__CIL_TMP36, NET +1* 568),
babelAssign(__CIL_TMP37,  __CIL_TMP36),
BabelExp_7 is __CIL_TMP37,
babelPtrR(__CIL_TMP38, BabelExp_7, 8),
babelAssign(__CIL_TMP39, NET +1* 416),
babelAssign(__CIL_TMP40,  __CIL_TMP39),
BabelExp_8 is __CIL_TMP40,
babelPtrR(__CIL_TMP41, BabelExp_8, 8),
BabelExp_9 is __CIL_TMP41,
babelAssign(__CIL_TMP42, BabelExp_9),
BabelExp_10 is __CIL_TMP42 * 64,
babelAssign(__CIL_TMP43, BabelExp_10),
babel__implicit_c_1(__CIL_TMP38, __CIL_TMP43 , TMP_SSA_1),
babelAssign(ARC_SSA_1,  TMP_SSA_1),
(babelJcc(12, ARC_SSA_1, 0) ->
babelAssign(MEM_57, NET),
babelAssign(__CIL_TMP44, MEM_57),
babel__implicit_c_2('NETWORK S: NOT ENOUGH MEMORY\\N', __CIL_TMP44),
BabelExp_11 is __CIL_GP_STDOUT,
babelPtrR(__CIL_TMP45, BabelExp_11, 8),
babel__implicit_c_3(__CIL_TMP45),
babelAssign(R, -1),true
; babelAssign(__CIL_TMP46, NET +1* 568),
babelAssign(__CIL_TMP47,  __CIL_TMP46),
BabelExp_12 is __CIL_TMP47,
babelPtrR(__CIL_TMP48, BabelExp_12, 8),
BabelExp_13 is  __CIL_TMP48,
babelAssign(__CIL_TMP49, BabelExp_13),
BabelExp_14 is  ARC_SSA_1 - __CIL_TMP49,
babelAssign(OFF_SSA_1, BabelExp_14),
babelAssign(__CIL_TMP50, NET +1* 568),
babelAssign(__CIL_TMP51,  __CIL_TMP50),
BabelExp_15 is ARC_SSA_1,
babelPtrL(__CIL_TMP51, BabelExp_15, 8),
babelAssign(__CIL_TMP52, NET +1* 424),
babelAssign(__CIL_TMP53,  __CIL_TMP52),
BabelExp_16 is __CIL_TMP53,
babelPtrR(__CIL_TMP54, BabelExp_16, 8),
babelAssign(__CIL_TMP55, NET +1* 576),
babelAssign(__CIL_TMP56,  __CIL_TMP55),
BabelExp_17 is ARC_SSA_1 +64* __CIL_TMP54,
babelPtrL(__CIL_TMP56, BabelExp_17, 8),
babelAssign(__CIL_TMP57, NET +1* 552),
babelAssign(__CIL_TMP58, __CIL_TMP57),
BabelExp_18 is __CIL_TMP58,
babelPtrR(NODE_SSA_1, BabelExp_18, 8),
babelAssign(ROOT_SSA_1, NODE_SSA_1),
babelAssign(NODE_SSA_2, NODE_SSA_1 +104* 1),
babelAssign(__CIL_TMP59, NET +1* 560),
babelAssign(__CIL_TMP60, __CIL_TMP59),
BabelExp_19 is __CIL_TMP60,
babelPtrR(__CIL_TMP61, BabelExp_19, 8),
babelAssign(STOP_SSA_1, __CIL_TMP61),
babel__implicit_c_4(NODE_SSA_2, STOP_SSA_1, ROOT_SSA_1, OFF_SSA_1),
babelAssign(R, 0),true). 

:- foreign(babel__implicit_c_5(+integer, +integer, +integer, +integer, +integer, +integer)).

insert_new_arc(NEW, NEWPOS, TAIL, HEAD, COST, RED_COST, VOID) :- 


 babelAssign(__CIL_TMP9, NEW +64* NEWPOS),
babelAssign(__CIL_TMP10, __CIL_TMP9),
babelAssign(__CIL_TMP11, __CIL_TMP10 +1* 8),
babelAssign(__CIL_TMP12, __CIL_TMP11),
BabelExp_20 is TAIL,
babelPtrL(__CIL_TMP12, BabelExp_20, 8),
babelAssign(__CIL_TMP13, NEW +64* NEWPOS),
babelAssign(__CIL_TMP14, __CIL_TMP13),
babelAssign(__CIL_TMP15, __CIL_TMP14 +1* 16),
babelAssign(__CIL_TMP16, __CIL_TMP15),
BabelExp_21 is HEAD,
babelPtrL(__CIL_TMP16, BabelExp_21, 8),
babelAssign(__CIL_TMP17, NEW +64* NEWPOS),
babelAssign(__CIL_TMP18, __CIL_TMP17),
babelAssign(__CIL_TMP19, __CIL_TMP18 +1* 56),
babelAssign(__CIL_TMP20,  __CIL_TMP19),
BabelExp_22 is COST,
babelPtrL(__CIL_TMP20, BabelExp_22, 8),
babelAssign(__CIL_TMP21, NEW + 64* NEWPOS),
babelAssign(__CIL_TMP22,  __CIL_TMP21),
BabelExp_23 is COST,
babelPtrL(__CIL_TMP22, BabelExp_23, 8),
babelAssign(__CIL_TMP23, NEW + 64* NEWPOS),
babelAssign(__CIL_TMP24, __CIL_TMP23),
babelAssign(__CIL_TMP25, __CIL_TMP24 +1* 48),
babelAssign(__CIL_TMP26,  __CIL_TMP25),
BabelExp_24 is RED_COST,
babelPtrL(__CIL_TMP26, BabelExp_24, 8),
BabelExp_25 is NEWPOS + 1,
babelAssign(POS_SSA_1, BabelExp_25),
babel__implicit_c_5(NEW, TAIL, HEAD, COST, RED_COST, POS_SSA_1). 

:- foreign(babel__implicit_c_6(+integer, +integer, +integer, +integer, +integer, +integer, +integer, +integer)).

replace_weaker_arc(NET, NEW, TAIL, HEAD, COST, RED_COST, VOID) :- 

__CIL_TMP15 is NEW + 8,
babelPtrL(__CIL_TMP15, TAIL, 8),
__CIL_TMP19 is NEW + 16,
babelPtrL(__CIL_TMP19, HEAD, 8),
__CIL_TMP23 is NEW + 56,
babelPtrL(__CIL_TMP23, COST, 8),
babelPtrL(NEW, COST, 8),
__CIL_TMP29 is NEW + 48,
babelPtrL(__CIL_TMP29, RED_COST, 8),
POS_SSA_1 is 1,
__CIL_TMP33 is NEW + 112,
__CIL_TMP35 is NEW + 128,
babelAssign(__CIL_TMP37, __CIL_TMP35 + 48),
babelPtrR(__CIL_TMP38, __CIL_TMP33, 8),
babelPtrR(__CIL_TMP39, __CIL_TMP37, 8),

(__CIL_TMP38 > __CIL_TMP39 ->
babelAssign(CMP_SSA_1, 2)
; babelAssign(CMP_SSA_1, 3)),
babel__implicit_c_6(NET, NEW, TAIL, HEAD, COST, RED_COST, POS_SSA_1, CMP_SSA_1). 

:- foreign(babel__implicit_c_7(+integer, +integer, +integer, +integer, +integer)).
:- foreign(babel__implicit_c_8(+integer)).

suspend_impl(__CIL_FP_SUSP, __CIL_PP_SUSP, NET, THRESHOLD, ALL, SUSP_SSA_2) :- 


 (babelJcc(13, ALL, 0) ->
babelAssign(__CIL_TMP16, NET +1* 440),
babelAssign(__CIL_TMP17,  __CIL_TMP16),
BabelExp_33 is __CIL_TMP17,
babelPtrR(SUSP_SSA_1, BabelExp_33, 8),
babelAssign(ARC_SSA_1, ARC),
babelAssign(NEW_ARC_SSA_1, NEW_ARC),
babelAssign(STOP_SSA_1, STOP),
babelAssign(SUSP_SSA_2, SUSP_SSA_1)
; babelAssign(__CIL_TMP18, NET +1* 576),
babelAssign(__CIL_TMP19,  __CIL_TMP18),
BabelExp_34 is __CIL_TMP19,
babelPtrR(__CIL_TMP20, BabelExp_34, 8),
BabelExp_35 is __CIL_TMP20,
babelAssign(STOP_SSA_1, BabelExp_35),
babelAssign(__CIL_TMP21, NET +1* 568),
babelAssign(__CIL_TMP22,  __CIL_TMP21),
babelAssign(__CIL_TMP23, NET +1* 424),
babelAssign(__CIL_TMP24,  __CIL_TMP23),
babelAssign(__CIL_TMP25, NET +1* 440),
babelAssign(__CIL_TMP26,  __CIL_TMP25),
BabelExp_36 is __CIL_TMP24,
babelPtrR(__CIL_TMP27, BabelExp_36, 8),
BabelExp_37 is __CIL_TMP26,
babelPtrR(__CIL_TMP28, BabelExp_37, 8),
BabelExp_38 is __CIL_TMP22,
babelPtrR(__CIL_TMP29, BabelExp_38, 8),
BabelExp_39 is __CIL_TMP27 - __CIL_TMP28,
babelAssign(__CIL_TMP30, BabelExp_39),
BabelExp_40 is __CIL_TMP29 + __CIL_TMP30,
babelAssign(NEW_ARC_SSA_1, BabelExp_40),
babelAssign(SUSP_SSA_1, 0),
babelAssign(ARC_SSA_1, NEW_ARC_SSA_1),
BabelExp_41 is SUSP_SSA_1,
babelPtrL(__CIL_FP_SUSP, BabelExp_41, 8),
babel__implicit_c_7(__CIL_PP_SUSP, THRESHOLD, NEW_ARC_SSA_1, ARC_SSA_1, STOP_SSA_1),
BabelExp_42 is __CIL_FP_SUSP,
babelPtrR(SUSP_SSA_2, BabelExp_42, 8)),

(babelJcc(13, SUSP_SSA_2, 0) ->
babelAssign(__CIL_TMP31, NET +1* 424),
babelAssign(__CIL_TMP32,  __CIL_TMP31),
BabelExp_43 is __CIL_TMP32,
babelPtrR(__CIL_TMP33, BabelExp_43, 8),
babelAssign(__CIL_TMP34, NET +1* 424),
babelAssign(__CIL_TMP35,  __CIL_TMP34),
BabelExp_44 is __CIL_TMP33 - SUSP_SSA_2,
babelPtrL(__CIL_TMP35, BabelExp_44, 8),
babelAssign(__CIL_TMP36, NET +1* 440),
babelAssign(__CIL_TMP37,  __CIL_TMP36),
BabelExp_45 is __CIL_TMP37,
babelPtrR(__CIL_TMP38, BabelExp_45, 8),
babelAssign(__CIL_TMP39, NET +1* 440),
babelAssign(__CIL_TMP40,  __CIL_TMP39),
BabelExp_46 is __CIL_TMP38 - SUSP_SSA_2,
babelPtrL(__CIL_TMP40, BabelExp_46, 8),
babelAssign(__CIL_TMP41, NET +1* 576),
babelAssign(__CIL_TMP42,  __CIL_TMP41),
BabelExp_47 is __CIL_TMP42,
babelPtrR(__CIL_TMP43, BabelExp_47, 8),
babelAssign(__CIL_TMP44, NET +1* 576),
babelAssign(__CIL_TMP45,  __CIL_TMP44),
BabelExp_48 is __CIL_TMP43 - SUSP_SSA_2,
babelPtrL(__CIL_TMP45, BabelExp_48, 8),
babelAssign(__CIL_TMP46, NET +1* 448),
babelAssign(__CIL_TMP47,  __CIL_TMP46),
BabelExp_49 is __CIL_TMP47,
babelPtrR(__CIL_TMP48, BabelExp_49, 8),
babelAssign(__CIL_TMP49, NET +1* 448),
babelAssign(__CIL_TMP50,  __CIL_TMP49),
BabelExp_50 is __CIL_TMP48 + SUSP_SSA_2,
babelPtrL(__CIL_TMP50, BabelExp_50, 8),
babel__implicit_c_8(NET)
; true),
true. 

 
suspend_impl_cil_lr_1(__CIL_AP_SUSP, THRESHOLD, NEW_ARC, ARC, STOP, VOID) :- 
(ARC >= STOP ->
babelAssign(__CIL_TMP16, ARC +1* 24),
babelAssign(__CIL_TMP17, __CIL_TMP16),
BabelExp_51 is __CIL_TMP17,
babelPtrR(__CIL_TMP18, BabelExp_51, 4),

(babelJcc(12, __CIL_TMP18, 1) ->
babelAssign(__CIL_TMP11, 1)
; babelAssign(__CIL_TMP11, 0)),

(babelJcc(13, __CIL_TMP11, 0) ->
babelAssign(__CIL_TMP19, ARC +1* 8),
babelAssign(__CIL_TMP20, __CIL_TMP19),
BabelExp_52 is __CIL_TMP20,
babelPtrR(__CIL_TMP21, BabelExp_52, 8),
BabelExp_53 is  __CIL_TMP21,
babelAssign(__CIL_TMP22, BabelExp_53),
babelAssign(MEM_56,  ARC),
BabelExp_54 is MEM_56,
babelPtrR(__CIL_TMP23, BabelExp_54, 8),
BabelExp_55 is __CIL_TMP22,
babelPtrR(__CIL_TMP24, BabelExp_55, 8),
babelAssign(__CIL_TMP25, ARC +1* 16),
babelAssign(__CIL_TMP26, __CIL_TMP25),
BabelExp_56 is __CIL_TMP26,
babelPtrR(__CIL_TMP27, BabelExp_56, 8),
BabelExp_57 is  __CIL_TMP27,
babelAssign(__CIL_TMP28, BabelExp_57),
BabelExp_58 is __CIL_TMP23 - __CIL_TMP24,
babelAssign(__CIL_TMP29, BabelExp_58),
BabelExp_59 is __CIL_TMP28,
babelPtrR(__CIL_TMP30, BabelExp_59, 8),
BabelExp_60 is __CIL_TMP29 + __CIL_TMP30,
babelAssign(RED_COST_SSA_1, BabelExp_60)
; BabelExp_61 is -2,
babelAssign(RED_COST_SSA_1, BabelExp_61),
babelAssign(__CIL_TMP31, ARC +1* 24),
babelAssign(__CIL_TMP32, __CIL_TMP31),
BabelExp_62 is __CIL_TMP32,
babelPtrR(__CIL_TMP33, BabelExp_62, 4),

(babelJcc(12, __CIL_TMP33, 0) ->
babelAssign(__CIL_TMP12, 1)
; babelAssign(__CIL_TMP12, 0)),

(babelJcc(13, __CIL_TMP12, 0) ->
babelAssign(__CIL_TMP34, ARC +1* 8),
babelAssign(__CIL_TMP35, __CIL_TMP34),
BabelExp_63 is __CIL_TMP35,
babelPtrR(__CIL_TMP36, BabelExp_63, 8),
BabelExp_64 is __CIL_TMP36,
babelAssign(__CIL_TMP37, BabelExp_64),
babelAssign(__CIL_TMP38, __CIL_TMP37 +1* 48),
babelAssign(__CIL_TMP39,  __CIL_TMP38),
BabelExp_65 is __CIL_TMP39,
babelPtrR(__CIL_TMP40, BabelExp_65, 8),
BabelExp_66 is __CIL_TMP40,
babelAssign(__CIL_TMP41, BabelExp_66),

(babelJcc(12, __CIL_TMP41, ARC) ->
babelAssign(__CIL_TMP13, 1)
; babelAssign(__CIL_TMP13, 0)),

(babelJcc(13, __CIL_TMP13, 0) ->
babelAssign(__CIL_TMP42, ARC +1* 8),
babelAssign(__CIL_TMP43, __CIL_TMP42),
BabelExp_67 is __CIL_TMP43,
babelPtrR(__CIL_TMP44, BabelExp_67, 8),
BabelExp_68 is __CIL_TMP44,
babelAssign(__CIL_TMP45, BabelExp_68),
babelAssign(__CIL_TMP46, __CIL_TMP45 +1* 48),
babelAssign(__CIL_TMP47,  __CIL_TMP46),
BabelExp_69 is NEW_ARC,
babelPtrL(__CIL_TMP47, BabelExp_69, 8)
; babelAssign(__CIL_TMP48, ARC +1* 16),
babelAssign(__CIL_TMP49, __CIL_TMP48),
BabelExp_70 is __CIL_TMP49,
babelPtrR(__CIL_TMP50, BabelExp_70, 8),
BabelExp_71 is __CIL_TMP50,
babelAssign(__CIL_TMP51, BabelExp_71),
babelAssign(__CIL_TMP52, __CIL_TMP51 +1* 48),
babelAssign(__CIL_TMP53,  __CIL_TMP52),
BabelExp_72 is NEW_ARC,
babelPtrL(__CIL_TMP53, BabelExp_72, 8))
; true)),

(RED_COST_SSA_1 =< THRESHOLD ->
BabelExp_73 is __CIL_AP_SUSP,
babelPtrR(__CIL_TMP54, BabelExp_73, 8),
BabelExp_74 is __CIL_TMP54 + 1,
babelPtrL(__CIL_AP_SUSP, BabelExp_74, 8),
babelAssign(NEW_ARC_SSA_1, NEW_ARC)
; babelPtrR(BabelExp_75, ARC, 8),
babelPtrL(NEW_ARC, BabelExp_75, 8),
babelAssign(NEW_ARC_SSA_1, NEW_ARC +64* 1)),
babelAssign(ARC_SSA_1, ARC +64* 1),!,
suspend_impl_cil_lr_1(__CIL_AP_SUSP, THRESHOLD, NEW_ARC_SSA_1, ARC_SSA_1, STOP, VOID); true),

(babelJcc(14, RED_COST, THRESHOLD) ->
babelAssign(__CIL_TMP15, 1)
; babelAssign(__CIL_TMP15, 0)),

(babelJcc(13, __CIL_TMP15, 0) ->
BabelExp_76 is __CIL_AP_SUSP,
babelPtrR(__CIL_TMP55, BabelExp_76, 8),
BabelExp_77 is __CIL_TMP55 + 1,
babelPtrL(__CIL_AP_SUSP, BabelExp_77, 8),
babelAssign(NEW_ARC_SSA_1, NEW_ARC)
; babelPtrR(BabelExp_78, ARC, 8),
babelPtrL(NEW_ARC, BabelExp_78, 8),
babelAssign(NEW_ARC_SSA_1, NEW_ARC +64* 1)),
babelAssign(ARC_SSA_1, ARC +64* 1),
suspend_impl_cil_lr_1(__CIL_AP_SUSP, THRESHOLD, NEW_ARC_SSA_1, ARC_SSA_1, STOP, VOID). 

 
replace_weaker_arc_cil_lr_1(NET, NEW, TAIL, HEAD, COST, RED_COST, POS, CMP, VOID) :- 


 babelAssign(__CIL_TMP16, NET +1* 448),
babelAssign(__CIL_TMP17,  __CIL_TMP16),
BabelExp_79 is __CIL_TMP17,
babelPtrR(__CIL_TMP18, BabelExp_79, 8),

(babelJcc(15, CMP, __CIL_TMP18) ->
babelAssign(__CIL_TMP12, 1)
; babelAssign(__CIL_TMP12, 0)),

(babelJcc(13, __CIL_TMP12, 0) ->
BabelExp_80 is CMP - 1,
babelAssign(__CIL_TMP19, BabelExp_80),
babelAssign(__CIL_TMP20, NEW + 64* __CIL_TMP19),
babelAssign(__CIL_TMP21, __CIL_TMP20),
babelAssign(__CIL_TMP22, __CIL_TMP21 +1* 48),
babelAssign(__CIL_TMP23,  __CIL_TMP22),
BabelExp_81 is __CIL_TMP23,
babelPtrR(__CIL_TMP24, BabelExp_81, 8),

(babelJcc(17, RED_COST, __CIL_TMP24) ->
babelAssign(__CIL_TMP13, 1)
; babelAssign(__CIL_TMP13, 0)),

(babelJcc(13, __CIL_TMP13, 0) ->
true
; BabelExp_82 is CMP - 1,
babelAssign(__CIL_TMP25, BabelExp_82),
babelAssign(__CIL_TMP26, NEW + 64* __CIL_TMP25),
babelAssign(__CIL_TMP27, __CIL_TMP26),
babelAssign(__CIL_TMP28, __CIL_TMP27 +1* 8),
babelAssign(__CIL_TMP29, __CIL_TMP28),
BabelExp_83 is POS - 1,
babelAssign(__CIL_TMP30, BabelExp_83),
babelAssign(__CIL_TMP31, NEW + 64* __CIL_TMP30),
babelAssign(__CIL_TMP32, __CIL_TMP31),
babelAssign(__CIL_TMP33, __CIL_TMP32 +1* 8),
babelAssign(__CIL_TMP34, __CIL_TMP33),
babelPtrR(BabelExp_84, __CIL_TMP29, 8),
babelPtrL(__CIL_TMP34, BabelExp_84, 8),
BabelExp_85 is CMP - 1,
babelAssign(__CIL_TMP35, BabelExp_85),
babelAssign(__CIL_TMP36, NEW + 64* __CIL_TMP35),
babelAssign(__CIL_TMP37, __CIL_TMP36),
babelAssign(__CIL_TMP38, __CIL_TMP37 +1* 16),
babelAssign(__CIL_TMP39, __CIL_TMP38),
BabelExp_86 is POS - 1,
babelAssign(__CIL_TMP40, BabelExp_86),
babelAssign(__CIL_TMP41, NEW + 64* __CIL_TMP40),
babelAssign(__CIL_TMP42, __CIL_TMP41),
babelAssign(__CIL_TMP43, __CIL_TMP42 +1* 16),
babelAssign(__CIL_TMP44, __CIL_TMP43),
babelPtrR(BabelExp_87, __CIL_TMP39, 8),
babelPtrL(__CIL_TMP44, BabelExp_87, 8),
BabelExp_88 is CMP - 1,
babelAssign(__CIL_TMP45, BabelExp_88),
babelAssign(__CIL_TMP46, NEW + 64* __CIL_TMP45),
babelAssign(__CIL_TMP47,  __CIL_TMP46),
BabelExp_89 is POS - 1,
babelAssign(__CIL_TMP48, BabelExp_89),
babelAssign(__CIL_TMP49, NEW + 64* __CIL_TMP48),
babelAssign(__CIL_TMP50,  __CIL_TMP49),
babelPtrR(BabelExp_90, __CIL_TMP47, 8),
babelPtrL(__CIL_TMP50, BabelExp_90, 8),
BabelExp_91 is CMP - 1,
babelAssign(__CIL_TMP51, BabelExp_91),
babelAssign(__CIL_TMP52, NEW + 64* __CIL_TMP51),
babelAssign(__CIL_TMP53,  __CIL_TMP52),
BabelExp_92 is POS - 1,
babelAssign(__CIL_TMP54, BabelExp_92),
babelAssign(__CIL_TMP55, NEW + 64* __CIL_TMP54),
babelAssign(__CIL_TMP56, __CIL_TMP55),
babelAssign(__CIL_TMP57, __CIL_TMP56 +1* 56),
babelAssign(__CIL_TMP58,  __CIL_TMP57),
babelPtrR(BabelExp_93, __CIL_TMP53, 8),
babelPtrL(__CIL_TMP58, BabelExp_93, 8),
BabelExp_94 is CMP - 1,
babelAssign(__CIL_TMP59, BabelExp_94),
babelAssign(__CIL_TMP60, NEW + 64* __CIL_TMP59),
babelAssign(__CIL_TMP61, __CIL_TMP60),
babelAssign(__CIL_TMP62, __CIL_TMP61 +1* 48),
babelAssign(__CIL_TMP63,  __CIL_TMP62),
BabelExp_95 is POS - 1,
babelAssign(__CIL_TMP64, BabelExp_95),
babelAssign(__CIL_TMP65, NEW + 64* __CIL_TMP64),
babelAssign(__CIL_TMP66, __CIL_TMP65),
babelAssign(__CIL_TMP67, __CIL_TMP66 +1* 48),
babelAssign(__CIL_TMP68,  __CIL_TMP67),
babelPtrR(BabelExp_96, __CIL_TMP63, 8),
babelPtrL(__CIL_TMP68, BabelExp_96, 8),
BabelExp_97 is CMP - 1,
babelAssign(__CIL_TMP69, BabelExp_97),
babelAssign(__CIL_TMP70, NEW + 64* __CIL_TMP69),
babelAssign(__CIL_TMP71, __CIL_TMP70),
babelAssign(__CIL_TMP72, __CIL_TMP71 +1* 8),
babelAssign(__CIL_TMP73, __CIL_TMP72),
BabelExp_98 is TAIL,
babelPtrL(__CIL_TMP73, BabelExp_98, 8),
BabelExp_99 is CMP - 1,
babelAssign(__CIL_TMP74, BabelExp_99),
babelAssign(__CIL_TMP75, NEW + 64* __CIL_TMP74),
babelAssign(__CIL_TMP76, __CIL_TMP75),
babelAssign(__CIL_TMP77, __CIL_TMP76 +1* 16),
babelAssign(__CIL_TMP78, __CIL_TMP77),
BabelExp_100 is HEAD,
babelPtrL(__CIL_TMP78, BabelExp_100, 8),
BabelExp_101 is CMP - 1,
babelAssign(__CIL_TMP79, BabelExp_101),
babelAssign(__CIL_TMP80, NEW + 64* __CIL_TMP79),
babelAssign(__CIL_TMP81,  __CIL_TMP80),
BabelExp_102 is COST,
babelPtrL(__CIL_TMP81, BabelExp_102, 8),
BabelExp_103 is CMP - 1,
babelAssign(__CIL_TMP82, BabelExp_103),
babelAssign(__CIL_TMP83, NEW + 64* __CIL_TMP82),
babelAssign(__CIL_TMP84, __CIL_TMP83),
babelAssign(__CIL_TMP85, __CIL_TMP84 +1* 56),
babelAssign(__CIL_TMP86,  __CIL_TMP85),
BabelExp_104 is COST,
babelPtrL(__CIL_TMP86, BabelExp_104, 8),
BabelExp_105 is CMP - 1,
babelAssign(__CIL_TMP87, BabelExp_105),
babelAssign(__CIL_TMP88, NEW + 64* __CIL_TMP87),
babelAssign(__CIL_TMP89, __CIL_TMP88),
babelAssign(__CIL_TMP90, __CIL_TMP89 +1* 48),
babelAssign(__CIL_TMP91,  __CIL_TMP90),
BabelExp_106 is RED_COST,
babelPtrL(__CIL_TMP91, BabelExp_106, 8),
babelAssign(POS_SSA_1, CMP),
BabelExp_107 is CMP * 2,
babelAssign(CMP_SSA_1, BabelExp_107),
babelAssign(__CIL_TMP92, NET +1* 448),
babelAssign(__CIL_TMP93,  __CIL_TMP92),
BabelExp_108 is CMP_SSA_1 + 1,
babelAssign(__CIL_TMP94, BabelExp_108),
BabelExp_109 is __CIL_TMP93,
babelPtrR(__CIL_TMP95, BabelExp_109, 8),

(babelJcc(15, __CIL_TMP94, __CIL_TMP95) ->
babelAssign(__CIL_TMP14, 1)
; babelAssign(__CIL_TMP14, 0)),

(babelJcc(13, __CIL_TMP14, 0) ->
BabelExp_110 is CMP_SSA_1 - 1,
babelAssign(__CIL_TMP96, BabelExp_110),
babelAssign(__CIL_TMP97, NEW + 64* __CIL_TMP96),
babelAssign(__CIL_TMP98, __CIL_TMP97),
babelAssign(__CIL_TMP99, __CIL_TMP98 +1* 48),
babelAssign(__CIL_TMP100,  __CIL_TMP99),
babelAssign(__CIL_TMP101, NEW + 64* CMP_SSA_1),
babelAssign(__CIL_TMP102, __CIL_TMP101),
babelAssign(__CIL_TMP103, __CIL_TMP102 +1* 48),
babelAssign(__CIL_TMP104,  __CIL_TMP103),
BabelExp_111 is __CIL_TMP100,
babelPtrR(__CIL_TMP105, BabelExp_111, 8),
BabelExp_112 is __CIL_TMP104,
babelPtrR(__CIL_TMP106, BabelExp_112, 8),

(babelJcc(16, __CIL_TMP105, __CIL_TMP106) ->
babelAssign(__CIL_TMP15, 1)
; babelAssign(__CIL_TMP15, 0)),

(babelJcc(13, __CIL_TMP15, 0) ->
BabelExp_113 is CMP_SSA_1 + 1,
babelAssign(CMP_SSA_2, BabelExp_113)
; babelAssign(CMP_SSA_2, CMP_SSA_1))
; babelAssign(CMP_SSA_2, CMP_SSA_1)),
replace_weaker_arc_cil_lr_1(NET, NEW, TAIL, HEAD, COST, RED_COST, POS_SSA_1, CMP_SSA_2, VOID),true),
replace_weaker_arc_cil_lr_1(NET, NEW, TAIL, HEAD, COST, RED_COST, POS, CMP, VOID),true
; true). 

 
insert_new_arc_cil_lr_1(NEW, TAIL, HEAD, COST, RED_COST, POS, VOID) :- 
 BabelExp_114 is POS - 1,
babelAssign(__CIL_TMP8, BabelExp_114),
(babelJcc(13, __CIL_TMP8, 0) ->
BabelExp_115 is POS / 2,
babelAssign(__CIL_TMP10, BabelExp_115),
BabelExp_116 is __CIL_TMP10 - 1,
babelAssign(__CIL_TMP11, BabelExp_116),
babelAssign(__CIL_TMP12, NEW + 64* __CIL_TMP11),
babelAssign(__CIL_TMP13, __CIL_TMP12),
babelAssign(__CIL_TMP14, __CIL_TMP13 +1* 48),
babelAssign(__CIL_TMP15,  __CIL_TMP14),
BabelExp_117 is __CIL_TMP15,
babelPtrR(__CIL_TMP16, BabelExp_117, 8),

(babelJcc(15, RED_COST, __CIL_TMP16) ->
babelAssign(__CIL_TMP9, 1)
; babelAssign(__CIL_TMP9, 0)),

(babelJcc(13, __CIL_TMP9, 0) ->
true
; BabelExp_118 is POS // 2,
babelAssign(__CIL_TMP17, BabelExp_118),
BabelExp_119 is __CIL_TMP17 - 1,
babelAssign(__CIL_TMP18, BabelExp_119),
babelAssign(__CIL_TMP19, NEW + 64* __CIL_TMP18),
babelAssign(__CIL_TMP20, __CIL_TMP19),
babelAssign(__CIL_TMP21, __CIL_TMP20 +1* 8),
babelAssign(__CIL_TMP22, __CIL_TMP21),
BabelExp_120 is POS - 1,
babelAssign(__CIL_TMP23, BabelExp_120),
babelAssign(__CIL_TMP24, NEW + 64* __CIL_TMP23),
babelAssign(__CIL_TMP25, __CIL_TMP24),
babelAssign(__CIL_TMP26, __CIL_TMP25 +1* 8),
babelAssign(__CIL_TMP27, __CIL_TMP26),
babelPtrR(BabelExp_121, __CIL_TMP22, 8),
babelPtrL(__CIL_TMP27, BabelExp_121, 8),
BabelExp_122 is POS // 2,
babelAssign(__CIL_TMP28, BabelExp_122),
BabelExp_123 is __CIL_TMP28 - 1,
babelAssign(__CIL_TMP29, BabelExp_123),
babelAssign(__CIL_TMP30, NEW + 64* __CIL_TMP29),
babelAssign(__CIL_TMP31, __CIL_TMP30),
babelAssign(__CIL_TMP32, __CIL_TMP31 +1* 16),
babelAssign(__CIL_TMP33, __CIL_TMP32),
BabelExp_124 is POS - 1,
babelAssign(__CIL_TMP34, BabelExp_124),
babelAssign(__CIL_TMP35, NEW + 64* __CIL_TMP34),
babelAssign(__CIL_TMP36, __CIL_TMP35),
babelAssign(__CIL_TMP37, __CIL_TMP36 +1* 16),
babelAssign(__CIL_TMP38, __CIL_TMP37),
babelPtrR(BabelExp_125, __CIL_TMP33, 8),
babelPtrL(__CIL_TMP38, BabelExp_125, 8),
BabelExp_126 is POS / 2,
babelAssign(__CIL_TMP39, BabelExp_126),
BabelExp_127 is __CIL_TMP39 - 1,
babelAssign(__CIL_TMP40, BabelExp_127),
babelAssign(__CIL_TMP41, NEW + 64* __CIL_TMP40),
babelAssign(__CIL_TMP42,  __CIL_TMP41),
BabelExp_128 is POS - 1,
babelAssign(__CIL_TMP43, BabelExp_128),
babelAssign(__CIL_TMP44, NEW + 64* __CIL_TMP43),
babelAssign(__CIL_TMP45,  __CIL_TMP44),
babelPtrR(BabelExp_129, __CIL_TMP42, 8),
babelPtrL(__CIL_TMP45, BabelExp_129, 8),
BabelExp_130 is POS // 2,
babelAssign(__CIL_TMP46, BabelExp_130),
BabelExp_131 is __CIL_TMP46 - 1,
babelAssign(__CIL_TMP47, BabelExp_131),
babelAssign(__CIL_TMP48, NEW + 64* __CIL_TMP47),
babelAssign(__CIL_TMP49,  __CIL_TMP48),
BabelExp_132 is POS - 1,
babelAssign(__CIL_TMP50, BabelExp_132),
babelAssign(__CIL_TMP51, NEW + 64* __CIL_TMP50),
babelAssign(__CIL_TMP52, __CIL_TMP51),
babelAssign(__CIL_TMP53, __CIL_TMP52 +1* 56),
babelAssign(__CIL_TMP54,  __CIL_TMP53),
babelPtrR(BabelExp_133, __CIL_TMP49, 8),
babelPtrL(__CIL_TMP54, BabelExp_133, 8),
BabelExp_134 is POS // 2,
babelAssign(__CIL_TMP55, BabelExp_134),
BabelExp_135 is __CIL_TMP55 - 1,
babelAssign(__CIL_TMP56, BabelExp_135),
babelAssign(__CIL_TMP57, NEW + 64* __CIL_TMP56),
babelAssign(__CIL_TMP58, __CIL_TMP57),
babelAssign(__CIL_TMP59, __CIL_TMP58 +1* 48),
babelAssign(__CIL_TMP60,  __CIL_TMP59),
BabelExp_136 is POS - 1,
babelAssign(__CIL_TMP61, BabelExp_136),
babelAssign(__CIL_TMP62, NEW + 64* __CIL_TMP61),
babelAssign(__CIL_TMP63, __CIL_TMP62),
babelAssign(__CIL_TMP64, __CIL_TMP63 +1* 48),
babelAssign(__CIL_TMP65,  __CIL_TMP64),
babelPtrR(BabelExp_137, __CIL_TMP60, 8),
babelPtrL(__CIL_TMP65, BabelExp_137, 8),
BabelExp_138 is POS // 2,
babelAssign(POS_SSA_1, BabelExp_138),
BabelExp_139 is POS_SSA_1 - 1,
babelAssign(__CIL_TMP66, BabelExp_139),
babelAssign(__CIL_TMP67, NEW + 64* __CIL_TMP66),
babelAssign(__CIL_TMP68, __CIL_TMP67),
babelAssign(__CIL_TMP69, __CIL_TMP68 +1* 8),
babelAssign(__CIL_TMP70, __CIL_TMP69),
BabelExp_140 is TAIL,
babelPtrL(__CIL_TMP70, BabelExp_140, 8),
BabelExp_141 is POS_SSA_1 - 1,
babelAssign(__CIL_TMP71, BabelExp_141),
babelAssign(__CIL_TMP72, NEW + 64* __CIL_TMP71),
babelAssign(__CIL_TMP73, __CIL_TMP72),
babelAssign(__CIL_TMP74, __CIL_TMP73 +1* 16),
babelAssign(__CIL_TMP75, __CIL_TMP74),
BabelExp_142 is HEAD,
babelPtrL(__CIL_TMP75, BabelExp_142, 8),
BabelExp_143 is POS_SSA_1 - 1,
babelAssign(__CIL_TMP76, BabelExp_143),
babelAssign(__CIL_TMP77, NEW + 64* __CIL_TMP76),
babelAssign(__CIL_TMP78,  __CIL_TMP77),
BabelExp_144 is COST,
babelPtrL(__CIL_TMP78, BabelExp_144, 8),
BabelExp_145 is POS_SSA_1 - 1,
babelAssign(__CIL_TMP79, BabelExp_145),
babelAssign(__CIL_TMP80, NEW + 64* __CIL_TMP79),
babelAssign(__CIL_TMP81, __CIL_TMP80),
babelAssign(__CIL_TMP82, __CIL_TMP81 +1* 56),
babelAssign(__CIL_TMP83,  __CIL_TMP82),
BabelExp_146 is COST,
babelPtrL(__CIL_TMP83, BabelExp_146, 8),
BabelExp_147 is POS_SSA_1 - 1,
babelAssign(__CIL_TMP84, BabelExp_147),
babelAssign(__CIL_TMP85, NEW + 64* __CIL_TMP84),
babelAssign(__CIL_TMP86, __CIL_TMP85),
babelAssign(__CIL_TMP87, __CIL_TMP86 +1* 48),
babelAssign(__CIL_TMP88,  __CIL_TMP87),
BabelExp_148 is RED_COST,
babelPtrL(__CIL_TMP88, BabelExp_148, 8),
insert_new_arc_cil_lr_1(NEW, TAIL, HEAD, COST, RED_COST, POS_SSA_1, VOID))
; true). 

 
resize_prob_cil_lr_1(NODE, STOP, ROOT, OFF) :- 
(NODE >= STOP -> true;
__CIL_TMP9 is NODE + 24,
babelPtrR(__CIL_TMP11, __CIL_TMP9, 8),
(__CIL_TMP11 \= ROOT ->
__CIL_TMP13 is NODE + 48,
babelPtrR(__CIL_TMP14, __CIL_TMP13, 8),
BabelExp_152 is  __CIL_TMP14,
babelAssign(__CIL_TMP15, BabelExp_152),
__CIL_TMP16 is __CIL_TMP15 + OFF,
__CIL_TMP18 is NODE +48,
babelPtrL(__CIL_TMP18, __CIL_TMP16, 8)
; true),
babelAssign(NODE_SSA_1, NODE +104* 1),
resize_prob_cil_lr_1(NODE_SSA_1, STOP, ROOT, OFF)).


refresh_neighbour_lists(NET, VOID) :- 
__CIL_TMP10 is NET + 552,
babelPtrR(NODE_SSA_1, __CIL_TMP10, 8),
__CIL_TMP12 is NET + 560,
babelPtrR(STOP_SSA_1, __CIL_TMP12, 8),
refresh_neighbour_lists_cil_lr_1(NODE_SSA_1, STOP_SSA_1),
babelAssign(__CIL_TMP15, NET + 568),
babelPtrR(ARC_SSA_1, __CIL_TMP15, 8),
__CIL_TMP17 is NET +576,
babelPtrR(STOP_SSA_2, __CIL_TMP17, 8),
refresh_neighbour_lists_cil_lr_2(ARC_SSA_1, STOP_SSA_2). 

:- foreign(babel__mcfutil_c_10(+integer)).
:- foreign(babel__mcfutil_c_11(+integer)).
:- foreign(babel__mcfutil_c_12(+integer)).

getfree(NET, RET) :- 
__CIL_TMP12 is NET + 552,
babelPtrR(__CIL_TMP8, __CIL_TMP12, 8),
(__CIL_TMP8 \= 0 -> (
__CIL_TMP14 is NET + 552,
babelPtrR(__CIL_TMP15, __CIL_TMP14, 8),
babel__mcfutil_c_10(__CIL_TMP15))
; true),
__CIL_TMP17 is NET + 568,
babelPtrR(__CIL_TMP9, __CIL_TMP17, 8),
(__CIL_TMP9 \= 0 ->
(__CIL_TMP19 is NET + 568,
babelPtrR(__CIL_TMP20, __CIL_TMP19, 8),
babel__mcfutil_c_11(__CIL_TMP20))
; true),
__CIL_TMP22 is NET +584,
babelPtrR(__CIL_TMP10, __CIL_TMP22, 8),
(__CIL_TMP10 \= 0 ->
(__CIL_TMP24 is NET + 584,
babelPtrR(__CIL_TMP25, __CIL_TMP24, 8),
babel__mcfutil_c_12(__CIL_TMP25))
;true),
__CIL_TMP27 is NET + 560,
babelPtrL(__CIL_TMP27, 0, 8),
__CIL_TMP29 is NET + 552,
babelPtrL(__CIL_TMP29, 0, 8),
__CIL_TMP31 is NET + 576,
babelPtrL(__CIL_TMP31, 0, 8),
__CIL_TMP33 is NET + 568,
babelPtrL(__CIL_TMP33, 0, 8),
__CIL_TMP35 is NET + 592,
babelPtrL(__CIL_TMP35,  0, 8),
__CIL_TMP37 is NET + 584,
babelPtrL(__CIL_TMP37, 0, 8),
RET is 0. 

 
refresh_potential_cil_lr_1_cil_lr_1(__CIL_AP_TMP, __CIL_AP_CHECKSUM, NODE, VOID) :- 


 (babelJcc(13, NODE, 0) ->
babelAssign(__CIL_TMP6, NODE +1* 8),
babelAssign(__CIL_TMP7, __CIL_TMP6),
BabelExp_76 is __CIL_TMP7,
babelPtrR(__CIL_TMP8, BabelExp_76, 4),

(babelJcc(12, __CIL_TMP8, 1) ->
babelAssign(__CIL_TMP5, 1)
; babelAssign(__CIL_TMP5, 0)),

(babelJcc(13, __CIL_TMP5, 0) ->
babelAssign(__CIL_TMP9, NODE +1* 48),
babelAssign(__CIL_TMP10, __CIL_TMP9),
BabelExp_77 is __CIL_TMP10,
babelPtrR(__CIL_TMP11, BabelExp_77, 8),
BabelExp_78 is __CIL_TMP11,
babelAssign(__CIL_TMP12, BabelExp_78),
babelAssign(__CIL_TMP13, NODE +1* 24),
babelAssign(__CIL_TMP14, __CIL_TMP13),
BabelExp_79 is __CIL_TMP14,
babelPtrR(__CIL_TMP15, BabelExp_79, 8),
BabelExp_80 is __CIL_TMP15,
babelAssign(__CIL_TMP16, BabelExp_80),
BabelExp_81 is __CIL_TMP12,
babelPtrR(__CIL_TMP17, BabelExp_81, 8),
BabelExp_82 is __CIL_TMP16,
babelPtrR(__CIL_TMP18, BabelExp_82, 8),
babelAssign(MEM_34, NODE),
BabelExp_83 is __CIL_TMP17 + __CIL_TMP18,
babelPtrL(MEM_34, BabelExp_83, 8)
; babelAssign(__CIL_TMP19, NODE +1* 24),
babelAssign(__CIL_TMP20, __CIL_TMP19),
BabelExp_84 is __CIL_TMP20,
babelPtrR(__CIL_TMP21, BabelExp_84, 8),
BabelExp_85 is __CIL_TMP21,
babelAssign(__CIL_TMP22, BabelExp_85),
babelAssign(__CIL_TMP23, NODE +1* 48),
babelAssign(__CIL_TMP24, __CIL_TMP23),
BabelExp_86 is __CIL_TMP24,
babelPtrR(__CIL_TMP25, BabelExp_86, 8),
BabelExp_87 is __CIL_TMP25,
babelAssign(__CIL_TMP26, BabelExp_87),
BabelExp_88 is __CIL_TMP22,
babelPtrR(__CIL_TMP27, BabelExp_88, 8),
BabelExp_89 is __CIL_TMP26,
babelPtrR(__CIL_TMP28, BabelExp_89, 8),
babelAssign(MEM_35, NODE),
BabelExp_90 is __CIL_TMP27 - __CIL_TMP28,
babelPtrL(MEM_35, BabelExp_90, 8),
BabelExp_91 is __CIL_AP_CHECKSUM,
babelPtrR(__CIL_TMP29, BabelExp_91, 8),
BabelExp_92 is __CIL_TMP29 + 1,
babelPtrL(__CIL_AP_CHECKSUM, BabelExp_92, 8)),
BabelExp_93 is NODE,
babelPtrL(__CIL_AP_TMP, BabelExp_93, 8),
babelAssign(__CIL_TMP30, NODE +1* 16),
babelAssign(__CIL_TMP31, __CIL_TMP30),
BabelExp_94 is __CIL_TMP31,
babelPtrR(NODE_SSA_1, BabelExp_94, 8),
refresh_potential_cil_lr_1_cil_lr_1(__CIL_AP_TMP, __CIL_AP_CHECKSUM, NODE_SSA_1, VOID)
; true),
BabelExp_95 is NODE,
babelPtrL(__CIL_AP_TMP, BabelExp_95, 8),
babelAssign(__CIL_TMP32, NODE +1* 16),
babelAssign(__CIL_TMP33, __CIL_TMP32),
BabelExp_96 is __CIL_TMP33,
babelPtrR(NODE_SSA_1, BabelExp_96, 8),
refresh_potential_cil_lr_1_cil_lr_1(__CIL_AP_TMP, __CIL_AP_CHECKSUM, NODE_SSA_1, VOID). 

 
refresh_potential_cil_lr_1_cil_lr_2(__CIL_AP_NODE, __CIL_AP_TMP, VOID) :- 


 BabelExp_97 is __CIL_AP_NODE,
babelPtrR(__CIL_TMP5, BabelExp_97, 8),
babelAssign(__CIL_TMP6, __CIL_TMP5),
babelAssign(__CIL_TMP7, __CIL_TMP6 +1* 24),
babelAssign(__CIL_TMP8, __CIL_TMP7),
BabelExp_98 is __CIL_TMP8,
babelPtrR(__CIL_TMP3, BabelExp_98, 8),
(babelJcc(13, __CIL_TMP3, 0) ->
BabelExp_99 is __CIL_AP_NODE,
babelPtrR(__CIL_TMP9, BabelExp_99, 8),
babelAssign(__CIL_TMP10, __CIL_TMP9),
babelAssign(__CIL_TMP11, __CIL_TMP10 +1* 32),
babelAssign(__CIL_TMP12, __CIL_TMP11),
babelPtrR(BabelExp_100, __CIL_TMP12, 8),
babelPtrL(__CIL_AP_TMP, BabelExp_100, 8),
BabelExp_101 is __CIL_AP_TMP,
babelPtrR(__CIL_TMP4, BabelExp_101, 8),
(babelJcc(13, __CIL_TMP4, 0) ->
babelPtrR(BabelExp_102, __CIL_AP_TMP, 8),
babelPtrL(__CIL_AP_NODE, BabelExp_102, 8),true
; BabelExp_103 is __CIL_AP_NODE,
babelPtrR(__CIL_TMP13, BabelExp_103, 8),
babelAssign(__CIL_TMP14, __CIL_TMP13),
babelAssign(__CIL_TMP15, __CIL_TMP14 +1* 24),
babelAssign(__CIL_TMP16, __CIL_TMP15),
babelPtrR(BabelExp_104, __CIL_TMP16, 8),
babelPtrL(__CIL_AP_NODE, BabelExp_104, 8),
refresh_potential_cil_lr_1_cil_lr_2(__CIL_AP_NODE, __CIL_AP_TMP, VOID),true)
; true). 

 :- foreign(babel__mcfutil_c_13(+integer)).
:- foreign(babel__mcfutil_c_14(+integer, +integer, +integer)).
:- foreign(babel__mcfutil_c_15(+integer)).
:- foreign(babel__mcfutil_c_16(+integer, +integer)).
:- foreign(babel__mcfutil_c_17(+integer)).
:- foreign(babel__mcfutil_c_18(+integer, +integer)).

primal_feasible_cil_lr_1(__CIL_AP_NET, __CIL_AP_RET, STOP, NODE, DUMMY, STOP_DUMMY, VOID) :- 
 (babelJcc(16, NODE, (STOP)) ->
babelAssign(__CIL_TMP14, 1)
; babelAssign(__CIL_TMP14, 0)),

(babelJcc(13, __CIL_TMP14, 0) ->
babelAssign(__CIL_TMP21, NODE +1* 48),
babelAssign(__CIL_TMP22, __CIL_TMP21),
BabelExp_105 is __CIL_TMP22,
babelPtrR(ARC_SSA_1, BabelExp_105, 8),
babelAssign(__CIL_TMP23, NODE +1* 80),
babelAssign(__CIL_TMP24, __CIL_TMP23),
BabelExp_106 is __CIL_TMP24,
babelPtrR(FLOW_SSA_1, BabelExp_106, 8),

(babelJcc(17, ARC_SSA_1, DUMMY) ->
babelAssign(__CIL_TMP15, 1)
; babelAssign(__CIL_TMP15, 0)),

(babelJcc(13, __CIL_TMP15, 0) ->
(babelJcc(16, ARC_SSA_1, STOP_DUMMY) ->
babelAssign(__CIL_TMP16, 1)
; babelAssign(__CIL_TMP16, 0)),

(babelJcc(13, __CIL_TMP16, 0) ->
(babelJcc(17, FLOW_SSA_1, 0) ->
babelAssign(__CIL_TMP17, 1)
; babelAssign(__CIL_TMP17, 0)),

(babelJcc(13, __CIL_TMP17, 0) ->
babelAssign(TMP_SSA_1, FLOW_SSA_1)
; (babelJcc(12, FLOW_SSA_1, 0) ->
babelAssign(TMP_SSA_1, 1)
; babelAssign(TMP_SSA_1, 0))),
BabelExp_107 is __CIL_AP_NET,
babelPtrR(__CIL_TMP25, BabelExp_107, 8),
babelAssign(__CIL_TMP26, __CIL_TMP25),
babelAssign(__CIL_TMP27, __CIL_TMP26 +1* 512),
babelAssign(__CIL_TMP28, __CIL_TMP27),
BabelExp_108 is __CIL_TMP28,
babelPtrR(__CIL_TMP29, BabelExp_108, 8),

(babelJcc(14, TMP_SSA_1, __CIL_TMP29) ->
babelAssign(__CIL_TMP18, 1)
; babelAssign(__CIL_TMP18, 0)),

(babelJcc(13, __CIL_TMP18, 0) ->
babel__mcfutil_c_13('PRIMAL NETWORK SIMPLEX: '),
babelAssign(__CIL_TMP30, NODE +1* 96),
babelAssign(__CIL_TMP31, __CIL_TMP30),
BabelExp_109 is __CIL_TMP31,
babelPtrR(__CIL_TMP32, BabelExp_109, 4),
babel__mcfutil_c_14('ARTIFICIAL ARC WITH NONZERO FLOW, NODE D (LD)\\N', __CIL_TMP32, FLOW_SSA_1)
; true)
; babelAssign(TMP_SSA_1, TMP)),
babelAssign(NODE_SSA_1, NODE +104),
primal_feasible_cil_lr_1(__CIL_AP_NET, __CIL_AP_RET, STOP, NODE_SSA_1, DUMMY, STOP_DUMMY, VOID),true
; BabelExp_110 is __CIL_AP_NET,
babelPtrR(__CIL_TMP33, BabelExp_110, 8),
babelAssign(__CIL_TMP34, __CIL_TMP33),
babelAssign(__CIL_TMP35, __CIL_TMP34 +1* 512),
babelAssign(__CIL_TMP36, __CIL_TMP35),
BabelExp_111 is __CIL_TMP36,
babelPtrR(__CIL_TMP37, BabelExp_111, 8),

(babelJcc(12, __CIL_TMP37, 0) ->
babelAssign(__CIL_TMP38, 1)
; babelAssign(__CIL_TMP38, 0)),


(babelJcc(16, FLOW_SSA_1, __CIL_TMP38) ->
babelAssign(__CIL_TMP19, 1)
; babelAssign(__CIL_TMP19, 0)),

(babelJcc(13, __CIL_TMP19, 0) ->
babel__mcfutil_c_15('PRIMAL NETWORK SIMPLEX: '),
babel__mcfutil_c_16('BASIS PRIMAL INFEASIBLE (LD)\\N', FLOW_SSA_1),
BabelExp_112 is __CIL_AP_NET,
babelPtrR(__CIL_TMP39, BabelExp_112, 8),
babelAssign(__CIL_TMP40, __CIL_TMP39),
babelAssign(__CIL_TMP41, __CIL_TMP40 +1* 488),
babelAssign(__CIL_TMP42, __CIL_TMP41),
BabelExp_113 is 0,
babelPtrL(__CIL_TMP42, BabelExp_113, 8),
BabelExp_114 is 1,
babelPtrL(__CIL_AP_RET, BabelExp_114, 4),true
; BabelExp_115 is __CIL_AP_NET,
babelPtrR(__CIL_TMP43, BabelExp_115, 8),
babelAssign(__CIL_TMP44, __CIL_TMP43),
babelAssign(__CIL_TMP45, __CIL_TMP44 +1* 512),
babelAssign(__CIL_TMP46, __CIL_TMP45),
BabelExp_116 is FLOW_SSA_1 - 1,
babelAssign(__CIL_TMP47, BabelExp_116),
BabelExp_117 is __CIL_TMP46,
babelPtrR(__CIL_TMP48, BabelExp_117, 8),

(babelJcc(14, __CIL_TMP47, __CIL_TMP48) ->
babelAssign(__CIL_TMP20, 1)
; babelAssign(__CIL_TMP20, 0)),

(babelJcc(13, __CIL_TMP20, 0) ->
babel__mcfutil_c_17('PRIMAL NETWORK SIMPLEX: '),
babel__mcfutil_c_18('BASIS PRIMAL INFEASIBLE (LD)\\N', FLOW_SSA_1),
BabelExp_118 is __CIL_AP_NET,
babelPtrR(__CIL_TMP49, BabelExp_118, 8),
babelAssign(__CIL_TMP50, __CIL_TMP49),
babelAssign(__CIL_TMP51, __CIL_TMP50 +1* 488),
babelAssign(__CIL_TMP52, __CIL_TMP51),
BabelExp_119 is 0,
babelPtrL(__CIL_TMP52, BabelExp_119, 8),
BabelExp_120 is 1,
babelPtrL(__CIL_AP_RET, BabelExp_120, 4),true
; babelAssign(NODE_SSA_1, NODE +104),
primal_feasible_cil_lr_1(__CIL_AP_NET, __CIL_AP_RET, STOP, NODE_SSA_1, DUMMY, STOP_DUMMY, VOID),true)))
; true). 

 
flow_org_cost_cil_lr_2(NODE, STOP) :- 

(NODE =:= STOP -> true;
(
babelAssign(__CIL_TMP5, NODE +1* 80),
babelAssign(__CIL_TMP6, __CIL_TMP5),
babelAssign(__CIL_TMP7, NODE +1* 48),
babelAssign(__CIL_TMP8, __CIL_TMP7),
BabelExp_121 is __CIL_TMP8,
babelPtrR(__CIL_TMP9, BabelExp_121, 8),
BabelExp_122 is __CIL_TMP9,
babelAssign(__CIL_TMP10, BabelExp_122),
babelAssign(__CIL_TMP11, __CIL_TMP10 +1* 48),
babelAssign(__CIL_TMP12, __CIL_TMP11),
babelPtrR(BabelExp_123, __CIL_TMP6, 8),
babelPtrL(__CIL_TMP12, BabelExp_123, 8),
babelAssign(NODE_SSA_1, NODE +104),
flow_org_cost_cil_lr_2(NODE_SSA_1, STOP))).

 
flow_org_cost_cil_lr_3(__CIL_AP_NET, __CIL_AP_FLEET, __CIL_AP_OPERATIONAL_COST, ARC, STOP) :- 
(ARC =:= STOP -> true;
babelAssign(__CIL_TMP13, ARC +1* 48),
babelAssign(__CIL_TMP14, __CIL_TMP13),
BabelExp_124 is __CIL_TMP14,
babelPtrR(__CIL_TMP8, BabelExp_124, 8),
(babelJcc(13, __CIL_TMP8, 0) ->
babelAssign(__CIL_TMP15, ARC +1* 8),
babelAssign(__CIL_TMP16, __CIL_TMP15),
BabelExp_125 is __CIL_TMP16,
babelPtrR(__CIL_TMP17, BabelExp_125, 8),
BabelExp_126 is __CIL_TMP17,
babelAssign(__CIL_TMP18, BabelExp_126),
babelAssign(__CIL_TMP19, __CIL_TMP18 +1* 96),
babelAssign(__CIL_TMP20, __CIL_TMP19),
BabelExp_127 is __CIL_TMP20,
babelPtrR(__CIL_TMP21, BabelExp_127, 4),

(__CIL_TMP21 < 0 ->
babelAssign(__CIL_TMP22, ARC +1* 8),
babelAssign(__CIL_TMP23, __CIL_TMP22),
BabelExp_128 is __CIL_TMP23,
babelPtrR(__CIL_TMP24, BabelExp_128, 8),
BabelExp_129 is __CIL_TMP24,
babelAssign(__CIL_TMP25, BabelExp_129),
babelAssign(__CIL_TMP26, __CIL_TMP25 +1* 96),
babelAssign(__CIL_TMP27, __CIL_TMP26),
BabelExp_130 is __CIL_TMP27,
babelPtrR(__CIL_TMP28, BabelExp_130, 4),

(__CIL_TMP28 \= 0 ->
babelAssign(__CIL_TMP29, ARC +1* 56),
babelAssign(__CIL_TMP30, __CIL_TMP29),
BabelExp_131 is __CIL_AP_NET,
babelPtrR(__CIL_TMP31, BabelExp_131, 8),
babelAssign(__CIL_TMP32, __CIL_TMP31),
babelAssign(__CIL_TMP33, __CIL_TMP32 +1* 528),
babelAssign(__CIL_TMP34, __CIL_TMP33),
BabelExp_132 is __CIL_TMP30,
babelPtrR(__CIL_TMP35, BabelExp_132, 8),
BabelExp_133 is __CIL_TMP34,
babelPtrR(__CIL_TMP36, BabelExp_133, 8),
BabelExp_134 is __CIL_AP_OPERATIONAL_COST,
babelPtrR(__CIL_TMP37, BabelExp_134, 8),
BabelExp_135 is __CIL_TMP35 - __CIL_TMP36,
babelAssign(__CIL_TMP38, BabelExp_135),
BabelExp_136 is __CIL_TMP37 + __CIL_TMP38,
babelPtrL(__CIL_AP_OPERATIONAL_COST, BabelExp_136, 8),
BabelExp_137 is __CIL_AP_FLEET,
babelPtrR(__CIL_TMP39, BabelExp_137, 8),
BabelExp_138 is __CIL_TMP39 + 1,
babelPtrL(__CIL_AP_FLEET, BabelExp_138, 8)
; babelAssign(__CIL_TMP40, ARC +1* 56),
babelAssign(__CIL_TMP41, __CIL_TMP40),
BabelExp_139 is __CIL_AP_OPERATIONAL_COST,
babelPtrR(__CIL_TMP42, BabelExp_139, 8),
BabelExp_140 is __CIL_TMP41,
babelPtrR(__CIL_TMP43, BabelExp_140, 8),
BabelExp_141 is __CIL_TMP42 + __CIL_TMP43,
babelPtrL(__CIL_AP_OPERATIONAL_COST, BabelExp_141, 8))
; babelAssign(__CIL_TMP44, ARC +1* 16),
babelAssign(__CIL_TMP45, __CIL_TMP44),
BabelExp_142 is __CIL_TMP45,
babelPtrR(__CIL_TMP46, BabelExp_142, 8),
BabelExp_143 is __CIL_TMP46,
babelAssign(__CIL_TMP47, BabelExp_143),
babelAssign(__CIL_TMP48, __CIL_TMP47 +1* 96),
babelAssign(__CIL_TMP49, __CIL_TMP48),
BabelExp_144 is __CIL_TMP49,
babelPtrR(__CIL_TMP50, BabelExp_144, 4),

(babelJcc(15, __CIL_TMP50, 0) ->
babelAssign(__CIL_TMP11, 1)
; babelAssign(__CIL_TMP11, 0)),

(babelJcc(13, __CIL_TMP11, 0) ->
babelAssign(__CIL_TMP51, ARC +1* 8),
babelAssign(__CIL_TMP52, __CIL_TMP51),
BabelExp_145 is __CIL_TMP52,
babelPtrR(__CIL_TMP53, BabelExp_145, 8),
BabelExp_146 is __CIL_TMP53,
babelAssign(__CIL_TMP54, BabelExp_146),
babelAssign(__CIL_TMP55, __CIL_TMP54 +1* 96),
babelAssign(__CIL_TMP56, __CIL_TMP55),
BabelExp_147 is __CIL_TMP56,
babelPtrR(__CIL_TMP57, BabelExp_147, 4),

(babelJcc(12, __CIL_TMP57, 0) ->
babelAssign(__CIL_TMP12, 1)
; babelAssign(__CIL_TMP12, 0)),

(babelJcc(13, __CIL_TMP12, 0) ->
babelAssign(__CIL_TMP58, ARC +1* 56),
babelAssign(__CIL_TMP59, __CIL_TMP58),
BabelExp_148 is __CIL_AP_NET,
babelPtrR(__CIL_TMP60, BabelExp_148, 8),
babelAssign(__CIL_TMP61, __CIL_TMP60),
babelAssign(__CIL_TMP62, __CIL_TMP61 +1* 528),
babelAssign(__CIL_TMP63, __CIL_TMP62),
BabelExp_149 is __CIL_TMP59,
babelPtrR(__CIL_TMP64, BabelExp_149, 8),
BabelExp_150 is __CIL_TMP63,
babelPtrR(__CIL_TMP65, BabelExp_150, 8),
BabelExp_151 is __CIL_AP_OPERATIONAL_COST,
babelPtrR(__CIL_TMP66, BabelExp_151, 8),
BabelExp_152 is __CIL_TMP64 - __CIL_TMP65,
babelAssign(__CIL_TMP67, BabelExp_152),
BabelExp_153 is __CIL_TMP66 + __CIL_TMP67,
babelPtrL(__CIL_AP_OPERATIONAL_COST, BabelExp_153, 8),
BabelExp_154 is __CIL_AP_FLEET,
babelPtrR(__CIL_TMP68, BabelExp_154, 8),
BabelExp_155 is __CIL_TMP68 + 1,
babelPtrL(__CIL_AP_FLEET, BabelExp_155, 8)
; babelAssign(__CIL_TMP69, ARC +1* 56),
babelAssign(__CIL_TMP70, __CIL_TMP69),
BabelExp_156 is __CIL_AP_OPERATIONAL_COST,
babelPtrR(__CIL_TMP71, BabelExp_156, 8),
BabelExp_157 is __CIL_TMP70,
babelPtrR(__CIL_TMP72, BabelExp_157, 8),
BabelExp_158 is __CIL_TMP71 + __CIL_TMP72,
babelPtrL(__CIL_AP_OPERATIONAL_COST, BabelExp_158, 8))
; true))
; true),
babelAssign(ARC_SSA_1, ARC +64),
flow_org_cost_cil_lr_3(__CIL_AP_NET, __CIL_AP_FLEET, __CIL_AP_OPERATIONAL_COST, ARC_SSA_1, STOP)).

 
flow_cost_cil_lr_1(ARC, STOP, VOID) :- 


 (babelJcc(13, ARC, (STOP)) ->
babelAssign(__CIL_TMP4, 1)
; babelAssign(__CIL_TMP4, 0)),

(babelJcc(13, __CIL_TMP4, 0) ->
babelAssign(__CIL_TMP6, ARC +1* 24),
babelAssign(__CIL_TMP7, __CIL_TMP6),
BabelExp_159 is __CIL_TMP7,
babelPtrR(__CIL_TMP8, BabelExp_159, 4),

(babelJcc(12, __CIL_TMP8, 2) ->
babelAssign(__CIL_TMP5, 1)
; babelAssign(__CIL_TMP5, 0)),

(babelJcc(13, __CIL_TMP5, 0) ->
babelAssign(__CIL_TMP9, ARC +1* 48),
babelAssign(__CIL_TMP10, __CIL_TMP9),
BabelExp_160 is 1,
babelPtrL(__CIL_TMP10, BabelExp_160, 8)
; babelAssign(__CIL_TMP11, ARC +1* 48),
babelAssign(__CIL_TMP12, __CIL_TMP11),
BabelExp_161 is 0,
babelPtrL(__CIL_TMP12, BabelExp_161, 8)),
babelAssign(ARC_SSA_1, ARC +64),
flow_cost_cil_lr_1(ARC_SSA_1, STOP, VOID)
; true),
babelAssign(ARC_SSA_1, ARC +64),
flow_cost_cil_lr_1(ARC_SSA_1, STOP, VOID). 

 
flow_cost_cil_lr_2(NODE, STOP, VOID) :- 


 (babelJcc(13, NODE, (STOP)) ->
babelAssign(__CIL_TMP4, 1)
; babelAssign(__CIL_TMP4, 0)),

(babelJcc(13, __CIL_TMP4, 0) ->
babelAssign(__CIL_TMP5, NODE +1* 80),
babelAssign(__CIL_TMP6, __CIL_TMP5),
babelAssign(__CIL_TMP7, NODE +1* 48),
babelAssign(__CIL_TMP8, __CIL_TMP7),
BabelExp_162 is __CIL_TMP8,
babelPtrR(__CIL_TMP9, BabelExp_162, 8),
BabelExp_163 is __CIL_TMP9,
babelAssign(__CIL_TMP10, BabelExp_163),
babelAssign(__CIL_TMP11, __CIL_TMP10 +1* 48),
babelAssign(__CIL_TMP12, __CIL_TMP11),
babelPtrR(BabelExp_164, __CIL_TMP6, 8),
babelPtrL(__CIL_TMP12, BabelExp_164, 8),
babelAssign(NODE_SSA_1, NODE +104),
flow_cost_cil_lr_2(NODE_SSA_1, STOP, VOID),true
; true). 

 
flow_cost_cil_lr_3(__CIL_AP_NET, __CIL_AP_FLEET, __CIL_AP_OPERATIONAL_COST, ARC, STOP, VOID) :- 


 (babelJcc(13, ARC, (STOP)) ->
babelAssign(__CIL_TMP7, 1)
; babelAssign(__CIL_TMP7, 0)),

(babelJcc(13, __CIL_TMP7, 0) ->
babelAssign(__CIL_TMP13, ARC +1* 48),
babelAssign(__CIL_TMP14, __CIL_TMP13),
BabelExp_165 is __CIL_TMP14,
babelPtrR(__CIL_TMP8, BabelExp_165, 8),
(babelJcc(13, __CIL_TMP8, 0) ->
babelAssign(__CIL_TMP15, ARC +1* 8),
babelAssign(__CIL_TMP16, __CIL_TMP15),
BabelExp_166 is __CIL_TMP16,
babelPtrR(__CIL_TMP17, BabelExp_166, 8),
BabelExp_167 is __CIL_TMP17,
babelAssign(__CIL_TMP18, BabelExp_167),
babelAssign(__CIL_TMP19, __CIL_TMP18 +1* 96),
babelAssign(__CIL_TMP20, __CIL_TMP19),
BabelExp_168 is __CIL_TMP20,
babelPtrR(__CIL_TMP21, BabelExp_168, 4),

(babelJcc(17, __CIL_TMP21, 0) ->
babelAssign(__CIL_TMP9, 1)
; babelAssign(__CIL_TMP9, 0)),

(babelJcc(13, __CIL_TMP9, 0) ->
babelAssign(__CIL_TMP22, ARC +1* 8),
babelAssign(__CIL_TMP23, __CIL_TMP22),
BabelExp_169 is __CIL_TMP23,
babelPtrR(__CIL_TMP24, BabelExp_169, 8),
BabelExp_170 is __CIL_TMP24,
babelAssign(__CIL_TMP25, BabelExp_170),
babelAssign(__CIL_TMP26, __CIL_TMP25 +1* 96),
babelAssign(__CIL_TMP27, __CIL_TMP26),
BabelExp_171 is __CIL_TMP27,
babelPtrR(__CIL_TMP28, BabelExp_171, 4),

(babelJcc(12, __CIL_TMP28, 0) ->
babelAssign(__CIL_TMP10, 1)
; babelAssign(__CIL_TMP10, 0)),

(babelJcc(13, __CIL_TMP10, 0) ->
BabelExp_172 is __CIL_AP_NET,
babelPtrR(__CIL_TMP29, BabelExp_172, 8),
babelAssign(__CIL_TMP30, __CIL_TMP29),
babelAssign(__CIL_TMP31, __CIL_TMP30 +1* 528),
babelAssign(__CIL_TMP32, __CIL_TMP31),
babelAssign(MEM_65, ARC),
BabelExp_173 is MEM_65,
babelPtrR(__CIL_TMP33, BabelExp_173, 8),
BabelExp_174 is __CIL_TMP32,
babelPtrR(__CIL_TMP34, BabelExp_174, 8),
BabelExp_175 is __CIL_AP_OPERATIONAL_COST,
babelPtrR(__CIL_TMP35, BabelExp_175, 8),
BabelExp_176 is __CIL_TMP33 - __CIL_TMP34,
babelAssign(__CIL_TMP36, BabelExp_176),
BabelExp_177 is __CIL_TMP35 + __CIL_TMP36,
babelPtrL(__CIL_AP_OPERATIONAL_COST, BabelExp_177, 8),
BabelExp_178 is __CIL_AP_FLEET,
babelPtrR(__CIL_TMP37, BabelExp_178, 8),
BabelExp_179 is __CIL_TMP37 + 1,
babelPtrL(__CIL_AP_FLEET, BabelExp_179, 8)
; BabelExp_180 is __CIL_AP_OPERATIONAL_COST,
babelPtrR(__CIL_TMP38, BabelExp_180, 8),
babelAssign(MEM_66, ARC),
BabelExp_181 is MEM_66,
babelPtrR(__CIL_TMP39, BabelExp_181, 8),
BabelExp_182 is __CIL_TMP38 + __CIL_TMP39,
babelPtrL(__CIL_AP_OPERATIONAL_COST, BabelExp_182, 8))
; babelAssign(__CIL_TMP40, ARC +1* 16),
babelAssign(__CIL_TMP41, __CIL_TMP40),
BabelExp_183 is __CIL_TMP41,
babelPtrR(__CIL_TMP42, BabelExp_183, 8),
BabelExp_184 is __CIL_TMP42,
babelAssign(__CIL_TMP43, BabelExp_184),
babelAssign(__CIL_TMP44, __CIL_TMP43 +1* 96),
babelAssign(__CIL_TMP45, __CIL_TMP44),
BabelExp_185 is __CIL_TMP45,
babelPtrR(__CIL_TMP46, BabelExp_185, 4),

(babelJcc(15, __CIL_TMP46, 0) ->
babelAssign(__CIL_TMP11, 1)
; babelAssign(__CIL_TMP11, 0)),

(babelJcc(13, __CIL_TMP11, 0) ->
babelAssign(__CIL_TMP47, ARC +1* 8),
babelAssign(__CIL_TMP48, __CIL_TMP47),
BabelExp_186 is __CIL_TMP48,
babelPtrR(__CIL_TMP49, BabelExp_186, 8),
BabelExp_187 is __CIL_TMP49,
babelAssign(__CIL_TMP50, BabelExp_187),
babelAssign(__CIL_TMP51, __CIL_TMP50 +1* 96),
babelAssign(__CIL_TMP52, __CIL_TMP51),
BabelExp_188 is __CIL_TMP52,
babelPtrR(__CIL_TMP53, BabelExp_188, 4),

(babelJcc(12, __CIL_TMP53, 0) ->
babelAssign(__CIL_TMP12, 1)
; babelAssign(__CIL_TMP12, 0)),

(babelJcc(13, __CIL_TMP12, 0) ->
BabelExp_189 is __CIL_AP_NET,
babelPtrR(__CIL_TMP54, BabelExp_189, 8),
babelAssign(__CIL_TMP55, __CIL_TMP54),
babelAssign(__CIL_TMP56, __CIL_TMP55 +1* 528),
babelAssign(__CIL_TMP57, __CIL_TMP56),
babelAssign(MEM_67, ARC),
BabelExp_190 is MEM_67,
babelPtrR(__CIL_TMP58, BabelExp_190, 8),
BabelExp_191 is __CIL_TMP57,
babelPtrR(__CIL_TMP59, BabelExp_191, 8),
BabelExp_192 is __CIL_AP_OPERATIONAL_COST,
babelPtrR(__CIL_TMP60, BabelExp_192, 8),
BabelExp_193 is __CIL_TMP58 - __CIL_TMP59,
babelAssign(__CIL_TMP61, BabelExp_193),
BabelExp_194 is __CIL_TMP60 + __CIL_TMP61,
babelPtrL(__CIL_AP_OPERATIONAL_COST, BabelExp_194, 8),
BabelExp_195 is __CIL_AP_FLEET,
babelPtrR(__CIL_TMP62, BabelExp_195, 8),
BabelExp_196 is __CIL_TMP62 + 1,
babelPtrL(__CIL_AP_FLEET, BabelExp_196, 8)
; BabelExp_197 is __CIL_AP_OPERATIONAL_COST,
babelPtrR(__CIL_TMP63, BabelExp_197, 8),
babelAssign(MEM_68, ARC),
BabelExp_198 is MEM_68,
babelPtrR(__CIL_TMP64, BabelExp_198, 8),
BabelExp_199 is __CIL_TMP63 + __CIL_TMP64,
babelPtrL(__CIL_AP_OPERATIONAL_COST, BabelExp_199, 8))
; true))
; true),
babelAssign(ARC_SSA_1, ARC +64),
flow_cost_cil_lr_3(__CIL_AP_NET, __CIL_AP_FLEET, __CIL_AP_OPERATIONAL_COST, ARC_SSA_1, STOP, VOID),true
; true),
babelAssign(ARC_SSA_1, ARC +64),
flow_cost_cil_lr_3(__CIL_AP_NET, __CIL_AP_FLEET, __CIL_AP_OPERATIONAL_COST, ARC_SSA_1, STOP, VOID),true. 

 :- foreign(babel__mcfutil_c_19(+integer, +integer, +integer)).
:- foreign(babel__mcfutil_c_20(+integer, +integer)).
:- foreign(babel__mcfutil_c_21(+integer, +integer, +integer, +integer)).

refresh_potential_cil_lr_1(__CIL_FP_TMP, __CIL_FP_NODE, __CIL_PP_TMP, __CIL_PP_NODE, __CIL_AP_CHECKSUM, NODE, TMP, ROOT, VOID) :- 
(
NODE =:= ROOT-> true;
babelPtrL(__CIL_FP_TMP, TMP, 8),
babel__mcfutil_c_19(__CIL_PP_TMP, __CIL_AP_CHECKSUM, NODE),
babelPtrR(TMP_SSA_1, __CIL_FP_TMP, 8),
NODE_SSA_1 is TMP_SSA_1,
babelPtrL(__CIL_FP_NODE, NODE_SSA_1, 8),
babelPtrL(__CIL_FP_TMP, TMP_SSA_1, 8),
babel__mcfutil_c_20(__CIL_PP_NODE, __CIL_PP_TMP),
babelPtrR(NODE_SSA_2, __CIL_FP_NODE, 8),
babelPtrR(TMP_SSA_2, __CIL_FP_TMP, 8),
refresh_potential_cil_lr_1(__CIL_FP_TMP, __CIL_FP_NODE, __CIL_PP_TMP, __CIL_PP_NODE, __CIL_AP_CHECKSUM, NODE_SSA2, TMP_SSA2, ROOT, VOID)).

refresh_neighbour_lists_cil_lr_1(NODE, STOP) :-
((NODE >= STOP) -> true);
(
__CIL_TMP6 is NODE + 64,
babelPtrL(__CIL_TMP6, 0, 8),
__CIL_TMP8 is NODE + 56,
babelPtrL(__CIL_TMP8, 0, 8),
NODE_SSA_1 is NODE +104,
refresh_neighbour_lists_cil_lr_1(NODE_SSA_1, STOP)
).

refresh_neighbour_lists_cil_lr_2(ARC, STOP) :- 
ARC >= STOP -> true;
__CIL_TMP6 is ARC + 8,
babelPtrR(__CIL_TMP8, __CIL_TMP6, 8),
__CIL_TMP10 is __CIL_TMP8 + 56,
__CIL_TMP12 is ARC + 32,
babelPtrR(BabelExp_210, __CIL_TMP10, 8),
babelPtrL(__CIL_TMP12, BabelExp_210, 8),
__CIL_TMP14 is ARC + 8,
babelPtrR(__CIL_TMP15, __CIL_TMP14, 8),
__CIL_TMP18 is __CIL_TMP15 + 56,
babelPtrL(__CIL_TMP18, ARC, 8),
__CIL_TMP20 is ARC + 16,
babelPtrR(__CIL_TMP21, __CIL_TMP20, 8),
__CIL_TMP24 is __CIL_TMP21 + 64,
babelAssign(__CIL_TMP26, ARC + 40),
babelPtrR(BabelExp_216, __CIL_TMP24, 8),
babelPtrL(__CIL_TMP26, BabelExp_216, 8),
__CIL_TMP27 is ARC + 16,
babelPtrR(__CIL_TMP29, __CIL_TMP27, 8),
__CIL_TMP32 is __CIL_TMP29 +64,
babelPtrL(__CIL_TMP32, ARC, 8),
ARC_SSA_1 is ARC +64,
refresh_neighbour_lists_cil_lr_2(ARC_SSA_1, STOP).
