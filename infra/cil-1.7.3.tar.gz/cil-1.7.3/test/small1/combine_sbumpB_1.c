typedef int int_type;

typedef int_type int_type1;

static __inline__ int_type1 sbump(struct str1 *const);
