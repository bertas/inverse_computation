int x;

int main(int a) {
  int i=0;
  int j = 6;
  while (a<5) { i=i+j+a; }

}

int main1(int a) {
  int k = 0;;
  while(a<5) {
    k ++;
  }
}
                
