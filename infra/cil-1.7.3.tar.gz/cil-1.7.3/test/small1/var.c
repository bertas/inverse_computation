int v2;   

F1()
{ 
  int v1,v2;
  F2(v1);
  F2(v2);
}

int v1;

F2(int a) {
  v1=0;
  v2=0;
}
