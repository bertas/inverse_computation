

int x; // We take its address
int b[5];


int main() {
  int local1, local2[4];
  int z;
  
  while(b[3] + &x) {
    z = &local1 + local2[2];
  }
  return z;
}
