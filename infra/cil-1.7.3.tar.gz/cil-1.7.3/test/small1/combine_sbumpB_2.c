typedef int int_type;

typedef int_type int_type1;

__inline static int_type1 sbump(struct str1 *this ) ;
