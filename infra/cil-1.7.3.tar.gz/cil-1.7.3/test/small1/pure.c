int pure[700000 / sizeof (int)] = {0,} ;

int main() {
  char *blah = (char *)pure;
  return 0;
}


