enum e2 {
  ITEM1 = 5,
  ITEM2 = 6,
} x2;

int getitem5() {
  return ITEM1;
}
